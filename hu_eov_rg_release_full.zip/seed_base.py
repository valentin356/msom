
import argparse, os, math, pandas as pd, logging, time
from hu_eov_rg.io_any import load_any_table
from hu_eov_rg.io_parquet_cfg import normalize_df_with_schema
from hu_eov_rg.coords import ensure_eov_coords
from hu_eov_rg.store import save_new_base_version
from hu_eov_rg.raster_export import export_rasters, export_diagnostics, generate_html_report
from hu_eov_rg.logging_utils import setup_logging, get_logger
from hu_eov_rg.progress import pbar

def _write_raster_meta(store_dir: str, base_res_m: float, x0: float, y0: float, levels=(7,10)):
    meta_dir = os.path.join(store_dir, "rasters"); os.makedirs(meta_dir, exist_ok=True)
    meta_path = os.path.join(meta_dir, "meta.json")
    with open(meta_path, "w", encoding="utf-8") as f:
        import json; json.dump({"base_res_m": float(base_res_m), "x0": float(x0), "y0": float(y0), "levels": list(levels)}, f, ensure_ascii=False, indent=2)
    return meta_path

def _load_meta_or_infer(store_dir: str, df: "pd.DataFrame", base_res_m: float):
    meta_path = os.path.join(store_dir, "rasters", "meta.json")
    if os.path.exists(meta_path):
        import json; 
        with open(meta_path, "r", encoding="utf-8") as f: m = json.load(f)
        return m["base_res_m"], m["x0"], m["y0"], m.get("levels",[7,10])
    x0 = float(df["eov_x"].min() - 1000.0); y0 = float(df["eov_y"].min() - 1000.0)
    return base_res_m, x0, y0, [7,10]

def main():
    ap = argparse.ArgumentParser(description="Ősfeltöltés – V1 base + raszterek + riport + tesztkészlet")
    ap.add_argument("--input", required=True); ap.add_argument("--schema", required=True); ap.add_argument("--store", required=True)
    ap.add_argument("--base-res-m", type=float, default=2048.0); ap.add_argument("--levels", type=int, nargs="+", default=[7,10])
    ap.add_argument("--export-csv", action="store_true"); ap.add_argument("--export-png", action="store_true")
    ap.add_argument("--no-quantize", action="store_true"); ap.add_argument("--max-dist-m", type=int, default=5000)
    args = ap.parse_args()

    log_path = os.path.join(args.store, 'diagnostics', 'V1', 'process.log')
    setup_logging(log_path, level=logging.INFO); log = get_logger(__name__)
    log.info("Start seed_base")

    raw = load_any_table(args.input)
    norm = normalize_df_with_schema(raw, args.schema)
    raw_conv = ensure_eov_coords(raw)
    if ("EOV_X" not in norm.columns or "EOV_Y" not in norm.columns) and ("EOV_X" in raw_conv.columns and "EOV_Y" in raw_conv.columns):
        norm["EOV_X"] = raw_conv["EOV_X"]; norm["EOV_Y"] = raw_conv["EOV_Y"]
    norm["eov_x"] = norm.get("EOV_Y"); norm["eov_y"] = norm.get("EOV_X")
    norm["has_coords"] = norm["eov_x"].notna() & norm["eov_y"].notna()

    save_new_base_version(args.store, norm, version=1); log.info("Base V1 created")

    coords_df = norm[norm["has_coords"]]
    base_res_m, x0, y0, levels = _load_meta_or_infer(args.store, coords_df if not coords_df.empty else norm, args.base_res_m)
    _write_raster_meta(args.store, base_res_m, x0, y0, levels)

    df = coords_df.copy()
    df["house_number"] = df["house_number"].astype(str)
    df["base_num"] = df["house_number"].str.extract(r"(\d+)").astype(float)
    def _parity_safe(x):
        if pd.isna(x): return None
        try: n=int(x)
        except: return None
        return "even" if n%2==0 else "odd"
    df["parity"] = df["base_num"].apply(_parity_safe)
    edges = []
    for (sett, street, par), g in pbar(df.groupby(["settlement","street","parity"]), desc='build edges groups'):
        g = g.dropna(subset=["base_num"]).sort_values("base_num")
        prev=None
        for _,r in g.iterrows():
            if prev is not None:
                d = math.hypot(r["eov_x"]-prev["eov_x"], r["eov_y"]-prev["eov_y"])
                tanya_flag = any(("tanya" in str(v).lower()) for v in [prev.get("tags",""), r.get("tags",""), street])
                sparse = d > 200.0
                edges.append({"settlement":sett,"street":street,"parity":par,
                              "x_lo":prev["eov_x"],"y_lo":prev["eov_y"],
                              "x_hi":r["eov_x"],"y_hi":r["eov_y"],
                              "gap_m":float(d),"interp_allowed": bool(not (tanya_flag or sparse))})
            prev=r
    import pandas as _pd
    rasters_dir = os.path.join(args.store, "rasters", "V1"); diags_dir = os.path.join(args.store, "diagnostics", "V1")
    os.makedirs(rasters_dir, exist_ok=True); os.makedirs(diags_dir, exist_ok=True)
    export_rasters(norm, _pd.DataFrame(edges), rasters_dir, base_res_m, x0, y0, levels=levels,
                   export_csv=bool(args.export_csv), export_png=bool(args.export_png), export_tif=True,
                   quantize=not args.no_quantize, max_dist_m=args.max_dist_m)
    export_diagnostics(norm, _pd.DataFrame(edges), diags_dir)
    report_path = os.path.join(diags_dir, "report.html")
    generate_html_report("V1", rasters_dir, diags_dir, report_path)

    proj_root = os.path.dirname(os.path.abspath(__file__))
    test_out = os.path.join(proj_root, "test_missing_seed_V1.csv")
    norm[~norm["has_coords"]].to_csv(test_out, index=False, encoding="utf-8")
    log.info(f"Saved test set to {test_out}")

if __name__ == "__main__":
    main()
