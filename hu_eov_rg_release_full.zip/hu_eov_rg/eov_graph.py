
from dataclasses import dataclass
import math, pandas as pd, logging
from .progress import pbar

log = logging.getLogger(__name__)

def dist_m_eov(x1,y1,x2,y2): return float(math.hypot(x2-x1, y2-y1))

def _parity_safe(x):
    if pd.isna(x): return None
    try: n=int(x)
    except: return None
    return "even" if n%2==0 else "odd"

@dataclass
class GeoResultEOV:
    eov_x: float
    eov_y: float
    source: str
    error_m: float
    meta: dict

class AddressGraphEOV:
    def __init__(self, df_addresses: pd.DataFrame, sparse_gap_m: float=200.0):
        req = {"street","house_number","eov_x","eov_y"}
        if not req.issubset(set(df_addresses.columns)):
            miss = req - set(df_addresses.columns)
            raise ValueError(f"Missing columns for graph: {miss}")
        self.addr = df_addresses[df_addresses["eov_x"].notna() & df_addresses["eov_y"].notna()].copy()
        self.addr["house_number"] = self.addr["house_number"].astype(str)
        self.addr["base_num"] = self.addr["house_number"].str.extract(r"(\d+)").astype(float)
        self.addr["parity"] = self.addr["base_num"].apply(_parity_safe)
        if "settlement" not in self.addr.columns: self.addr["settlement"] = None
        if "tags" not in self.addr.columns: self.addr["tags"] = ""
        self.addr.sort_values(["settlement","street","parity","base_num"], inplace=True)
        self.sparse_gap_m = float(sparse_gap_m)
        self.edges = self._build_edges()
        self.street_stats = self._build_density()

    def _build_edges(self) -> pd.DataFrame:
        rows = []
        groups = list(self.addr.groupby(["settlement","street","parity"]))
        for (sett, street, par), g in pbar(groups, desc="edges", leave=False):
            g = g.dropna(subset=["base_num"]).sort_values("base_num")
            prev = None
            for _, r in g.iterrows():
                if prev is not None:
                    d = dist_m_eov(prev["eov_x"], prev["eov_y"], r["eov_x"], r["eov_y"])
                    tanya_flag = any(("tanya" in str(v).lower()) for v in [prev.get("tags",""), r.get("tags",""), street])
                    sparse = d > self.sparse_gap_m
                    rows.append({
                        "settlement":sett, "street":street, "parity":par,
                        "num_lo": int(prev["base_num"]), "num_hi": int(r["base_num"]),
                        "x_lo": prev["eov_x"], "y_lo": prev["eov_y"],
                        "x_hi": r["eov_x"], "y_hi": r["eov_y"],
                        "gap_m": d, "tanya_edge": bool(tanya_flag), "sparse_edge": bool(sparse),
                        "interp_allowed": bool(not (tanya_flag or sparse)),
                    })
                prev = r
        return pd.DataFrame(rows)

    def _build_density(self) -> pd.DataFrame:
        stats = []
        for (sett, street, par), g in self.edges.groupby(["settlement","street","parity"]):
            n = len(g); total = g["gap_m"].sum() if n else 0.0
            addr_count = n + 1 if n else len(self.addr[(self.addr["settlement"]==sett)&(self.addr["street"]==street)&(self.addr["parity"]==par)])
            dens = (addr_count / (total/1000.0)) if total>0 else None
            stats.append({"settlement":sett,"street":street,"parity":par,
                          "addresses": int(addr_count),"total_length_m": float(total),
                          "density_per_km": float(dens) if dens else None,
                          "sparse_ratio": float(g["sparse_edge"].mean()) if n else 0.0,
                          "tanya_ratio": float(g["tanya_edge"].mean()) if n else 0.0,
                          "interp_allowed_fraction": float(g["interp_allowed"].mean()) if n else 0.0})
        return pd.DataFrame(stats)

class GeocoderEOV:
    def __init__(self, graph: AddressGraphEOV, all_rows_df: pd.DataFrame):
        self.g = graph; self.full = all_rows_df
    def geocode(self, settlement, street, hn) -> GeoResultEOV:
        exact = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street)) & (self.g.addr["house_number"].eq(str(hn)))]
        if not exact.empty:
            r = exact.iloc[0]; return GeoResultEOV(r["eov_x"], r["eov_y"], "exact", 0.0, {"match":"exact"})
        import re
        m = re.match(r"(\d+)", str(hn))
        if not m:
            pts = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street))]
            if pts.empty: raise ValueError("Street has no known anchors with coordinates")
            return GeoResultEOV(pts["eov_x"].mean(), pts["eov_y"].mean(), "street-centroid", 150.0, {"reason":"no-number"})
        base = int(m.group(1)); par = "even" if base%2==0 else "odd"
        group = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street)) & (self.g.addr["parity"].eq(par))].dropna(subset=["base_num"]).sort_values("base_num")
        if group.empty:
            group = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street))].dropna(subset=["base_num"]).sort_values("base_num")
            if group.empty: raise ValueError("Street has no known anchors with coordinates")
        lower = group[group["base_num"] < base].tail(1); upper = group[group["base_num"] > base].head(1)
        if lower.empty or upper.empty:
            near = group.iloc[(group["base_num"]-base).abs().argsort().iloc[0]]
            return GeoResultEOV(near["eov_x"], near["eov_y"], "nearest", 60.0, {"reason":"no-bracket"})
        lo, hi = lower.iloc[0], upper.iloc[0]
        edges = self.g.edges
        chain = edges[(edges["settlement"].eq(settlement)) & (edges["street"].eq(street)) & (edges["num_lo"].eq(int(lo["base_num"]))) & (edges["num_hi"].eq(int(hi["base_num"])))]
        if chain.empty or not bool(chain.iloc[0]["interp_allowed"]):
            d = dist_m_eov(lo["eov_x"], lo["eov_y"], hi["eov_x"], hi["eov_y"])
            return GeoResultEOV(lo["eov_x"], lo["eov_y"], "anchor-no-interp", d/2, {"blocked_edge":True}) if (base-int(lo["base_num"])<=int(hi["base_num"])-base) else GeoResultEOV(hi["eov_x"], hi["eov_y"], "anchor-no-interp", d/2, {"blocked_edge":True})
        ratio = (base - int(lo["base_num"])) / (int(hi["base_num"]) - int(lo["base_num"]))
        x = lo["eov_x"] + ratio*(hi["eov_x"]-lo["eov_x"]); y = lo["eov_y"] + ratio*(hi["eov_y"]-lo["eov_y"])
        gap_m = float(chain.iloc[0]["gap_m"])
        dens_row = self.g.street_stats[(self.g.street_stats["settlement"].eq(settlement)) & (self.g.street_stats["street"].eq(street)) & (self.g.street_stats["parity"].eq(par))]
        density = float(dens_row.iloc[0]["density_per_km"]) if (not dens_row.empty and dens_row.iloc[0]["density_per_km"]) else None
        err = (gap_m/2) / math.sqrt(max((density or 50.0)/50.0, 0.5))
        return GeoResultEOV(x, y, "interpolated", float(err), {"gap_m":gap_m,"density_per_km":density})
