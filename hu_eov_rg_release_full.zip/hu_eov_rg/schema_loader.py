
import json, os
def load_schema(path: str):
    ext = os.path.splitext(path)[1].lower()
    if ext in [".json",".jsn"]:
        with open(path, "r", encoding="utf-8") as f: return json.load(f)
    elif ext in [".yaml",".yml"]:
        import yaml
        with open(path, "r", encoding="utf-8") as f: return yaml.safe_load(f)
    else:
        raise ValueError("Unsupported schema extension. Use .json or .yaml")
