
import re, os, sys
from typing import Dict, List, Tuple, Optional, Any

import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.warp import reproject
from rasterio.windows import from_bounds
from rasterio import transform as rio_transform

S2_BANDS_NATIVE = {
    "B01": 60, "B02": 10, "B03": 10, "B04": 10,
    "B05": 20, "B06": 20, "B07": 20, "B08": 10,
    "B8A": 20, "B09": 60, "B10": 60, "B11": 20, "B12": 20
}
DEFAULT_ORDER = ["B02","B03","B04","B08","B05","B06","B07","B8A","B11","B12","B01","B09","B10"]

BAND_RE = re.compile(r"(B0[1-9]|B1[0-2]|B8A)\b", flags=re.IGNORECASE)
RES_RE  = re.compile(r"/R(10|20|60)m/", flags=re.IGNORECASE)

def _norm(s: str) -> str:
    return s.replace("\\", "/")

def list_s2_bands_in_zip(zip_path: str) -> Dict[str, Dict[str, Optional[str]]]:
    import zipfile
    if not os.path.exists(zip_path):
        raise FileNotFoundError(f"ZIP not found: {zip_path}")
    with zipfile.ZipFile(zip_path, "r") as zf:
        files = [_norm(n) for n in zf.namelist() if n.lower().endswith(".jp2")]
    filtered = [f for f in files if ("TCI" not in f.split("/")[-1])]
    out: Dict[str, Dict[str, Optional[str]]] = {b: {"10m": None, "20m": None, "60m": None} for b in S2_BANDS_NATIVE.keys()}
    for f in filtered:
        m_band = BAND_RE.search(f)
        m_res  = RES_RE.search("/" + f + "/")
        if not m_band or not m_res:
            continue
        band = m_band.group(1).upper()
        res  = m_res.group(1) + "m"
        if band in out:
            out[band][res] = f
    if not any(any(v for v in d.values()) for d in out.values()):
        raise RuntimeError("No JP2 bands found in ZIP (did you pass a SAFE.zip?).")
    return out

def _open_vsizip(zip_path: str, inner_path: str):
    vsi1 = f"zip://{zip_path}!{inner_path}"
    try:
        return rasterio.open(vsi1)
    except Exception as e1:
        vsi2 = "/vsizip/" + _norm(zip_path).lstrip("/") + "/" + inner_path.lstrip("/")
        try:
            return rasterio.open(vsi2)
        except Exception as e2:
            raise RuntimeError(f"Failed to open JP2 via VSIZIP. Tried:\n  {vsi1}\n  {vsi2}\nErrors: {e1}\n{e2}")

def _pick_reference_dataset(zip_path: str, band_map: Dict[str, Dict[str, str]], target_res_m: int):
    candidates = []
    for b in DEFAULT_ORDER:
        res_key = f"{target_res_m}m"
        p = band_map.get(b, {}).get(res_key)
        if p:
            candidates.append((b, p))
    if not candidates:
        for b, d in band_map.items():
            for rk in ["10m","20m","60m"]:
                if d.get(rk):
                    candidates.append((b, d[rk]))
    if not candidates:
        raise RuntimeError("No usable bands found in ZIP.")
    ds = _open_vsizip(zip_path, candidates[0][1])
    return ds

def load_s2_zip(
    zip_path: str,
    bands: Optional[List[str]] = None,
    target_res_m: int = 10,
    order: Optional[List[str]] = None,
    resampling: str = "bilinear",
    out_dtype: str = "float32",
    scale_reflectance: bool = False,
    aoi_bounds: Optional[Tuple[float,float,float,float]] = None,
):
    if target_res_m not in (10,20,60):
        raise ValueError("target_res_m must be one of {10,20,60}")
    print(f"[loader] scanning: {zip_path}", file=sys.stderr)
    band_map = list_s2_bands_in_zip(zip_path)

    if bands is None:
        bands = [b for b in DEFAULT_ORDER if any(band_map[b].values())]
    if order is None:
        order = [b for b in DEFAULT_ORDER if b in bands]
    else:
        order = [b for b in order if b in bands]

    ref_ds = _pick_reference_dataset(zip_path, band_map, target_res_m)
    ref_crs = ref_ds.crs
    bounds = ref_ds.bounds

    dst_width  = int(round((bounds.right - bounds.left) / target_res_m))
    dst_height = int(round((bounds.top   - bounds.bottom) / target_res_m))
    dst_transform = rio_transform.from_origin(bounds.left, bounds.top, target_res_m, target_res_m)

    if aoi_bounds is not None:
        window = from_bounds(*aoi_bounds, transform=dst_transform, width=dst_width, height=dst_height)
        h = int(window.height); w = int(window.width)
        dst_transform = rasterio.windows.transform(window, dst_transform)
        dst_height, dst_width = h, w

    stack_list = []
    used = []
    missing = []
    for b in order:
        preferred = f"{target_res_m}m"
        inner = band_map.get(b, {}).get(preferred)
        if inner is None:
            fallback_order = ["10m","20m","60m"]
            fallback_order.sort(key=lambda r: abs(int(r[:-1]) - target_res_m))
            for rk in fallback_order:
                if band_map.get(b, {}).get(rk):
                    inner = band_map[b][rk]; break
        if inner is None:
            missing.append(b)
            continue
        print(f"[loader] band {b} -> {inner}", file=sys.stderr)
        with _open_vsizip(zip_path, inner) as ds:
            src = ds.read(1).astype(out_dtype)
            if scale_reflectance:
                src = src / 10000.0
            dst = np.zeros((dst_height, dst_width), dtype=out_dtype)
            reproject(
                source=src,
                destination=dst,
                src_transform=ds.transform,
                src_crs=ds.crs,
                dst_transform=dst_transform,
                dst_crs=ref_crs,
                resampling=getattr(Resampling, resampling),
                num_threads=2
            )
        stack_list.append(dst)
        used.append(b)

    if not stack_list:
        raise RuntimeError("No bands could be loaded/resampled.")

    stack = np.stack(stack_list, axis=0)

    profile = {
        "driver": "GTiff",
        "dtype": str(stack.dtype),
        "count": stack.shape[0],
        "height": dst_height,
        "width": dst_width,
        "transform": dst_transform,
        "crs": ref_crs,
        "compress": "deflate",
        "tiled": True,
        "blockxsize": 256,
        "blockysize": 256,
        "interleave": "band",
        "zip_path": zip_path,
        "target_res_m": target_res_m
    }
    if missing:
        print(f"[loader] missing bands (skipped): {missing}", file=sys.stderr)
    return stack, profile, used

def write_geotiff(out_path: str, stack, profile, band_names=None):
    out_dir = os.path.dirname(os.path.abspath(out_path))
    if out_dir and not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    abs_path = os.path.abspath(out_path)
    print(f"[writer] writing -> {abs_path}", file=sys.stderr)
    with rasterio.open(out_path, "w", **{k:v for k,v in profile.items() if k in [
        "driver","dtype","count","height","width","transform","crs","compress","tiled","blockxsize","blockysize","interleave"]}) as dst:
        for i in range(stack.shape[0]):
            dst.write(stack[i], i+1)
            if band_names:
                try:
                    dst.set_band_description(i+1, band_names[i])
                except Exception:
                    pass
    print(f"[writer] done: {abs_path}", file=sys.stderr)

def derive_hr_profile(lr_profile: dict, up_factor: int):
    t = lr_profile["transform"]
    new_a = t.a / up_factor
    new_e = t.e / up_factor
    hr_transform = rio_transform.Affine(new_a, t.b, t.c, t.d, new_e, t.f)
    hr_profile = lr_profile.copy()
    hr_profile["height"] = lr_profile["height"] * up_factor
    hr_profile["width"]  = lr_profile["width"]  * up_factor
    hr_profile["transform"] = hr_transform
    return hr_profile
