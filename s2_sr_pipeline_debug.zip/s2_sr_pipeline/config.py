
from dataclasses import dataclass
@dataclass
class ModelConfig:
    bands: int = 13
    up_factor: int = 10
    endmembers: int = 8
    som_codebook: int = 64
    som_sigma: float = 1.5
    tv_weight: float = 0.01
    grad_weight: float = 0.05
    order_weight: float = 0.01
    recon_l1_weight: float = 1.0
    sam_weight: float = 0.2
