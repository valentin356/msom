
import torch, torch.nn as nn, torch.nn.functional as F
class DirichletUnmix(nn.Module):
    def __init__(self, in_dim:int, endmembers:int, temp:float=1.0):
        super().__init__()
        self.net = nn.Sequential(nn.Conv2d(in_dim, in_dim, 3, padding=1), nn.ReLU(True), nn.Conv2d(in_dim, endmembers, 1))
        self.log_temp = nn.Parameter(torch.log(torch.tensor([temp])))
    def forward(self, feat):
        return F.softmax(self.net(feat) / torch.exp(self.log_temp), dim=1)
def mix_spectra(A, E):
    return torch.einsum('bkhw,kc->bchw', A, E.clamp(0,1))
