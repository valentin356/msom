
import argparse, torch, numpy as np, os, sys
from .dataio import load_s2_zip, write_geotiff, derive_hr_profile
from .config import ModelConfig
from .model import GraphSOMUpscaleModel

ANCHORS_PREF = ["B02","B03","B04","B08"]

def pick_anchors(stack, used_bands, max_ch=4):
    idxs = []
    for b in ANCHORS_PREF:
        if b in used_bands and len(idxs) < max_ch:
            idxs.append(used_bands.index(b))
    i = 0
    while len(idxs) < max_ch and i < len(used_bands):
        if i not in idxs:
            idxs.append(i)
        i += 1
    return stack[idxs]

def main():
    ap = argparse.ArgumentParser(description="S2 SAFE ZIP loader + Graph-SOM Unmixing upscale (debug loud).")
    ap.add_argument("zip", help="Path to Sentinel-2 SAFE .zip")
    ap.add_argument("--out", required=True, help="Output HR GeoTIFF path")
    ap.add_argument("--res", type=int, default=10, choices=[10,20,60], help="Target LR stacking resolution (m)")
    ap.add_argument("--up", type=int, default=10, help="Upscale factor (10 => 1 m from 10 m)")
    ap.add_argument("--endmembers", type=int, default=8, help="Number of endmembers (K)")
    ap.add_argument("--bands", nargs="+", default=None, help="Bands to include (e.g., B02 B03 B04 B08 B11 B12 B8A)")
    ap.add_argument("--resampling", default="bilinear", choices=["nearest","bilinear","cubic","cubic_spline","lanczos"], help="Resampling for LR stack")
    ap.add_argument("--reflectance", action="store_true", help="Divide by 10000 for L2A reflectance")
    ap.add_argument("--save-lr", dest="save_lr", default=None, help="Optional: write LR stacked GeoTIFF")
    ap.add_argument("--device", default="cuda", choices=["cuda","cpu"], help="Device for model inference")
    args = ap.parse_args()

    print(f"[main] ZIP: {args.zip}", file=sys.stderr)
    stack, profile, used = load_s2_zip(args.zip, bands=args.bands, target_res_m=args.res, resampling=args.resampling, scale_reflectance=args.reflectance)
    print(f"[main] used bands: {used}", file=sys.stderr)
    print(f"[main] stack shape [B,H,W]: {stack.shape}", file=sys.stderr)

    device = args.device if torch.cuda.is_available() and args.device == "cuda" else "cpu"
    print(f"[main] device: {device}", file=sys.stderr)
    cfg = ModelConfig(bands=stack.shape[0], up_factor=args.up, endmembers=args.endmembers)
    model = GraphSOMUpscaleModel(cfg).to(device).eval()

    x_lr = torch.from_numpy(stack).unsqueeze(0).to(device)
    anchors = torch.from_numpy(pick_anchors(stack, used, max_ch=min(4, stack.shape[0]))).unsqueeze(0).to(device)

    with torch.no_grad():
        out = model(x_lr, anchors_lr=anchors, compute_loss=False)

    Y_hr = out["Y_hr"].cpu().numpy()[0]
    hr_profile = derive_hr_profile(profile, up_factor=args.up)

    write_geotiff(args.out, Y_hr, hr_profile, band_names=used)
    if args.save_lr:
        write_geotiff(args.save_lr, stack, profile, band_names=used)
    print("[main] done", file=sys.stderr)

if __name__ == "__main__":
    main()
