
import argparse, numpy as np
from .dataio import write_geotiff
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    arr = np.random.rand(3, 64, 64).astype("float32")
    profile = {
        "driver":"GTiff","dtype":"float32","count":3,"height":64,"width":64,
        "transform":(1,0,0,0,-1,0),"crs":None,"compress":"deflate","tiled":True,
        "blockxsize":64,"blockysize":64,"interleave":"band"
    }
    write_geotiff(args.out, arr, profile, band_names=["R","G","B"])
if __name__ == "__main__":
    main()
