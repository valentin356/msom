
from dataclasses import dataclass
import logging
from .progress import pbar
import math
import pandas as pd

def dist_m_eov(x1, y1, x2, y2):
    return float(math.hypot(x2 - x1, y2 - y1))

def parity(n:int)->str: return "even" if n%2==0 else "odd"

@dataclass
class GeoResultEOV:
    eov_x: float  # EASTING (X)
    eov_y: float  # NORTHING (Y)
    source: str
    error_m: float
    meta: dict

log = logging.getLogger(__name__)

class AddressGraphEOV:
    def __init__(self, df_addresses: pd.DataFrame, sparse_gap_m: float=200.0):
        req = {"street","house_number","eov_x","eov_y"}
        if not req.issubset(set(df_addresses.columns)):
            missing = req - set(df_addresses.columns)
            raise ValueError(f"Missing columns for graph: {missing}")
        self.addr = df_addresses[df_addresses["eov_x"].notna() & df_addresses["eov_y"].notna()].copy()
        self.addr["house_number"] = self.addr["house_number"].astype(str)
        self.addr["base_num"] = self.addr["house_number"].str.extract(r"(\\d+)").astype(float)
        self.addr["parity"] = self.addr["base_num"].apply(lambda x: parity(int(x)) if not math.isnan(x) else None)
        if "settlement" not in self.addr.columns: self.addr["settlement"] = None
        if "tags" not in self.addr.columns: self.addr["tags"] = ""
        self.addr.sort_values(["settlement","street","parity","base_num"], inplace=True)
        self.sparse_gap_m = float(sparse_gap_m)
        self.edges = self._build_edges()
        self.street_stats = self._build_density()

    def _build_edges(self) -> pd.DataFrame:
        rows = []
        groups = list(self.addr.groupby(["settlement","street","parity"]))
        for (sett, street, par), g in pbar(groups, desc="edges", leave=False):
            g = g.dropna(subset=["base_num"]).sort_values("base_num")
            prev = None
            for _, r in g.iterrows():
                if prev is not None:
                    d = dist_m_eov(prev["eov_x"], prev["eov_y"], r["eov_x"], r["eov_y"])
                    tanya_flag = any(("tanya" in str(v).lower()) for v in [prev.get("tags",""), r.get("tags",""), street])
                    sparse = d > self.sparse_gap_m
                    rows.append({
                        "settlement": sett, "street": street, "parity": par,
                        "num_lo": int(prev["base_num"]), "num_hi": int(r["base_num"]),
                        "x_lo": prev["eov_x"], "y_lo": prev["eov_y"],
                        "x_hi": r["eov_x"], "y_hi": r["eov_y"],
                        "gap_m": d, "tanya_edge": bool(tanya_flag), "sparse_edge": bool(sparse),
                        "interp_allowed": bool(not (tanya_flag or sparse)),
                    })
                prev = r
        return pd.DataFrame(rows)

    def _build_density(self) -> pd.DataFrame:
        stats = []
        for (sett, street, par), g in self.edges.groupby(["settlement","street","parity"]):
            n = len(g)
            total_len = g["gap_m"].sum() if n else 0.0
            addr_count = n + 1 if n else len(self.addr[(self.addr["settlement"]==sett)&(self.addr["street"]==street)&(self.addr["parity"]==par)])
            dens = (addr_count / (total_len/1000.0)) if total_len > 0 else None
            stats.append({
                "settlement": sett, "street": street, "parity": par,
                "addresses": int(addr_count), "total_length_m": float(total_len),
                "density_per_km": float(dens) if dens else None,
                "sparse_ratio": float(g["sparse_edge"].mean()) if n else 0.0,
                "tanya_ratio": float(g["tanya_edge"].mean()) if n else 0.0,
                "interp_allowed_fraction": float(g["interp_allowed"].mean()) if n else 0.0
            })
        return pd.DataFrame(stats)

    def density_map(self) -> pd.DataFrame:
        return self.street_stats.sort_values(["settlement","street","parity"])

class GeocoderEOV:
    def __init__(self, graph: AddressGraphEOV, all_rows_df: pd.DataFrame):
        self.g = graph
        self.full = all_rows_df

    def geocode(self, settlement, street, hn) -> GeoResultEOV:
        exact = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street)) & (self.g.addr["house_number"].eq(str(hn)))]
        if not exact.empty:
            r = exact.iloc[0]
            return GeoResultEOV(eov_x=r["eov_x"], eov_y=r["eov_y"], source="exact", error_m=0.0, meta={"match":"exact"})
        import re
        m = re.match(r"(\\d+)", str(hn))
        if not m:
            street_pts = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street))]
            if street_pts.empty:
                raise ValueError("Street has no known anchors with coordinates")
            x = street_pts["eov_x"].mean(); y = street_pts["eov_y"].mean()
            return GeoResultEOV(eov_x=x, eov_y=y, source="street-centroid", error_m=150.0, meta={"reason":"no-number"})
        base = int(m.group(1)); par = "even" if base % 2 == 0 else "odd"
        group = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street)) & (self.g.addr["parity"].eq(par))].dropna(subset=["base_num"]).sort_values("base_num")
        if group.empty:
            group = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street))].dropna(subset=["base_num"]).sort_values("base_num")
            if group.empty:
                raise ValueError("Street has no known anchors with coordinates")
        lower = group[group["base_num"] < base].tail(1)
        upper = group[group["base_num"] > base].head(1)
        if lower.empty or upper.empty:
            near = group.iloc[(group["base_num"]-base).abs().argsort().iloc[0]]
            return GeoResultEOV(eov_x=near["eov_x"], eov_y=near["eov_y"], source="nearest", error_m=60.0, meta={"reason":"no-bracket"})
        lo, hi = lower.iloc[0], upper.iloc[0]
        edges = self.g.edges
        chain = edges[(edges["settlement"].eq(settlement)) & (edges["street"].eq(street)) & (edges["num_lo"].eq(int(lo["base_num"]))) & (edges["num_hi"].eq(int(hi["base_num"])))]
        if chain.empty or not bool(chain.iloc[0]["interp_allowed"]):
            d = dist_m_eov(lo["eov_x"], lo["eov_y"], hi["eov_x"], hi["eov_y"])
            if (base - int(lo["base_num"])) <= (int(hi["base_num"]) - base):
                return GeoResultEOV(eov_x=lo["eov_x"], eov_y=lo["eov_y"], source="anchor-no-interp", error_m=d/2, meta={"blocked_edge":True})
            else:
                return GeoResultEOV(eov_x=hi["eov_x"], eov_y=hi["eov_y"], source="anchor-no-interp", error_m=d/2, meta={"blocked_edge":True})
        ratio = (base - int(lo["base_num"])) / (int(hi["base_num"]) - int(lo["base_num"]))
        x = lo["eov_x"] + ratio * (hi["eov_x"] - lo["eov_x"])
        y = lo["eov_y"] + ratio * (hi["eov_y"] - lo["eov_y"])
        gap_m = float(chain.iloc[0]["gap_m"])
        dens_row = self.g.street_stats[(self.g.street_stats["settlement"].eq(settlement)) & (self.g.street_stats["street"].eq(street)) & (self.g.street_stats["parity"].eq(par))]
        density = float(dens_row.iloc[0]["density_per_km"]) if (not dens_row.empty and dens_row.iloc[0]["density_per_km"]) else None
        err = (gap_m/2) / math.sqrt(max((density or 50.0)/50.0, 0.5))
        return GeoResultEOV(eov_x=x, eov_y=y, source="interpolated", error_m=float(err), meta={"gap_m":gap_m,"density_per_km":density})
