
import pandas as pd
from typing import Tuple, Optional

WGS_LON_CANDIDATES = ["lon","longitude","long","x","wgs84_x","wgs_lon"]
WGS_LAT_CANDIDATES = ["lat","latitude","y","wgs84_y","wgs_lat"]

def detect_coords(df: pd.DataFrame) -> str:
    """
    Returns one of: "eov", "wgs84", "none"
    Detects EOV via presence of both 'EOV_X' and 'EOV_Y' (any case).
    Detects WGS84 via presence of lon/lat columns.
    """
    low = {c.lower(): c for c in df.columns}
    has_eov_x = "eov_x" in low
    has_eov_y = "eov_y" in low
    if has_eov_x and has_eov_y:
        return "eov"
    # WGS?
    has_lon = any(c in low for c in WGS_LON_CANDIDATES)
    has_lat = any(c in low for c in WGS_LAT_CANDIDATES)
    if has_lon and has_lat:
        return "wgs84"
    return "none"

def _pick_lower(df: pd.DataFrame, names):
    low = {c.lower(): c for c in df.columns}
    for n in names:
        if n in low:
            return low[n]
    return None

def wgs84_to_eov(df: pd.DataFrame, lon_col: str, lat_col: str) -> pd.DataFrame:
    """
    Convert WGS84 lon/lat to EOV (EPSG:23700) using pyproj if available.
    Adds columns: EOV_X (northing/Y), EOV_Y (easting/X) per your naming.
    """
    try:
        from pyproj import Transformer  # type: ignore
    except Exception as e:
        raise RuntimeError("pyproj is required for WGS84->EOV conversion. Please install pyproj.") from e
    transformer = Transformer.from_crs(4326, 23700, always_xy=True)
    lon = df[lon_col].astype(float)
    lat = df[lat_col].astype(float)
    # transformer returns (x=easting, y=northing) in EOV meters
    easting_x, northing_y = transformer.transform(lon.values, lat.values)
    df_out = df.copy()
    df_out["EOV_Y"] = easting_x  # X
    df_out["EOV_X"] = northing_y # Y
    return df_out

def ensure_eov_coords(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure EOV cols exist (EOV_X=Y northing, EOV_Y=X easting).
    If only WGS84 present, convert (requires pyproj).
    If neither present, just return as-is (geokóder fogja előállítani).
    """
    kind = detect_coords(df)
    if kind == "eov":
        return df
    if kind == "wgs84":
        lon_col = _pick_lower(df, WGS_LON_CANDIDATES)
        lat_col = _pick_lower(df, WGS_LAT_CANDIDATES)
        return wgs84_to_eov(df, lon_col, lat_col)
    return df
