print('geocode_batch placeholder')
