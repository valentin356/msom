
import logging, os
from logging.handlers import RotatingFileHandler

def setup_logging(log_path: str=None, level=logging.INFO):
    logger = logging.getLogger()
    if logger.handlers:
        return logger
    logger.setLevel(level)
    fmt = logging.Formatter('%(asctime)s | %(levelname)s | %(name)s | %(message)s')
    ch = logging.StreamHandler(); ch.setLevel(level); ch.setFormatter(fmt); logger.addHandler(ch)
    if log_path:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        fh = RotatingFileHandler(log_path, maxBytes=5_000_000, backupCount=3, encoding='utf-8')
        fh.setLevel(level); fh.setFormatter(fmt); logger.addHandler(fh)
    return logger

def get_logger(name: str):
    import logging; return logging.getLogger(name)
