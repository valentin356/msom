
import os, re, pandas as pd
from typing import Tuple

BASE_PATTERN = re.compile(r"base_v(\d+)\.(parquet|pq)$", re.IGNORECASE)

def find_latest_base_version(store_dir: str):
    versions = []
    for fn in os.listdir(store_dir):
        m = BASE_PATTERN.match(fn)
        if m:
            versions.append((int(m.group(1)), fn))
    if not versions:
        return None, None
    versions.sort()
    v, fn = versions[-1]
    return v, os.path.join(store_dir, fn)

def save_new_base_version(store_dir: str, df: pd.DataFrame, version: int):
    os.makedirs(store_dir, exist_ok=True)
    path = os.path.join(store_dir, f"base_v{version}.parquet")
    df.to_parquet(path, index=False)
    return path
