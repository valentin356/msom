import hashlib, pandas as pd

def hash64(s: pd.Series) -> pd.Series:
    def h(x: str) -> int:
        b = hashlib.sha1(x.encode('utf-8','ignore')).digest()[:8]
        return int.from_bytes(b, 'big') & ((1<<63)-1)
    return s.fillna("").astype(str).map(h).astype("int64")
