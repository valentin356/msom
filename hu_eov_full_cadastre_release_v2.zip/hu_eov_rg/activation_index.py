import numpy as np, pandas as pd
from .progress import pbar

def build_activation_index(edges_df: pd.DataFrame, x0: float, y0: float, base_res_m: float, level: int):
    res = base_res_m / (2**level)
    try:
        import rasterio
        from rasterio.features import rasterize
        from rasterio.transform import Affine
        lines = []
        for _, e in edges_df.iterrows():
            x1,y1,x2,y2 = float(e["x_lo"]), float(e["y_lo"]), float(e["x_hi"]), float(e["y_hi"])
            lines.append({"type":"LineString","coordinates":[(x1,y1),(x2,y2)]})
        if not lines:
            return pd.DataFrame({"level":[],"xi":[],"yi":[]})
        xs = [min(l["coordinates"][0][0], l["coordinates"][1][0]) for l in lines]
        ys = [min(l["coordinates"][0][1], l["coordinates"][1][1]) for l in lines]
        xe = [max(l["coordinates"][0][0], l["coordinates"][1][0]) for l in lines]
        ye = [max(l["coordinates"][0][1], l["coordinates"][1][1]) for l in lines]
        x_min, x_max = min(xs), max(xe); y_min, y_max = min(ys), max(ye)
        xi0 = int(np.floor((x_min - x0)/res)); yi0 = int(np.floor((y_min - y0)/res))
        xi1 = int(np.ceil((x_max - x0)/res)); yi1 = int(np.ceil((y_max - y0)/res))
        W = max(1, xi1 - xi0); H = max(1, yi1 - yi0)
        transform = Affine(res, 0, x0 + xi0*res, 0, -res, y0 + yi1*res)
        mask = rasterize(((geom,1) for geom in lines), out_shape=(H,W), transform=transform)
        ys_i, xs_i = np.where(mask>0)
        A = pd.DataFrame({"xi": xs_i+xi0, "yi": ys_i+yi0}); A["level"]=level
        return A[["level","xi","yi"]]
    except Exception:
        coords = []
        for _, e in pbar(edges_df.iterrows(), total=len(edges_df), desc=f'activate L{level}'):
            x1, y1, x2, y2 = float(e['x_lo']), float(e['y_lo']), float(e['x_hi']), float(e['y_hi'])
            L = max(1, int(np.hypot(x2-x1, y2-y1) / res))
            ts = np.linspace(0, 1, L+1)
            xs = x1 + ts * (x2 - x1); ys = y1 + ts * (y2 - y1)
            xi = np.floor((xs - x0)/res).astype(int); yi = np.floor((ys - y0)/res).astype(int)
            coords.extend(zip(xi, yi))
        if not coords: return pd.DataFrame({"level":[],"xi":[],"yi":[]})
        A = pd.DataFrame(coords, columns=["xi","yi"]).drop_duplicates(); A["level"] = level
        return A[["level","xi","yi"]]
