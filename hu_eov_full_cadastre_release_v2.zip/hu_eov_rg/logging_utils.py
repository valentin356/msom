import logging, os, sys

def setup_logging(log_path=None, level=logging.INFO):
    handlers = []
    fmt = logging.Formatter('[%(asctime)s] %(levelname)s %(name)s: %(message)s')
    sh = logging.StreamHandler(sys.stdout); sh.setFormatter(fmt); handlers.append(sh)
    if log_path:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        fh = logging.FileHandler(log_path, encoding='utf-8'); fh.setFormatter(fmt); handlers.append(fh)
    logging.basicConfig(level=level, handlers=handlers, force=True)

def get_logger(name):
    return logging.getLogger(name)
