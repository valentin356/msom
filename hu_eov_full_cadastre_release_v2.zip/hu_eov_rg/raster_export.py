import os, json, numpy as np, pandas as pd

def _ensure_dir(p): os.makedirs(p, exist_ok=True); return p

def _tile_counts(df: pd.DataFrame, x0, y0, level, base_res_m):
    res = base_res_m / (2**level)
    if df.empty: return np.zeros((1,1), dtype=int), 0, 0, res
    xi = np.floor((df["eov_x"].to_numpy() - x0)/res).astype(int)
    yi = np.floor((df["eov_y"].to_numpy() - y0)/res).astype(int)
    xi0, yi0 = xi.min(), yi.min(); W = xi.max()-xi0+1; H = yi.max()-yi0+1
    grid = np.zeros((H, W), dtype=int)
    for a,b in zip(yi-yi0, xi-xi0): grid[a,b] += 1
    return grid, xi0, yi0, res

def _save_cog(arr: np.ndarray, path: str, x0: float, y0: float, xi0: int, yi0: int, res: float,
              crs="EPSG:23700", dtype="uint16", block=512, compress="ZSTD", zstd_level=9):
    try:
        import rasterio
        from rasterio.transform import Affine
        from rasterio.enums import Resampling
    except Exception:
        return None
    x_min = x0 + xi0 * res; y_max = y0 + (yi0 + arr.shape[0]) * res
    transform = Affine(res, 0, x_min, 0, -res, y_max)
    profile = dict(driver="GTiff", height=int(arr.shape[0]), width=int(arr.shape[1]), count=1,
                   dtype=str(dtype), crs=crs, transform=transform,
                   tiled=True, blockxsize=int(block), blockysize=int(block),
                   compress=compress, BIGTIFF="YES")
    if compress == "ZSTD": profile["zstd_level"] = int(zstd_level)
    with rasterio.open(path, "w", **profile) as dst:
        dst.write(arr, 1)
        try: dst.build_overviews([2,4,8,16], Resampling.average)
        except Exception: pass
    return path

def export_rasters(base_df: pd.DataFrame, edges_df: pd.DataFrame, out_dir: str, base_res_m: float, x0: float, y0: float, levels=(9,10)):
    _ensure_dir(out_dir)
    anchors = base_df[base_df["has_coords"]][["eov_x","eov_y"]].dropna()
    for L in levels:
        den, xi0, yi0, res = _tile_counts(anchors, x0, y0, L, base_res_m)
        _save_cog(den.astype("uint16"), os.path.join(out_dir, f"density_L{L}.tif"), x0, y0, xi0, yi0, res, dtype="uint16")

def export_diagnostics(base_df: pd.DataFrame, edges_df: pd.DataFrame, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    summary = {"rows_total": int(len(base_df)),
               "rows_with_coords": int(base_df["has_coords"].sum()) if "has_coords" in base_df.columns else None}
    with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    return summary

def generate_html_report(version_label: str, rasters_dir: str, diag_dir: str, out_html_path: str):
    layers = [fn for fn in sorted(os.listdir(rasters_dir)) if fn.endswith(".tif")]
    summary = {}
    sp = os.path.join(diag_dir, "summary.json")
    if os.path.exists(sp):
        with open(sp, "r", encoding="utf-8") as f: summary = json.load(f)
    html = [f"<html><head><meta charset='utf-8'><title>Riport {version_label}</title></head><body>", f"<h1>Riport – {version_label}</h1>"]
    if summary:
        html += ["<h2>Összegző metrikák</h2><ul>"] + [f"<li><b>{k}</b>: {v}</li>" for k,v in summary.items()] + ["</ul>"]
    html.append("<h2>Raszter rétegek</h2>")
    for fn in layers: html.append(f"<p>{fn}</p>")
    html.append("</body></html>")
    with open(out_html_path, "w", encoding="utf-8") as f: f.write("\n".join(html))
    return out_html_path
