import re, pandas as pd
_NUM_RE = re.compile(r"(\d+)")

def extract_base_num(series: pd.Series) -> pd.Series:
    s = series.fillna("").astype(str).map(lambda x: _NUM_RE.search(x).group(1) if _NUM_RE.search(x) else None)
    return pd.to_numeric(s, errors="coerce")
