import pandas as pd

def ensure_eov_coords(df: pd.DataFrame):
    if "EOV_X" in df.columns and "EOV_Y" in df.columns:
        return df
    lat_cols = ["lat","LAT","Lat","wgs84_lat","WGS84_LAT"]
    lon_cols = ["lon","LON","Lon","lng","LNG","long","LONG","wgs84_lon","WGS84_LON"]
    lat = next((c for c in lat_cols if c in df.columns), None)
    lon = next((c for c in lon_cols if c in df.columns), None)
    if lat and lon:
        try:
            from pyproj import Transformer
            tr = Transformer.from_crs(4326, 23700, always_xy=True)
            X, Y = tr.transform(df[lon].astype(float).to_numpy(), df[lat].astype(float).to_numpy())
            out = df.copy(); out["EOV_X"] = Y; out["EOV_Y"] = X
            return out
        except Exception:
            pass
    return df
