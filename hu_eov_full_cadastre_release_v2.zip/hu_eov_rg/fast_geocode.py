import pandas as pd, numpy as np
from .housenum import extract_base_num
from .keyhash import hash64

def build_key_id(df: pd.DataFrame) -> pd.Series:
    key = df["settlement"].astype("string").fillna("") + "||" + df["street"].astype("string").fillna("") + "||" + df["parity"].astype("string").fillna("")
    return hash64(key)

def geocode_vectorized(base_df: pd.DataFrame, edges_df: pd.DataFrame, targets_df: pd.DataFrame):
    anchors = base_df[base_df["has_coords"]].copy()
    anchors["base_num"] = extract_base_num(anchors["house_number"])
    anchors = anchors.dropna(subset=["base_num"])
    anchors["parity"] = np.where((anchors["base_num"] % 2 == 0), "even", "odd")
    anchors["base_num"] = anchors["base_num"].astype(np.int32)
    for c in ["settlement","street","parity"]:
        anchors[c] = anchors[c].astype("string")
    anchors["key_id"] = build_key_id(anchors)
    anchors.sort_values(["key_id","base_num"], inplace=True)

    T = targets_df.copy()
    T["base_num"] = extract_base_num(T["house_number"]).astype("Int64")
    T["parity"] = np.where(T["base_num"].notna() & ((T["base_num"] % 2) == 0), "even", "odd")
    for c in ["settlement","street","parity"]:
        T[c] = T[c].astype("string")
    T["key_id"] = build_key_id(T)
    T.sort_values(["key_id","base_num"], inplace=True)

    exact_map = base_df.set_index(["settlement","street","house_number"])[["eov_x","eov_y"]]
    keys = list(zip(T["settlement"], T["street"], T["house_number"].astype(str)))
    exact_xy = exact_map.reindex(keys)
    exact_mask = exact_xy["eov_x"].notna() & exact_xy["eov_y"].notna()

    out = pd.DataFrame(index=T.index)
    out.loc[exact_mask, "eov_x"] = exact_xy.loc[exact_mask, "eov_x"]
    out.loc[exact_mask, "eov_y"] = exact_xy.loc[exact_mask, "eov_y"]
    out.loc[exact_mask, "GEOCODE_SOURCE"] = "exact"
    out.loc[exact_mask, "GEOCODE_ERROR_M"] = 0.0

    remaining = ~exact_mask
    nonum = remaining & T["base_num"].isna()
    if nonum.any():
        centroids = base_df[base_df["has_coords"]].groupby(["settlement","street"])[["eov_x","eov_y"]].mean().rename(columns={"eov_x":"cx","eov_y":"cy"})
        c_keys = list(zip(T.loc[nonum, "settlement"], T.loc[nonum, "street"]))
        cxy = centroids.reindex(c_keys)
        out.loc[nonum, "eov_x"] = cxy["cx"].values
        out.loc[nonum, "eov_y"] = cxy["cy"].values
        out.loc[nonum, "GEOCODE_SOURCE"] = "street-centroid"
        out.loc[nonum, "GEOCODE_ERROR_M"] = 150.0

    todo = remaining & T["base_num"].notna()
    if todo.any():
        A = anchors[["key_id","base_num","eov_x","eov_y"]].copy()
        L = pd.merge_asof(
            T.loc[todo, ["key_id","base_num"]].sort_values(["key_id","base_num"]),
            A.rename(columns={"eov_x":"x_lo","eov_y":"y_lo"}).sort_values(["key_id","base_num"]),
            by="key_id", on="base_num", direction="backward", allow_exact_matches=True)
        H = pd.merge_asof(
            T.loc[todo, ["key_id","base_num"]].sort_values(["key_id","base_num"]),
            A.rename(columns={"eov_x":"x_hi","eov_y":"y_hi"}).sort_values(["key_id","base_num"]),
            by="key_id", on="base_num", direction="forward", allow_exact_matches=True)
        L = L.reindex(T.loc[todo].sort_values(["key_id","base_num"]).index)
        H = H.reindex(T.loc[todo].sort_values(["key_id","base_num"]).index)
        bn = T.loc[todo, "base_num"].astype(int)
        lo_missing = L["x_lo"].isna() | L["y_lo"].isna()
        hi_missing = H["x_hi"].isna() | H["y_hi"].isna()
        nearest = lo_missing | hi_missing
        if nearest.any():
            xl = L.loc[nearest, "x_lo"]; yl = L.loc[nearest, "y_lo"]
            xh = H.loc[nearest, "x_hi"]; yh = H.loc[nearest, "y_hi"]
            use_lo = xl.notna()
            out.loc[T.loc[todo].index[nearest], "eov_x"] = np.where(use_lo, xl, xh)
            out.loc[T.loc[todo].index[nearest], "eov_y"] = np.where(use_lo, yl, yh)
            out.loc[T.loc[todo].index[nearest], "GEOCODE_SOURCE"] = "nearest"
            out.loc[T.loc[todo].index[nearest], "GEOCODE_ERROR_M"] = 60.0
        both = (~lo_missing) & (~hi_missing)
        if both.any():
            idx = T.loc[todo].index[both]
            blo = L.loc[both, "base_num"].astype(int).values
            bhi = H.loc[both, "base_num"].astype(int).values
            denom = (bhi - blo).astype(float); denom[denom==0] = 1.0
            ratio = (bn.loc[idx].values - blo) / denom
            x = L.loc[both, "x_lo"].values + ratio * (H.loc[both, "x_hi"].values - L.loc[both, "x_lo"].values)
            y = L.loc[both, "y_lo"].values + ratio * (H.loc[both, "y_hi"].values - L.loc[both, "y_lo"].values)
            if edges_df is not None and len(edges_df):
                E = edges_df[["settlement","street","parity","num_lo","num_hi","gap_m","interp_allowed"]].copy()
                E["parity"] = E["parity"].astype("string")
                E["key_id"] = hash64(E["settlement"].astype("string").fillna("") + "||" + E["street"].astype("string").fillna("") + "||" + E["parity"])
                E["num_lo"] = E["num_lo"].astype(int); E["num_hi"] = E["num_hi"].astype(int)
                JJ = pd.DataFrame({"key_id": T.loc[idx, "key_id"].values, "num_lo": blo, "num_hi": bhi}).merge(E, how="left", on=["key_id","num_lo","num_hi"])
                allow = JJ["interp_allowed"].fillna(False).values
                gap = JJ["gap_m"].fillna(200.0).astype(float).values
            else:
                allow = np.ones_like(blo, dtype=bool); gap = np.full_like(blo, 200.0, dtype=float)
            snap = ~allow
            if snap.any():
                closer_lo = (bn.loc[idx].values - blo) <= (bhi - bn.loc[idx].values)
                xs = np.where(closer_lo, L.loc[both, "x_lo"].values, H.loc[both, "x_hi"].values)
                ys = np.where(closer_lo, L.loc[both, "y_lo"].values, H.loc[both, "y_hi"].values)
                out.loc[idx[snap], "eov_x"] = xs[snap]
                out.loc[idx[snap], "eov_y"] = ys[snap]
                out.loc[idx[snap], "GEOCODE_SOURCE"] = "anchor-no-interp"
                out.loc[idx[snap], "GEOCODE_ERROR_M"] = (gap[snap]/2.0)
            ok = allow
            if ok.any():
                out.loc[idx[ok], "eov_x"] = x[ok]; out.loc[idx[ok], "eov_y"] = y[ok]
                out.loc[idx[ok], "GEOCODE_SOURCE"] = "interpolated"; out.loc[idx[ok], "GEOCODE_ERROR_M"] = (gap[ok]/2.0)
    missing_addr = out["GEOCODE_SOURCE"].isna() & (T["settlement"].isna() | T["street"].isna())
    out.loc[missing_addr, "GEOCODE_SOURCE"] = "insufficient-address"; out.loc[missing_addr, "GEOCODE_ERROR_M"] = np.nan
    return out
