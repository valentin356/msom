import logging, numpy as np, pandas as pd
log = logging.getLogger(__name__)

def _sha1_hex(b: bytes) -> str:
    import hashlib; return hashlib.sha1(b).hexdigest()

def _to_eov(gdf, target_epsg=23700):
    if gdf.crs is None: gdf = gdf.set_crs(epsg=target_epsg)
    elif gdf.crs.to_epsg() != target_epsg: gdf = gdf.to_crs(epsg=target_epsg)
    return gdf

def load_parcels_polygons(path: str, target_epsg=23700):
    import geopandas as gpd
    gdf = gpd.read_file(path); gdf = _to_eov(gdf, target_epsg)
    gdf["parcel_id"] = gdf.geometry.apply(lambda g: _sha1_hex(g.wkb)); return gdf

def load_streets_polygons(path: str, code_field: str=None, name_field: str=None, target_epsg=23700):
    import geopandas as gpd
    gdf = gpd.read_file(path); gdf = _to_eov(gdf, target_epsg)
    if code_field and code_field in gdf.columns: gdf["street_code"] = gdf[code_field].astype(str)
    else: gdf["street_code"] = gdf.geometry.apply(lambda g: _sha1_hex(g.wkb))
    gdf["street_name"] = gdf[name_field].astype(str) if name_field and name_field in gdf.columns else None
    return gdf

def parcels_centroids(gdf_parcels):
    C = gdf_parcels.copy(); C["eov_x"] = C.geometry.centroid.x; C["eov_y"] = C.geometry.centroid.y
    return C[["parcel_id","eov_x","eov_y"]]

def streets_axes_pca(gdf_streets):
    rows = []
    for _, row in gdf_streets.iterrows():
        geom = row.geometry
        try:
            xs, ys = geom.exterior.coords.xy
            import numpy as np
            X = np.c_[np.array(xs), np.array(ys)]
            if X.shape[0] < 3: continue
            mu = X.mean(axis=0); X0 = X - mu
            U, S, VT = np.linalg.svd(X0, full_matrices=False)
            dirv = VT[0]
            rows.append({"street_code": row["street_code"], "street_name": row.get("street_name", None),
                         "cx": float(mu[0]), "cy": float(mu[1]), "dir_x": float(dirv[0]), "dir_y": float(dirv[1])})
        except Exception: continue
    return pd.DataFrame(rows)

def frontage_points_from_polygons(gdf_parcels, gdf_streets, buffer_m=20.0):
    from shapely.ops import nearest_points
    from shapely.strtree import STRtree
    P = gdf_parcels.copy(); S = gdf_streets.copy()
    P["boundary"] = P.geometry.boundary; S["boundary"] = S.geometry.boundary
    treeS = STRtree(S["boundary"].values.tolist())
    out = []
    for i, pb in enumerate(P["boundary"].values):
        cand = treeS.query(pb.buffer(buffer_m))
        for sb in cand or []:
            p = nearest_points(pb, sb)[0]
            out.append({"parcel_id": P.iloc[i]["parcel_id"], "eov_x": p.x, "eov_y": p.y})
    return pd.DataFrame(out).drop_duplicates()
