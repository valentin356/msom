# HU EOV Geocoder – Cadastre-ready (poligon parcellák & utcák)
Build: 2025-10-16T10:17:47.665941Z

## Fő funkciók
- Vektoros, gyors geokódolás (merge_asof, int64 kulcs).
- Gráf/élek (házzszám-bracket), aktivációs maszk, COG diagnosztika.
- Cadastre: poligon parcellák és poligon utcák, centroid, PCA tengely, frontage pontok.
- Frontage-snap opció geokód közben.
- Tqdm progress és részletes logok.

## Példa parancsok
seed:      python seed_base.py --input alap.xlsx --schema schemas/schema.json --store ./store --parcels parcella.shp --streets utcak.shp
update:    python update_base.py --input friss.parquet --schema schemas/schema.json --store ./store --parcels parcella_uj.shp --streets utcak_uj.shp
geocode:   python geocode_batch.py --store ./store --schema schemas/schema.json --targets geokodolandok.xlsx --out-csv geokodolt.csv --use-frontage
