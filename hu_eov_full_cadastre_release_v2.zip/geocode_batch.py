import os, re, time, argparse, numpy as np, pandas as pd
from hu_eov_rg.io_any import load_any_table
from hu_eov_rg.io_parquet_cfg import normalize_df_with_schema
from hu_eov_rg.coords import ensure_eov_coords
from hu_eov_rg.eov_raster import RasterIndexEOV
from hu_eov_rg.fast_geocode import geocode_vectorized
from hu_eov_rg.logging_utils import setup_logging, get_logger

def find_latest_version(bases_dir):
    vs = []
    for fn in os.listdir(bases_dir):
        m = re.match(r"V(\d+)\.parquet$", fn)
        if m: vs.append(int(m.group(1)))
    v = max(vs) if vs else None
    return v

def main():
    ap = argparse.ArgumentParser(description="Batch geokódolás (vektoros, cadastre frontage-snap opcióval).")
    ap.add_argument("--store", required=True); ap.add_argument("--schema", required=True)
    ap.add_argument("--targets", required=True); ap.add_argument("--out-csv", required=True)
    ap.add_argument("--base-res-m", type=float, default=2048.0); ap.add_argument("--max-level", type=int, default=11)
    ap.add_argument("--activation-level", type=int, default=10)
    ap.add_argument("--use-frontage", action="store_true")
    args = ap.parse_args()
    os.makedirs(os.path.join(args.store, "logs"), exist_ok=True)
    log_path = os.path.join(args.store, "logs", f"geocode_batch_{int(time.time())}.log")
    setup_logging(log_path); log = get_logger(__name__)
    v = find_latest_version(os.path.join(args.store, "bases"))
    if not v: raise SystemExit("Nincs base a store-ban. Futtasd az ősfeltöltést (seed_base.py).")
    base_path = os.path.join(args.store, "bases", f"V{v}.parquet")
    base = pd.read_parquet(base_path)
    if "eov_x" not in base.columns or "eov_y" not in base.columns:
        base = base.rename(columns={"EOV_Y":"eov_x","EOV_X":"eov_y"})
    base["has_coords"] = base["eov_x"].notna() & base["eov_y"].notna()
    r = RasterIndexEOV(base_res_m=args.base_res_m, max_level=args.max_level)
    r.ingest_df(base)
    if r.x0 is None or r.y0 is None: r.fit_origin_from_df(r.addr_df)
    r.build_cells_from_coords(); r.build_graph(sparse_gap_m=200.0)
    targ_raw = load_any_table(args.targets); targ_raw = ensure_eov_coords(targ_raw)
    targ = normalize_df_with_schema(targ_raw, args.schema)
    res = geocode_vectorized(base, r.graph.edges, targ)
    out = targ.copy()
    provided = out["eov_x"].notna() & out["eov_y"].notna()
    out.loc[provided, "GEOCODE_SOURCE"] = "provided"; out.loc[provided, "GEOCODE_ERROR_M"] = 0.0
    fill = ~provided
    out.loc[fill, "eov_x"] = res.loc[fill, "eov_x"]; out.loc[fill, "eov_y"] = res.loc[fill, "eov_y"]
    out.loc[fill, "GEOCODE_SOURCE"] = res.loc[fill, "GEOCODE_SOURCE"]; out.loc[fill, "GEOCODE_ERROR_M"] = res.loc[fill, "GEOCODE_ERROR_M"]
    try:
        L = int(args.activation_level)
        resm = args.base_res_m / (2**L)
        xi = np.floor((out["eov_x"] - r.x0) / resm).astype("Int64")
        yi = np.floor((out["eov_y"] - r.y0) / resm).astype("Int64")
        out["xi"] = xi; out["yi"] = yi
        act_path = os.path.join(args.store, "rasters", f"V{v}", f"activation_L{L}.parquet")
        if os.path.exists(act_path):
            act = pd.read_parquet(act_path)[["xi","yi"]].drop_duplicates(); act["active"] = True
            out = out.merge(act, how="left", on=["xi","yi"])
            mask_block = out["active"].isna() & (out["GEOCODE_SOURCE"]=="interpolated")
            if mask_block.any():
                anchors = base[base["has_coords"]].copy()
                anchors["base_num"] = pd.to_numeric(anchors["house_number"].astype(str).str.extract(r"(\d+)")[0], errors="coerce")
                anchors = anchors.dropna(subset=["base_num"])
                anchors["parity"] = np.where((anchors["base_num"] % 2 == 0), "even", "odd")
                anchors["base_num"] = anchors["base_num"].astype(int)
                for c in ["settlement","street","parity"]: anchors[c] = anchors[c].astype("string")
                anchors.sort_values(["settlement","street","parity","base_num"], inplace=True)
                B = out.loc[mask_block, ["settlement","street","parity","house_number"]].copy()
                B["base_num"] = pd.to_numeric(B["house_number"].astype(str).str.extract(r"(\d+)")[0], errors="coerce").astype("Int64")
                lo_b = pd.merge_asof(
                    B.sort_values(["settlement","street","parity","base_num"]),
                    anchors[["settlement","street","parity","base_num","eov_x","eov_y"]].rename(columns={"eov_x":"x_lo","eov_y":"y_lo"}),
                    by=["settlement","street","parity"], on="base_num", direction="backward", allow_exact_matches=True
                ).loc[B.index]
                hi_b = pd.merge_asof(
                    B.sort_values(["settlement","street","parity","base_num"]),
                    anchors[["settlement","street","parity","base_num","eov_x","eov_y"]].rename(columns={"eov_x":"x_hi","eov_y":"y_hi"}),
                    by=["settlement","street","parity"], on="base_num", direction="forward", allow_exact_matches=True
                ).loc[B.index]
                bn_b = B["base_num"].astype("Int64")
                d_lo = (bn_b - lo_b["base_num"]).abs(); d_hi = (hi_b["base_num"] - bn_b).abs()
                use_lo = d_lo.fillna(np.inf) <= d_hi.fillna(np.inf)
                new_x = np.where(use_lo, lo_b["x_lo"], hi_b["x_hi"]); new_y = np.where(use_lo, lo_b["y_lo"], hi_b["y_hi"])
                out.loc[mask_block, "eov_x"] = new_x; out.loc[mask_block, "eov_y"] = new_y
                out.loc[mask_block, "GEOCODE_SOURCE"] = "anchor-no-interp"; out.loc[mask_block, "GEOCODE_ERROR_M"] = 100.0
            if "active" in out.columns: out.drop(columns=["active"], inplace=True)
    except Exception as e:
        log = get_logger(__name__); log.warning(f"Aktivációs ellenőrzés kihagyva: {e}")
    if args.use_frontage:
        fp_path = os.path.join(args.store, "cadastre", f"V{v}", "frontage_points.parquet")
        if os.path.exists(fp_path):
            try:
                fp = pd.read_parquet(fp_path)
                maybe = out["GEOCODE_SOURCE"].isin(["interpolated","street-centroid"]) 
                if maybe.any() and len(fp):
                    from scipy.spatial import cKDTree
                    tree = cKDTree(fp[["eov_x","eov_y"]].to_numpy())
                    q = out.loc[maybe, ["eov_x","eov_y"]].to_numpy()
                    d, idxs = tree.query(q, k=1, workers=-1)
                    pts = fp[["eov_x","eov_y"]].to_numpy()[idxs]
                    out.loc[maybe, "eov_x"] = pts[:,0]; out.loc[maybe, "eov_y"] = pts[:,1]
                    out.loc[maybe, "GEOCODE_SOURCE"] = out.loc[maybe, "GEOCODE_SOURCE"].where(out.loc[maybe,"GEOCODE_SOURCE"]=="street-centroid","interpolated-frontage")
                    out.loc[maybe, "GEOCODE_ERROR_M"] = np.minimum(out.loc[maybe, "GEOCODE_ERROR_M"].fillna(100.0), 30.0)
            except Exception as e:
                log = get_logger(__name__); log.warning(f"Frontage snap kihagyva: {e}")
    out["EOV_Y"] = out["eov_x"]; out["EOV_X"] = out["eov_y"]
    out.to_csv(args.out_csv, index=False, encoding="utf-8"); print(f"Mentve: {args.out_csv}")
if __name__ == "__main__": main()
