# DRIFT — Discrete Routing In-Field Transduction (Sentinel-2)

- Unlabeled representation + discrete routing quantizer + CRF refinement
- **GDAL-only** IO, JP2 via `/vsizip/`
- **Nearest neighbor** resampling
- **NEW:** Early **clipping/alignment to reference.tif** using `--ref`

## Quickstart
pip install -r requirements.txt

python scripts/preprocess_s2.py --zip /path/S2*_L2A_*.zip --out data/s2_stack.tif --ref data/reference.tif
python scripts/train_drift.py --stack data/s2_stack.tif --epochs 2 --tile 256
python scripts/infer_drift.py --stack data/s2_stack.tif --weights models/drift.ckpt --out_prefix output/run1_
