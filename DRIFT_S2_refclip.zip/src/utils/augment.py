import torch, numpy as np
def random_block_mask(x,mask_ratio=0.75,block=8):
    B,C,H,W=x.shape; m=torch.zeros((B,1,H,W),device=x.device)
    n=int((H*W*mask_ratio)/(block*block))
    for b in range(B):
        for _ in range(n):
            i=np.random.randint(0,max(1,H-block+1)); j=np.random.randint(0,max(1,W-block+1))
            m[b,0,i:i+block,j:j+block]=1.0
    return x*(1-m), m
def normalize_minmax(x,eps=1e-6):
    xmin=x.amin(dim=(2,3),keepdim=True); xmax=x.amax(dim=(2,3),keepdim=True)
    return (x-xmin)/(xmax-xmin+eps)
