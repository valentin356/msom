def tiles_for_size(H,W,tile=256,overlap=32):
    ys=list(range(0,H,tile-overlap)); xs=list(range(0,W,tile-overlap))
    if ys[-1]+tile<H: ys.append(H-tile)
    if xs[-1]+tile<W: xs.append(W-tile)
    ys=[max(0,min(y,H-tile)) for y in ys]; xs=[max(0,min(x,W-tile)) for x in xs]
    tiles=[]
    for y in dict.fromkeys(ys):
        for x in dict.fromkeys(xs): tiles.append((y,x,tile,tile))
    return tiles
