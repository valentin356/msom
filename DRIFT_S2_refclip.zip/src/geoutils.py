import numpy as np
from osgeo import gdal

def open_gdal(path):
    ds=gdal.Open(path,gdal.GA_ReadOnly)
    if ds is None: raise RuntimeError(f'Cannot open: {path}')
    return ds

def create_like(ref_ds,out_path,bands,dtype=gdal.GDT_Float32,compress='LZW'):
    drv=gdal.GetDriverByName('GTiff')
    x=ref_ds.RasterXSize; y=ref_ds.RasterYSize
    gt=ref_ds.GetGeoTransform(); prj=ref_ds.GetProjection()
    dst=drv.Create(out_path,x,y,bands,dtype,options=['TILED=YES','COMPRESS='+compress,'BIGTIFF=IF_SAFER'])
    dst.SetGeoTransform(gt); dst.SetProjection(prj)
    return dst

def write_array_like(ref_ds,out_path,array,dtype=gdal.GDT_Float32,compress='LZW',nodata=None):
    import numpy as np
    if array.ndim==2: array=array[None,...]
    dst=create_like(ref_ds,out_path,array.shape[0],dtype,compress)
    for i in range(array.shape[0]):
        b=dst.GetRasterBand(i+1); b.WriteArray(array[i]);
        if nodata is not None: b.SetNoDataValue(nodata)
        b.FlushCache()
    dst.FlushCache(); dst=None

def reproject_near(src_path, ref_ds, out_path='/vsimem/tmp_warp.tif'):
    gt=ref_ds.GetGeoTransform(); x=ref_ds.RasterXSize; y=ref_ds.RasterYSize
    minx=gt[0]; maxy=gt[3]; maxx=minx+x*gt[1]; miny=maxy+y*gt[5]
    opts=gdal.WarpOptions(format='GTiff', outputBounds=(minx,miny,maxx,maxy), width=x, height=y,
        dstSRS=ref_ds.GetProjection(), resampleAlg=gdal.GRA_NearestNeighbour, targetAlignedPixels=True, multithread=True,
        xRes=abs(gt[1]), yRes=abs(gt[5]))
    out=gdal.Warp(out_path, src_path, options=opts)
    if out is None: raise RuntimeError('gdal.Warp failed')
    out.FlushCache(); out=None
    return out_path
