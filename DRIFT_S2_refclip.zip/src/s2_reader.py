import re, zipfile
import numpy as np
from osgeo import gdal
from .geoutils import open_gdal, reproject_near, write_array_like

S2_BANDS=['B01','B02','B03','B04','B05','B06','B07','B08','B8A','B09','B10','B11','B12']

def list_zip_members(zip_path):
    with zipfile.ZipFile(zip_path,'r') as z: return z.namelist()

def best_band_files(zip_path):
    mem=list_zip_members(zip_path)
    pat=re.compile(r'.*GRANULE/.*/IMG_DATA/(R10m|R20m|R60m)/.*_(B0[1-9]|B1[0-2]|B8A)_(10m|20m|60m)\.jp2$',re.IGNORECASE)
    cand={}
    for m in mem:
        if not m.lower().endswith('.jp2'): continue
        if 'IMG_DATA' not in m: continue
        mm=pat.match(m)
        if not mm: continue
        band=mm.group(2).upper(); res=int(mm.group(3).replace('m',''))
        vsi=f'/vsizip/{zip_path}/{m}'
        if (band not in cand) or (res < cand[band][1]): cand[band]=(vsi,res)
    return cand

def pick_reference_10m(cand):
    for b in ['B04','B03','B02','B08']:
        if b in cand and cand[b][1]==10: return cand[b][0]
    best=None
    for b,(p,r) in cand.items():
        if (best is None) or (r<best[1]): best=(p,r)
    return best[0]

def build_stack(zip_path,out_stack_path,wanted_bands=None,scale_to_reflectance=True,ref_override_path=None):
    if wanted_bands is None: wanted_bands=S2_BANDS
    cand=best_band_files(zip_path)
    if not cand: raise RuntimeError('No bands found in ZIP')
    if ref_override_path is not None:
        ref_ds=open_gdal(ref_override_path)
    else:
        ref_ds=open_gdal(pick_reference_10m(cand))
    arrays=[]; names=[]
    for band in wanted_bands:
        if band not in cand: continue
        src_path,_=cand[band]
        tmp=reproject_near(src_path, ref_ds, out_path=f'/vsimem/tmp_{band}.tif')
        ds=open_gdal(tmp)
        arr=ds.ReadAsArray().astype(np.float32)
        if scale_to_reflectance:
            arr = arr/10000.0; arr[arr<0]=0; arr[arr>1]=1
        arrays.append(arr); names.append(band); ds=None
    if not arrays: raise RuntimeError('No wanted bands available')
    stack=np.stack(arrays,axis=0)
    write_array_like(ref_ds,out_stack_path,stack,dtype=gdal.GDT_Float32,compress='LZW')
    return names
