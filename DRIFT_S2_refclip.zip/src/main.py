import argparse
from scripts.preprocess_s2.py import main as preprocess_main
from scripts.train_drift import main as train_main
from scripts.infer_drift import main as infer_main

if __name__=='__main__':
    parser = argparse.ArgumentParser(description='DRIFT pipeline')
    sub = parser.add_subparsers(dest='cmd')
    p0=sub.add_parser('preprocess'); p0.add_argument('--zip',required=True); p0.add_argument('--out',required=True); p0.add_argument('--ref',required=False)
    p1=sub.add_parser('train'); p1.add_argument('--stack',required=True); p1.add_argument('--epochs',type=int,default=2); p1.add_argument('--tile',type=int,default=256)
    p2=sub.add_parser('infer'); p2.add_argument('--stack',required=True); p2.add_argument('--weights',required=True); p2.add_argument('--out_prefix',required=True)
    args=parser.parse_args()
    if args.cmd=='preprocess': preprocess_main(args)
    elif args.cmd=='train': train_main(args)
    elif args.cmd=='infer': infer_main(args)
    else: parser.print_help()
