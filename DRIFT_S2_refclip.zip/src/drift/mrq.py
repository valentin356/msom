import torch
import torch.nn as nn
import torch.nn.functional as F
from ..utils.sinkhorn import sinkhorn_knopp

class Head(nn.Module):
    def __init__(self,dim,K):
        super().__init__(); self.proj=nn.Conv2d(dim,dim,1); self.codes=nn.Parameter(torch.randn(K,dim))
    def forward(self,z):
        q=self.proj(z); B,D,H,W=q.shape; qf=q.permute(0,2,3,1).reshape(B,H*W,D)
        codes=F.normalize(self.codes,dim=1); qn=F.normalize(qf,dim=2)
        logits=torch.einsum('bnd,kd->bnk', qn, codes); return logits, qf

class MRQ(nn.Module):
    def __init__(self,dim,heads,Ks,topk=4,sink_iters=3,sink_eps=0.05):
        super().__init__(); self.heads=nn.ModuleList([Head(dim,K) for K in Ks]); self.topk=topk; self.sink_iters=sink_iters; self.sink_eps=sink_eps
    def forward(self,z):
        outs=[]; qfs=[]
        for h in self.heads:
            lg,qf=h(z); outs.append(lg); qfs.append(qf)
        return outs,qfs
    def balanced_assign(self,logits):
        soft=[]; hard_idx=[]
        for lg in logits:
            P=sinkhorn_knopp(lg,n_iters=self.sink_iters,epsilon=self.sink_eps)
            tk=torch.topk(P,k=min(self.topk,P.shape[-1]),dim=-1); H=torch.zeros_like(P); H.scatter_(-1,tk.indices,1.0)
            hard=H/H.sum(dim=-1,keepdim=True).clamp_min(1e-6); soft.append(P); hard_idx.append(hard.argmax(dim=-1))
        return soft, hard_idx
    def commit_losses(self,qfs,hard_idx,weight=0.25):
        loss=0.0
        for qf,idx,h in zip(qfs,hard_idx,self.heads):
            codes=F.normalize(h.codes,dim=1); qn=F.normalize(qf,dim=2); hard=codes[idx]; loss=loss+weight*F.mse_loss(qn,hard)
        return loss
