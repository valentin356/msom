import numpy as np, torch, torch.nn.functional as F
from ..geoutils import open_gdal, write_array_like
from .m2pt import M2PT
from .mrq import MRQ
from .config import Config
from .crf import meanfield_potts
from osgeo import gdal

def infer(stack_path,weights_path,out_prefix,device='cpu',tile=256,overlap=32):
    ds=open_gdal(stack_path); C=ds.RasterCount; H=ds.RasterYSize; W=ds.RasterXSize
    ckpt=torch.load(weights_path,map_location='cpu')
    model=M2PT(in_ch=C,dim=Config.embed_dim).to(device)
    quant=MRQ(dim=Config.embed_dim,heads=Config.code_heads,Ks=Config.codebook_sizes,topk=Config.topk,sink_iters=Config.sinkhorn_iters,sink_eps=Config.sinkhorn_eps).to(device)
    model.load_state_dict(ckpt['m2pt'],strict=False); quant.load_state_dict(ckpt['mrq'],strict=False); model.eval()
    labels=np.zeros((H,W),dtype=np.uint16); prob=np.zeros((H,W),dtype=np.float32); entr=np.zeros((H,W),dtype=np.float32)
    step=tile-overlap; head=0
    for y in range(0,H,step):
        h=min(tile,H-y)
        for x in range(0,W,step):
            w=min(tile,W-x)
            arr=np.stack([ds.GetRasterBand(i+1).ReadAsArray(xoff=x,yoff=y,win_xsize=w,win_ysize=h) for i in range(C)],axis=0).astype(np.float32)
            t=torch.from_numpy(arr[None,...])
            with torch.no_grad():
                z,_=model(t); logits,_=quant(z); lg=logits[head]; B,N,K=lg.shape; lg2d=lg.reshape(1,h,w,K).permute(0,3,1,2)
                Q=F.softmax(lg2d,dim=1); e=-(Q*(Q.clamp_min(1e-6).log())).sum(dim=1); top_p,top_c=Q.max(dim=1)
                labels[y:y+h,x:x+w]=top_c[0].cpu().numpy().astype(np.uint16); prob[y:y+h,x:x+w]=top_p[0].cpu().numpy(); entr[y:y+h,x:x+w]=e[0].cpu().numpy()
    write_array_like(ds,out_prefix+'codes.tif',labels,dtype=gdal.GDT_UInt16); write_array_like(ds,out_prefix+'prob.tif',prob,dtype=gdal.GDT_Float32); write_array_like(ds,out_prefix+'entropy.tif',entr,dtype=gdal.GDT_Float32)
    labels_crf=np.zeros_like(labels,dtype=np.uint16)
    for y in range(0,H,step):
        h=min(tile,H-y)
        for x in range(0,W,step):
            w=min(tile,W-x)
            arr=np.stack([ds.GetRasterBand(i+1).ReadAsArray(xoff=x,yoff=y,win_xsize=w,win_ysize=h) for i in range(C)],axis=0).astype(np.float32)
            t=torch.from_numpy(arr[None,...])
            with torch.no_grad():
                z,_=model(t); logits,_=quant(z); lg=logits[head]; B,N,K=lg.shape; lg2d=lg.reshape(1,h,w,K).permute(0,3,1,2)
                Q=meanfield_potts(lg2d,None,weight=Config.crf_weight,iters=Config.crf_iters); top_p,top_c=Q.max(dim=1)
                labels_crf[y:y+h,x:x+w]=top_c[0].cpu().numpy().astype(np.uint16)
    write_array_like(ds,out_prefix+'labels_crf.tif',labels_crf,dtype=gdal.GDT_UInt16)
    import numpy as np
    thr=np.quantile(entr,0.25); conf=(entr<=thr).astype(np.uint8); write_array_like(ds,out_prefix+'confmask.tif',conf,dtype=gdal.GDT_Byte)
    return True
