import argparse, os, sys, numpy as np
from osgeo import gdal
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from src.s2_reader import build_stack
from src.geoutils import open_gdal, write_array_like

def compute_indices(stack_path, band_names, out_prefix):
    ds=open_gdal(stack_path)
    arrs=[ds.GetRasterBand(i+1).ReadAsArray().astype(np.float32) for i in range(ds.RasterCount)]
    data=dict(zip(band_names,arrs))
    if 'B08' in data and 'B04' in data:
        ndvi=(data['B08']-data['B04'])/(data['B08']+data['B04']+1e-6)
        write_array_like(ds,out_prefix+'ndvi.tif',ndvi,dtype=gdal.GDT_Float32)
    if 'B03' in data and 'B08' in data:
        ndwi=(data['B03']-data['B08'])/(data['B03']+data['B08']+1e-6)
        write_array_like(ds,out_prefix+'ndwi.tif',ndwi,dtype=gdal.GDT_Float32)
    if 'B11' in data and 'B08' in data:
        ndbi=(data['B11']-data['B08'])/(data['B11']+data['B08']+1e-6)
        write_array_like(ds,out_prefix+'ndbi.tif',ndbi,dtype=gdal.GDT_Float32)

def main(ns=None):
    p=argparse.ArgumentParser(); p.add_argument('--zip',required=True); p.add_argument('--out',required=True); p.add_argument('--ref',required=False,help='Reference GeoTIFF for early clip/align')
    args=p.parse_args() if ns is None else ns
    os.makedirs(os.path.dirname(args.out),exist_ok=True)
    bands=build_stack(args.zip,args.out,ref_override_path=args.ref)
    print('Saved stack:',args.out,'bands:',bands)
    out_prefix=os.path.join(os.path.dirname(args.out),'')
    compute_indices(args.out,bands,out_prefix)

if __name__=='__main__':
    main()
