import argparse, os, sys, torch
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from src.drift.inference import infer
def main(ns=None):
    p=argparse.ArgumentParser(); p.add_argument('--stack',required=True); p.add_argument('--weights',required=True); p.add_argument('--out_prefix',required=True); p.add_argument('--tile',type=int,default=256); p.add_argument('--overlap',type=int,default=32)
    args=p.parse_args() if ns is None else ns
    device='cuda' if torch.cuda.is_available() else 'cpu'
    os.makedirs(os.path.dirname(args.out_prefix),exist_ok=True)
    infer(args.stack,args.weights,args.out_prefix,device=device,tile=args.tile,overlap=args.overlap)
if __name__=='__main__': main()
