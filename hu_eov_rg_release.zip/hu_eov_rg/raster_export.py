import os, json, time, logging
import numpy as np
import pandas as pd
from .progress import pbar

log = logging.getLogger(__name__)

def _ensure_dir(p): os.makedirs(p, exist_ok=True); return p

def _grid_extent_from_points(df: pd.DataFrame, x0: float, y0: float, level: int, base_res_m: float):
    res = base_res_m / (2**level)
    xs = ((df["eov_x"] - x0) / res).to_numpy()
    ys = ((df["eov_y"] - y0) / res).to_numpy()
    if xs.size == 0 or ys.size == 0:
        return res, 0, 0, 1, 1
    xi_min = int(np.floor(np.nanmin(xs))); xi_max = int(np.ceil(np.nanmax(xs)))
    yi_min = int(np.floor(np.nanmin(ys))); yi_max = int(np.ceil(np.nanmax(ys)))
    width = max(1, xi_max - xi_min + 1); height = max(1, yi_max - yi_min + 1)
    return res, xi_min, yi_min, width, height

def _grid_centers(x0, y0, res, xi_min, yi_min, width, height):
    xs = x0 + (np.arange(xi_min, xi_min+width) + 0.5) * res
    ys = y0 + (np.arange(yi_min, yi_min+height) + 0.5) * res
    X, Y = np.meshgrid(xs, ys)  # [H,W]
    return X, Y

def _nearest_distance_grid(anchors_xy: np.ndarray, X: np.ndarray, Y: np.ndarray):
    if anchors_xy.size == 0: 
        return np.full_like(X, np.nan, dtype=float)
    try:
        from scipy.spatial import cKDTree
        tree = cKDTree(anchors_xy)
        coords = np.c_[X.reshape(-1), Y.reshape(-1)]
        dist, _ = tree.query(coords, k=1, workers=-1)
        return dist.reshape(X.shape)
    except Exception:
        pass
    H, W = X.shape
    out = np.empty((H,W), dtype=float)
    for i in pbar(range(H), desc="nearest rows", leave=False):
        xi_row = X[i, :]; yi_row = Y[i, :]
        min_d2 = np.full(W, np.inf, dtype=float)
        chunk = 4096
        n = anchors_xy.shape[0]
        for s in range(0, n, chunk):
            block = anchors_xy[s:s+chunk]
            dx = xi_row[None,:] - block[:,0:1]
            dy = yi_row[None,:] - block[:,1:2]
            d2 = (dx*dx + dy*dy)
            md2 = d2.min(axis=0)
            min_d2 = np.minimum(min_d2, md2)
        out[i,:] = np.sqrt(min_d2)
    return out

def _tile_counts(df: pd.DataFrame, x0, y0, level, base_res_m):
    res = base_res_m / (2**level)
    if df.empty: return np.zeros((1,1), dtype=int), 0, 0, res
    xi = np.floor((df["eov_x"].to_numpy() - x0)/res).astype(int)
    yi = np.floor((df["eov_y"].to_numpy() - y0)/res).astype(int)
    xi0, yi0 = xi.min(), yi.min(); W = xi.max()-xi0+1; H = yi.max()-yi0+1
    grid = np.zeros((H, W), dtype=int)
    for a,b in zip(yi-yi0, xi-xi0): grid[a,b] += 1
    return grid, xi0, yi0, res

def _save_png(arr: np.ndarray, path: str):
    try:
        import matplotlib.pyplot as plt
    except Exception:
        log.debug("matplotlib not available, skipping PNG export")
        return None
    plt.figure(); plt.imshow(arr, origin="upper"); plt.axis("off")
    plt.savefig(path, bbox_inches="tight", pad_inches=0); plt.close()
    return path

def _save_tif(arr: np.ndarray, path: str, x0: float, y0: float, xi0: int, yi0: int, res: float, crs="EPSG:23700"):
    try:
        import rasterio
        from rasterio.transform import Affine
    except Exception:
        log.debug("rasterio not available, skipping GeoTIFF export")
        return None
    x_min = x0 + xi0 * res
    y_max = y0 + (yi0 + arr.shape[0]) * res
    transform = Affine(res, 0, x_min, 0, -res, y_max)
    nodata = -9999.0 if arr.dtype.kind == "f" else (65535 if arr.dtype == np.uint16 else 255)
    data = arr
    with rasterio.open(path, "w", driver="GTiff", height=data.shape[0], width=data.shape[1], count=1,
                       dtype=data.dtype, crs=crs, transform=transform, nodata=nodata) as dst:
        dst.write(data, 1)
    return path

def _quantize(arr: np.ndarray, kind: str, max_dist_m: int=5000, density_max: int=65535):
    if kind == "nearest_dist":
        a = np.clip(arr, 0, max_dist_m)
        return a.astype(np.uint16), "uint16", 1.0, 0.0, 2
    if kind in ("edge_gap_median", "density"):
        a = np.clip(arr, 0, density_max)
        return a.astype(np.uint16), "uint16", 1.0, 0.0, 2
    if kind == "interp_allowed_fraction":
        a = np.rint(np.clip(arr, 0, 1) * 255.0).astype(np.uint8)
        return a, "uint8", 1/255.0, 0.0, 2
    return arr.astype(np.float32), "float32", 1.0, 0.0, 3

def _save_cog(arr: np.ndarray, path: str, x0: float, y0: float, xi0: int, yi0: int, res: float,
              crs="EPSG:23700", dtype="uint16", scale=1.0, offset=0.0, predictor=2,
              block=512, overviews=(2,4,8,16), compress="ZSTD", zstd_level=9):
    try:
        import rasterio
        from rasterio.transform import Affine
        from rasterio.enums import Resampling
    except Exception:
        return None
    x_min = x0 + xi0 * res
    y_max = y0 + (yi0 + arr.shape[0]) * res
    transform = Affine(res, 0, x_min, 0, -res, y_max)
    nodata = 255 if dtype == "uint8" else (65535 if dtype == "uint16" else -9999.0)
    data = arr
    profile = dict(driver="GTiff",
                   height=int(data.shape[0]), width=int(data.shape[1]), count=1,
                   dtype=str(dtype),
                   crs=crs, transform=transform,
                   tiled=True, blockxsize=int(block), blockysize=int(block),
                   compress=compress, predictor=int(predictor),
                   BIGTIFF="YES")
    if compress == "DEFLATE":
        profile["zlevel"] = 9
    elif compress == "ZSTD":
        profile["zstd_level"] = int(zstd_level)
    with rasterio.open(path, "w", **profile) as dst:
        dst.write(data, 1)
        try:
            dst.update_tags(1, SCALE=str(scale), OFFSET=str(offset))
        except Exception:
            pass
        try:
            if overviews:
                dst.build_overviews(list(overviews), Resampling.average)
                dst.update_tags(ns='rio_overview', resampling='average')
        except Exception:
            pass
    return path

def _save_layer_optimized(name: str, arr: np.ndarray, out_dir: str, L: int, xi0: int, yi0: int, meta_acc: dict,
                          export_csv=False, export_png=False, export_tif=True,
                          quantize=True, q_params=None, cog=True):
    if q_params is None: q_params = {}
    kind = name
    if quantize:
        qdata, dtype, scale, offset, predictor = _quantize(arr, kind, **q_params)
    else:
        qdata, dtype, scale, offset, predictor = arr.astype(np.float32), "float32", 1.0, 0.0, 3
    stem = f"{name}_L{L}"
    os.makedirs(out_dir, exist_ok=True)
    out = {}
    if export_tif:
        tif = os.path.join(out_dir, stem + ".tif")
        if cog:
            _save_cog(qdata, tif, meta_acc["x0"], meta_acc["y0"], xi0, yi0, meta_acc["res"],
                      dtype=dtype, scale=scale, offset=offset, predictor=predictor)
        else:
            _save_tif(qdata, tif, meta_acc["x0"], meta_acc["y0"], xi0, yi0, meta_acc["res"])
        out["tif"] = tif
    if export_csv:
        np.savetxt(os.path.join(out_dir, stem + ".csv"), arr, fmt="%.3f", delimiter=",")
    if export_png:
        _save_png(arr, os.path.join(out_dir, stem + ".png"))
    with open(os.path.join(out_dir, stem + ".meta.json"), "w", encoding="utf-8") as f:
        json.dump({"xi0":int(xi0),"yi0":int(yi0),"res":float(meta_acc["res"]),"level":int(L),
                   "dtype": dtype, "scale": scale, "offset": offset}, f, ensure_ascii=False, indent=2)
    return out

def export_rasters(base_df: pd.DataFrame, edges_df: pd.DataFrame, out_dir: str, base_res_m: float, x0: float, y0: float, levels=(7,10),
                   export_csv=False, export_png=False, export_tif=True, quantize=True,
                   max_dist_m=5000, density_max=65535):
    _ensure_dir(out_dir)
    anchors = base_df[base_df["has_coords"]][["eov_x","eov_y"]].dropna()
    pts = anchors.to_numpy()
    out_paths = {}; errors = []
    log.info(f"Export raszterek indulnak: levels={levels}, anchors={len(anchors)}")
    for L in pbar(levels, desc="levels"):
        t0 = time.perf_counter()
        try:
            den_grid, den_xi0, den_yi0, den_res = _tile_counts(anchors, x0, y0, L, base_res_m)
            out_paths[f"density_L{L}"] = _save_layer_optimized('density', den_grid, out_dir, L, den_xi0, den_yi0, {'x0':x0,'y0':y0,'res':den_res},
                                                               export_csv=export_csv, export_png=export_png, export_tif=export_tif,
                                                               quantize=quantize, q_params={'max_dist_m': max_dist_m, 'density_max': density_max})
            log.info(f"[L{L}] density grid {den_grid.shape} ok")
        except Exception as e:
            errors.append(f"density_L{L}: {e}"); log.exception(f"density_L{L} failed")
        try:
            res2, xi_min, yi_min, width, height = _grid_extent_from_points(anchors, x0, y0, L, base_res_m)
            X, Y = _grid_centers(x0, y0, res2, xi_min, yi_min, width, height)
            dist_grid = _nearest_distance_grid(pts, X, Y)
            out_paths[f"nearest_dist_L{L}"] = _save_layer_optimized('nearest_dist', dist_grid, out_dir, L, xi_min, yi_min, {'x0':x0,'y0':y0,'res':res2},
                                                                    export_csv=export_csv, export_png=export_png, export_tif=export_tif,
                                                                    quantize=quantize, q_params={'max_dist_m': max_dist_m, 'density_max': density_max})
            log.info(f"[L{L}] nearest_dist grid {dist_grid.shape} ok")
        except Exception as e:
            errors.append(f"nearest_dist_L{L}: {e}"); log.exception(f"nearest_dist_L{L} failed")
        if edges_df is not None and not edges_df.empty:
            try:
                ex = (edges_df["x_lo"].to_numpy() + edges_df["x_hi"].to_numpy())/2.0
                ey = (edges_df["y_lo"].to_numpy() + edges_df["y_hi"].to_numpy())/2.0
                resE = base_res_m / (2**L)
                xi = np.floor((ex - x0)/resE).astype(int); yi = np.floor((ey - y0)/resE).astype(int)
                if xi.size:
                    xi0, yi0 = xi.min(), yi.min(); W = xi.max()-xi0+1; H = yi.max()-yi0+1
                else:
                    xi0, yi0, W, H = 0,0,1,1
                gap_grid = np.full((H,W), np.nan, dtype=float)
                fr_grid  = np.full((H,W), np.nan, dtype=float)
                from collections import defaultdict
                gaps = defaultdict(list); frs = defaultdict(list)
                for i in pbar(range(len(xi)), desc=f"edges L{L}", leave=False):
                    key = (yi[i]-yi0, xi[i]-xi0)
                    gaps[key].append(float(edges_df["gap_m"].iloc[i]))
                    frs[key].append(1.0 if bool(edges_df["interp_allowed"].iloc[i]) else 0.0)
                for (ri,ci), vals in gaps.items():
                    gap_grid[ri,ci] = float(np.nanmedian(vals))
                    fr_grid[ri,ci]  = float(np.nanmean(frs[(ri,ci)]))
                out_paths[f"edge_gap_median_L{L}"] = _save_layer_optimized('edge_gap_median', gap_grid, out_dir, L, xi0, yi0, {'x0':x0,'y0':y0,'res':resE},
                                                                           export_csv=export_csv, export_png=export_png, export_tif=export_tif,
                                                                           quantize=quantize, q_params={'max_dist_m': max_dist_m, 'density_max': density_max})
                out_paths[f"interp_allowed_fraction_L{L}"] = _save_layer_optimized('interp_allowed_fraction', fr_grid, out_dir, L, xi0, yi0, {'x0':x0,'y0':y0,'res':resE},
                                                                                   export_csv=export_csv, export_png=export_png, export_tif=export_tif,
                                                                                   quantize=quantize, q_params={'max_dist_m': max_dist_m, 'density_max': density_max})
                log.info(f"[L{L}] edge raszterek ok")
            except Exception as e:
                errors.append(f"edge_layers_L{L}: {e}"); log.exception(f"edge_layers_L{L} failed")
        dt = time.perf_counter()-t0
        log.info(f"[L{L}] kész {dt:.2f}s alatt")
    if errors:
        with open(os.path.join(out_dir, "export_errors.log"), "w", encoding="utf-8") as f:
            f.write("\n".join(errors))
        log.warning(f"Export raszterek hibák: {len(errors)} bejegyzés az export_errors.log-ban")
    return out_paths

def export_diagnostics(base_df: pd.DataFrame, edges_df: pd.DataFrame, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    summary = {"rows_total": int(len(base_df)),
               "rows_with_coords": int(base_df["has_coords"].sum()) if "has_coords" in base_df.columns else None}
    if edges_df is not None and not edges_df.empty:
        summary["edge_gap_m_median"] = float(np.nanmedian(edges_df["gap_m"].to_numpy()))
        summary["interp_allowed_fraction_mean"] = float(np.nanmean(edges_df["interp_allowed"].astype(float).to_numpy()))
    else:
        summary["edge_gap_m_median"] = None
        summary["interp_allowed_fraction_mean"] = None
    with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    log.info(f"Diagnostics saved to {out_dir}")
    return summary

def _load_sidecar(dir_path: str, stem: str):
    path = os.path.join(dir_path, stem + ".meta.json")
    if not os.path.exists(path): return None
    with open(path, "r", encoding="utf-8") as f: return json.load(f)

def export_diffs(prev_dir: str, curr_dir: str, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    diffs = {}
    prev_files = [fn for fn in os.listdir(prev_dir) if fn.endswith(".csv")]
    for fn in pbar(prev_files, desc="diff raszterek"):
        stem = fn[:-4]; p_prev = os.path.join(prev_dir, fn); p_curr = os.path.join(curr_dir, fn)
        if not os.path.exists(p_curr): 
            log.debug(f"skip diff for {fn}, missing current")
            continue
        A = np.loadtxt(p_prev, delimiter=","); B = np.loadtxt(p_curr, delimiter=",")
        H = min(A.shape[0], B.shape[0]); W = min(A.shape[1], B.shape[1])
        D = B[:H,:W] - A[:H,:W]
        out_csv = os.path.join(out_dir, stem + "_diff.csv")
        np.savetxt(out_csv, D, fmt="%.3f", delimiter=",")
        png_path = None
        try:
            import matplotlib.pyplot as plt
            plt.figure(); plt.imshow(D, origin="upper"); plt.axis("off")
            png_path = os.path.join(out_dir, stem + "_diff.png")
            plt.savefig(png_path, bbox_inches="tight", pad_inches=0); plt.close()
        except Exception:
            pass
        diffs[stem] = {"csv": out_csv, "png": png_path, "tif": None}
    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(diffs, f, ensure_ascii=False, indent=2)
    log.info(f"Diff raszterek kész: {out_dir}")
    return diffs

def generate_html_report(version_label: str, rasters_dir: str, diag_dir: str, out_html_path: str, prev_version_label: str=None, diffs_dir: str=None):
    layers = []
    for fn in sorted(os.listdir(rasters_dir)):
        if fn.endswith(".png"):
            name = fn[:-4]; csv = os.path.join(rasters_dir, name + ".csv"); tif = os.path.join(rasters_dir, name + ".tif")
            layers.append({"name": name, "png": fn, "csv": os.path.basename(csv) if os.path.exists(csv) else None,
                           "tif": os.path.basename(tif) if os.path.exists(tif) else None})
    summary = {}
    sp = os.path.join(diag_dir, "summary.json")
    if os.path.exists(sp):
        with open(sp, "r", encoding="utf-8") as f: summary = json.load(f)
    diffs = []
    if diffs_dir and os.path.isdir(diffs_dir):
        for fn in sorted(os.listdir(diffs_dir)):
            if fn.endswith("_diff.png"):
                stem = fn[:-4]; diffs.append({"name": stem, "png": fn, "csv": stem + ".csv" if os.path.exists(os.path.join(diffs_dir, stem + ".csv")) else None})
    def _link(path, text): return f'<a href="{path}">{text}</a>' if path and os.path.exists(path) else text
    html = [f"<html><head><meta charset='utf-8'><title>Riport {version_label}</title></head><body>",
            f"<h1>Geokódoló gyorsriport – {version_label}</h1>"]
    if summary: html += ["<h2>Összegző metrikák</h2><ul>"] + [f"<li><b>{k}</b>: {v}</li>" for k,v in summary.items()] + ["</ul>"]
    html.append("<h2>Raszter rétegek</h2>")
    for L in layers:
        html.append(f"<h3>{L['name']}</h3>")
        html.append(f"<p>Letöltés: {_link(os.path.join(rasters_dir, L['csv']) if L['csv'] else None, 'CSV')} | {_link(os.path.join(rasters_dir, L['tif']) if L['tif'] else None, 'GeoTIFF')}</p>")
        html.append(f"<img src='{os.path.join(rasters_dir, L['png'])}' style='max-width:100%;height:auto;border:1px solid #ddd'/>")
    if diffs:
        html.append(f"<h2>Verzióközi különbségek – {prev_version_label} → {version_label}</h2>")
        for D in diffs:
            html.append(f"<h3>{D['name']}</h3>")
            html.append(f"<img src='{os.path.join(diffs_dir, D['png'])}' style='max-width:100%;height:auto;border:1px solid #ddd'/>")
    html.append("</body></html>")
    with open(out_html_path, "w", encoding="utf-8") as f: f.write("\n".join(html))
    log.info(f"HTML riport mentve: {out_html_path}")
    return out_html_path
