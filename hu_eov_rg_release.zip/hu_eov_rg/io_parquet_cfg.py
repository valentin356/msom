import pandas as pd
from .schema_loader import load_schema

def _pick(df: pd.DataFrame, spec, case_insensitive=True):
    if spec is None: return None
    cands = spec if isinstance(spec, list) else [spec]
    cols = list(df.columns)
    if case_insensitive:
        low = {c.lower(): c for c in cols}
        for c in cands:
            if c is None: continue
            k = str(c).lower()
            if k in low: return low[k]
        return None
    else:
        for c in cands:
            if c in cols: return c
        return None

def normalize_df_with_schema(df: pd.DataFrame, schema_path: str) -> pd.DataFrame:
    sch = load_schema(schema_path) or {}
    L = sch.get("levels", {}); C = sch.get("coords", {})
    def col(s): return _pick(df, s, True)
    fields = {}
    for key in ["country","county","settlement","city_district","settlement_part","district","postcode",
                "street_name","street_type","house_number","lot_number","building","staircase","floor","door","subunit","tags"]:
        c = col(L.get(key))
        fields[key] = df[c] if c else None
    eov_x_col = col(C.get("eov_x_col"))
    eov_y_col = col(C.get("eov_y_col"))
    fields["EOV_Y"] = df[eov_x_col] if eov_x_col else None
    fields["EOV_X"] = df[eov_y_col] if eov_y_col else None
    out = pd.DataFrame(fields)
    if (("street_name" in out.columns) and ("street_type" in out.columns) 
        and out["street_name"] is not None and out["street_type"] is not None):
        out["street"] = (out["street_name"].astype(str).str.strip() + " " + out["street_type"].astype(str).str.strip()).str.replace(r"\s+"," ", regex=True)
    else:
        out["street"] = out.get("street_name")
    for c in ["country","county","settlement","city_district","settlement_part","district","postcode","street","street_name","street_type","house_number","lot_number","building","staircase","floor","door","subunit","tags"]:
        if c in out.columns:
            try: out[c] = out[c].astype(str).str.strip()
            except: pass
    out["eov_x"] = out.get("EOV_Y")
    out["eov_y"] = out.get("EOV_X")
    out["has_coords"] = out["eov_x"].notna() & out["eov_y"].notna()
    return out

def load_addresses_from_parquet_with_schema(parquet_path: str, schema_path: str) -> pd.DataFrame:
    df = pd.read_parquet(parquet_path)
    return normalize_df_with_schema(df, schema_path)
