import argparse, os, pandas as pd, math, logging, time
from hu_eov_rg.io_any import load_any_table
from hu_eov_rg.io_parquet_cfg import normalize_df_with_schema
from hu_eov_rg.coords import ensure_eov_coords
from hu_eov_rg.store import find_latest_base_version, save_new_base_version
from hu_eov_rg.raster_export import export_rasters, export_diagnostics, export_diffs, generate_html_report
from hu_eov_rg.logging_utils import setup_logging, get_logger
from hu_eov_rg.progress import pbar

KEY_COLS = ["settlement","street","house_number"]

def _read_meta(store_dir: str):
    meta_path = os.path.join(store_dir, "rasters", "meta.json")
    if os.path.exists(meta_path):
        import json
        with open(meta_path, "r", encoding="utf-8") as f: m = json.load(f)
        return m["base_res_m"], m["x0"], m["y0"], m.get("levels",[7,10])
    return 2048.0, None, None, [7,10]

def _infer_origin(df: pd.DataFrame):
    x0 = float(df["eov_x"].min() - 1000.0); y0 = float(df["eov_y"].min() - 1000.0); return x0, y0

def main():
    ap = argparse.ArgumentParser(description="Frissítés – új base verzió, raszterekkel és diffekkel.")
    ap.add_argument("--input", required=True); ap.add_argument("--schema", required=True); ap.add_argument("--store", required=True)
    ap.add_argument("--export-csv", action="store_true"); ap.add_argument("--export-png", action="store_true")
    ap.add_argument("--no-quantize", action="store_true"); ap.add_argument("--max-dist-m", type=int, default=5000)
    args = ap.parse_args()

    setup_logging(level=logging.INFO); log = get_logger(__name__)
    log.info("Start update")

    v, latest = find_latest_base_version(args.store)
    if not latest: raise SystemExit("Nincs base. Futtasd először a seed_base.py-t.")
    base = pd.read_parquet(latest)

    upd_raw = load_any_table(args.input)
    upd_norm = normalize_df_with_schema(upd_raw, args.schema)
    upd_raw_conv = ensure_eov_coords(upd_raw)
    if ("EOV_X" not in upd_norm.columns or "EOV_Y" not in upd_norm.columns) and ("EOV_X" in upd_raw_conv.columns and "EOV_Y" in upd_raw_conv.columns):
        upd_norm["EOV_X"] = upd_raw_conv["EOV_X"]; upd_norm["EOV_Y"] = upd_raw_conv["EOV_Y"]
    upd_norm["eov_x"] = upd_norm.get("EOV_Y"); upd_norm["eov_y"] = upd_norm.get("EOV_X")
    upd_norm["has_coords"] = upd_norm["eov_x"].notna() & upd_norm["eov_y"].notna()

    base_keyed = base.set_index(KEY_COLS); upd_keyed = upd_norm.set_index(KEY_COLS)
    combined = base_keyed.combine_first(upd_keyed); combined.update(upd_keyed); combined = combined.reset_index()
    new_path = save_new_base_version(args.store, combined, version=(v+1)); log.info(f"Base V{v+1} created: {new_path}")

    base_res_m, x0, y0, levels = _read_meta(args.store)
    if x0 is None or y0 is None: 
        coords_df = combined[combined["has_coords"]]
        x0, y0 = _infer_origin(coords_df if not coords_df.empty else combined)

    df = combined[combined["has_coords"]].copy()
    df["house_number"] = df["house_number"].astype(str)
    df["base_num"] = df["house_number"].str.extract(r"(\d+)").astype(float)
    def _parity_safe(x):
        if pd.isna(x): return None
        try: n=int(x)
        except: return None
        return "even" if n%2==0 else "odd"
    df["parity"] = df["base_num"].apply(_parity_safe)
    edges = []
    for (sett, street, par), g in pbar(df.groupby(["settlement","street","parity"]), desc='build edges groups'):
        g = g.dropna(subset=["base_num"]).sort_values("base_num")
        prev=None
        for _,r in g.iterrows():
            if prev is not None:
                d = math.hypot(r["eov_x"]-prev["eov_x"], r["eov_y"]-prev["eov_y"])
                tanya_flag = any(("tanya" in str(v).lower()) for v in [prev.get("tags",""), r.get("tags",""), street])
                sparse = d > 200.0
                edges.append({"settlement":sett,"street":street,"parity":par,
                              "x_lo":prev["eov_x"],"y_lo":prev["eov_y"],
                              "x_hi":r["eov_x"],"y_hi":r["eov_y"],
                              "gap_m":float(d),"interp_allowed": bool(not (tanya_flag or sparse))})
            prev=r

    curr_ras_dir = os.path.join(args.store, "rasters", f"V{v+1}")
    curr_diag_dir = os.path.join(args.store, "diagnostics", f"V{v+1}")
    os.makedirs(curr_ras_dir, exist_ok=True); os.makedirs(curr_diag_dir, exist_ok=True)
    export_rasters(combined, pd.DataFrame(edges), curr_ras_dir, base_res_m, x0, y0, levels=levels,
                   export_csv=bool(args.export_csv), export_png=bool(args.export_png), export_tif=True,
                   quantize=not args.no_quantize, max_dist_m=args.max_dist_m)
    export_diagnostics(combined, pd.DataFrame(edges), curr_diag_dir)

    prev_ras_dir = os.path.join(args.store, "rasters", f"V{v}")
    if os.path.isdir(prev_ras_dir):
        diff_dir = os.path.join(args.store, "rasters", "diffs", f"V{v+1}_vs_V{v}")
        os.makedirs(diff_dir, exist_ok=True); export_diffs(prev_ras_dir, curr_ras_dir, diff_dir)

    report_path = os.path.join(curr_diag_dir, "report.html")
    diffs_path = os.path.join(args.store, "rasters", "diffs", f"V{v+1}_vs_V{v}")
    generate_html_report(f"V{v+1}", curr_ras_dir, curr_diag_dir, report_path, prev_version_label=f"V{v}", diffs_dir=diffs_path if os.path.isdir(diffs_path) else None)

if __name__ == "__main__":
    main()
