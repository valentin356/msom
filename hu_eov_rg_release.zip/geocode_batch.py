import argparse, pandas as pd, logging, os, time
from hu_eov_rg.io_any import load_any_table
from hu_eov_rg.io_parquet_cfg import normalize_df_with_schema
from hu_eov_rg.coords import ensure_eov_coords
from hu_eov_rg.store import find_latest_base_version
from hu_eov_rg.eov_raster import RasterIndexEOV, GeocoderRasterEOV
from hu_eov_rg.logging_utils import setup_logging, get_logger
from hu_eov_rg.progress import pbar

def main():
    ap = argparse.ArgumentParser(description="Batch geokódolás: store + geokódolandó címek -> CSV.")
    ap.add_argument("--store", required=True)
    ap.add_argument("--schema", required=True)
    ap.add_argument("--targets", required=True)
    ap.add_argument("--out-csv", required=True)
    ap.add_argument("--sparse-gap-m", type=float, default=200.0)
    ap.add_argument("--base-res-m", type=float, default=2048.0)
    ap.add_argument("--max-level", type=int, default=11)
    args = ap.parse_args()

    log_dir = os.path.join(args.store, 'logs'); os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, f'geocode_batch_{int(time.time())}.log')
    setup_logging(log_path, level=logging.INFO); log = get_logger(__name__)
    log.info('Start geocode_batch')

    v, latest = find_latest_base_version(args.store)
    if not latest:
        raise SystemExit("Nincs base a store-ban. Futtasd az ősfeltöltést.")
    base = pd.read_parquet(latest)
    if "eov_x" not in base.columns or "eov_y" not in base.columns:
        base = base.rename(columns={"EOV_Y":"eov_x","EOV_X":"eov_y"})

    r = RasterIndexEOV(base_res_m=args.base_res_m, max_level=args.max_level)
    r.ingest_df(base)
    if r.x0 is None or r.y0 is None:
        r.fit_origin_from_df(r.addr_df)
    r.build_cells_from_coords()
    r.build_graph(sparse_gap_m=args.sparse_gap_m)
    geo = GeocoderRasterEOV(r)

    targ_raw = load_any_table(args.targets)
    targ_norm = normalize_df_with_schema(targ_raw, args.schema)
    targ_raw_conv = ensure_eov_coords(targ_raw)
    if ("EOV_X" not in targ_norm.columns or "EOV_Y" not in targ_norm.columns) and ("EOV_X" in targ_raw_conv.columns and "EOV_Y" in targ_raw_conv.columns):
        targ_norm["EOV_X"] = targ_raw_conv["EOV_X"]
        targ_norm["EOV_Y"] = targ_raw_conv["EOV_Y"]
    targ_norm["eov_x"] = targ_norm.get("EOV_Y")
    targ_norm["eov_y"] = targ_norm.get("EOV_X")
    targ_norm["has_coords"] = targ_norm["eov_x"].notna() & targ_norm["eov_y"].notna()

    out_rows = []
    for _, row in pbar(targ_norm.iterrows(), total=len(targ_norm), desc='geocode rows'):
        if pd.notna(row.get("eov_x")) and pd.notna(row.get("eov_y")):
            out_rows.append({**row.to_dict(), "GEOCODE_SOURCE": "provided", "GEOCODE_ERROR_M": 0.0})
            continue
        settlement = row.get("settlement"); street = row.get("street"); hn = row.get("house_number")
        if pd.isna(settlement) or pd.isna(street) or pd.isna(hn):
            out_rows.append({**row.to_dict(), "GEOCODE_SOURCE": "insufficient-address", "GEOCODE_ERROR_M": None})
            continue
        try:
            res = geo.geocode(settlement, street, str(hn))
            out_rows.append({**row.to_dict(),
                             "eov_x": res["eov_x"], "eov_y": res["eov_y"],
                             "EOV_Y": res["eov_x"], "EOV_X": res["eov_y"],
                             "GEOCODE_SOURCE": res["source"], "GEOCODE_ERROR_M": res["error_m"]})
        except Exception as e:
            out_rows.append({**row.to_dict(), "GEOCODE_SOURCE": f"error:{e}", "GEOCODE_ERROR_M": None})

    pd.DataFrame(out_rows).to_csv(args.out_csv, index=False, encoding="utf-8")
    print(f"Saved geocoded CSV to {args.out_csv}")

if __name__ == "__main__":
    main()
