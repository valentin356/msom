
import torch
import torch.optim as optim
from .model import GraphSOMUpscaleModel
from .config import ModelConfig, TrainConfig

def synthetic_batch(B=1, C=13, H=24, W=24, device="cpu"):
    x = torch.rand(B,C,H,W, device=device)
    anchors = x[:,:min(C,4)]
    return x, anchors

def train_one_epoch(model, opt, device="cpu"):
    model.train()
    x, anchors = synthetic_batch(device=device)
    out = model(x, anchors_lr=anchors, compute_loss=True)
    opt.zero_grad()
    out["loss_total"].backward()
    opt.step()
    return {k: float(v.detach().cpu()) for k,v in out.items() if k.startswith("loss_")}

def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    mcfg = ModelConfig()
    model = GraphSOMUpscaleModel(mcfg).to(device)
    tcfg = TrainConfig()
    opt = optim.Adam(model.parameters(), lr=tcfg.lr)
    for epoch in range(tcfg.epochs):
        logs = train_one_epoch(model, opt, device)
        print(f"Epoch {epoch+1}: ", logs)
    # quick forward to produce outputs
    x, anchors = synthetic_batch(device=device)
    with torch.no_grad():
        out = model(x, anchors_lr=anchors, compute_loss=False)
    print({k: v.shape if hasattr(v, 'shape') else type(v) for k,v in out.items()})

if __name__ == "__main__":
    main()
