
import torch
import torch.nn as nn
import torch.nn.functional as F

class DirichletUnmix(nn.Module):
    """
    Produces abundance vectors (simplex) from features using softmax (Dirichlet-like).
    Optionally learns per-endmember temperature.
    """
    def __init__(self, in_dim:int, endmembers:int, temp:float=1.0):
        super().__init__()
        self.endmembers = endmembers
        self.net = nn.Sequential(
            nn.Linear(in_dim, 2*in_dim),
            nn.ReLU(inplace=True),
            nn.Linear(2*in_dim, endmembers),
        )
        self.log_temp = nn.Parameter(torch.log(torch.tensor([temp])))

    def forward(self, feat):
        # feat: [B,N,D]
        logits = self.net(feat) / torch.exp(self.log_temp)
        a = F.softmax(logits, dim=-1)  # [B,N,K]
        return a

def mix_spectra(abundances, endmembers):
    """
    abundances: [B,N,K]
    endmembers: [K,B]
    returns: [B,N,B]
    """
    return abundances @ endmembers  # [B,N,B]
