
import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class GraphSOM(nn.Module):
    """
    A simple SOM-like codebook learned end-to-end.
    Each prototype represents an 'endmember' candidate in spectral space.
    """
    def __init__(self, codebook:int, bands:int, sigma:float=1.5):
        super().__init__()
        self.codebook = codebook
        self.bands = bands
        self.sigma = sigma
        self.prototypes = nn.Parameter(torch.randn(codebook, bands)*0.01)

        # predefine a 1D neighborhood kernel over prototypes (ring)
        idx = torch.arange(codebook).unsqueeze(1)
        self.register_buffer("proto_idx", idx)  # [K,1]

    def forward(self, x):
        """
        x: [B,N,Bands] - spectral vectors
        returns: assignment weights [B,N,K], and current prototypes [K,Bands]
        """
        B,N,D = x.shape
        protos = self.prototypes  # [K,D]
        # cosine similarity
        x_n = F.normalize(x, dim=-1)
        p_n = F.normalize(protos, dim=-1)
        sim = x_n @ p_n.T  # [B,N,K]
        bmu = sim.argmax(-1)  # [B,N]

        # soft neighborhood around BMU index in 1D ring topology
        K = protos.size(0)
        # distances in prototype index space
        idxs = self.proto_idx.squeeze(1)  # [K]
        dmat = torch.cdist(idxs.float().unsqueeze(-1), idxs.float().unsqueeze(-1), p=1)  # [K,K]
        neigh = torch.exp(-(dmat**2)/(2*self.sigma**2))  # [K,K]

        # gather neighborhood centered at each BMU index -> weight contributions
        # For simplicity, take the same neighborhood for all BMUs: weight by sim softmax
        w = F.softmax(sim*3.0, dim=-1)  # [B,N,K]
        return w, protos

    def prototypes_clamped(self):
        # optional clamp reflectance range [0,1]
        return self.prototypes.clamp(0.0,1.0)
