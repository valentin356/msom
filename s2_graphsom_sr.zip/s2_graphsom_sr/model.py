
import torch
import torch.nn as nn
import torch.nn.functional as F

from .som import GraphSOM
from .unmix import DirichletUnmix, mix_spectra
from .guidance import GuidanceNet
from .ot import micro_mesh
from .psf import degrade_psf_downsample
from .losses import l1_recon, spectral_angle_mapper, total_variation, gradient_align_loss, isotonic_order_loss
from .config import ModelConfig

class GraphSOMUpscaleModel(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.cfg = cfg
        # simple feature extractor at coarse resolution
        self.feat = nn.Sequential(
            nn.Conv2d(cfg.bands, 64, 3, padding=1),
            nn.ReLU(True),
            nn.Conv2d(64, 64, 3, padding=1),
            nn.ReLU(True),
        )
        self.som = GraphSOM(codebook=cfg.som_codebook, bands=cfg.bands, sigma=cfg.som_sigma)
        self.unmix = DirichletUnmix(in_dim=64, endmembers=cfg.endmembers, temp=0.7)
        # endmember readout from SOM prototypes (learned)
        # guidance on four anchor bands (placeholder: use first 4)
        self.guidance = GuidanceNet(in_ch=min(cfg.bands,4))

    def forward(self, x_lr, anchors_lr=None, compute_loss=False, degrade_stride=10):
        """
        x_lr: [B,C,H,W] low-res (Sentinel-2)
        anchors_lr: [B,4,H,W] anchor bands for guidance (or None -> take first 4 of x_lr)
        Returns dict with hr cube and (optional) losses.
        """
        B,C,H,W = x_lr.shape
        up = self.cfg.up_factor

        # Coarse features
        f = self.feat(x_lr)                    # [B,64,H,W]
        f_flat = f.movedim(1,-1).reshape(B, H*W, 64)
        # SOM codes (not used explicitly here, but could be a weighting toward endmembers)
        w_som, protos = self.som(x_lr.movedim(1,-1).reshape(B,H*W,C))  # [B,N,K_som], [K_som,C]

        # Coarse abundances
        a_flat = self.unmix(f_flat)            # [B,N,K_endm]
        a_coarse = a_flat.reshape(B, H, W, self.cfg.endmembers).movedim(-1,1)  # [B,K,H,W]

        # Guidance
        if anchors_lr is None:
            anchors_lr = x_lr[:,:min(C,4)]
        G = self.guidance(anchors_lr)          # [B,2,H,W]

        # Subpixel micro-meshing (ensure per-cell marginals match coarse)
        A_hr = micro_mesh(a_coarse, self.cfg.endmembers, up=up, guidance=G,
                          border_lambda=self.cfg.border_weight, iters_smooth=5)  # [B,K,H*up,W*up]

        # Endmembers: use SOM prototypes averaged into K via 1x1 conv-like readout
        # For simplicity, map SOM prototypes to endmembers with a small MLP
        # (Here: linear projection)
        # protos: [K_som, C], map to [K, C]
        Ksom = protos.shape[0]
        Wmap = torch.randn(Ksom, self.cfg.endmembers, device=protos.device, dtype=protos.dtype)*0.01
        endm = (protos @ Wmap).T  # [K, C]
        endm = endm.clamp(0.0, 1.0)

        # HR mix
        Y_hr = torch.einsum('bkhw,kc->bchw', A_hr, endm)  # [B,C,H*up,W*up]

        out = {"Y_hr": Y_hr, "A_hr": A_hr, "endmembers": endm, "A_coarse": a_coarse, "guidance": G}

        if compute_loss:
            # degrade HR back to LR
            x_rec = degrade_psf_downsample(Y_hr, stride=up)  # [B,C,H,W]
            loss_recon = l1_recon(x_rec, x_lr)
            loss_sam   = spectral_angle_mapper(x_lr, x_rec)
            loss_tv    = total_variation(A_hr)
            loss_grad  = gradient_align_loss(Y_hr, F.interpolate(G, scale_factor=up, mode='bilinear', align_corners=False))
            # simple potential phi from guidance magnitude
            Gup = F.interpolate(G, scale_factor=up, mode='bilinear', align_corners=False)
            phi = (Gup[:,0:1]**2 + Gup[:,1:2]**2).sqrt()
            loss_order = isotonic_order_loss(A_hr, phi)

            total = (self.cfg.recon_l1_weight*loss_recon +
                     self.cfg.sam_weight*loss_sam +
                     self.cfg.tv_weight*loss_tv +
                     self.cfg.grad_weight*loss_grad +
                     self.cfg.order_weight*loss_order)

            out.update({
                "loss_total": total,
                "loss_recon": loss_recon,
                "loss_sam": loss_sam,
                "loss_tv": loss_tv,
                "loss_grad": loss_grad,
                "loss_order": loss_order
            })
        return out
