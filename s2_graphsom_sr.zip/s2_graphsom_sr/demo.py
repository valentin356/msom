
"""Minimal demo using random data.
This will build the model and run a single forward pass to produce a HR cube and subpixel abundances.
"""
import torch
from s2_graphsom_sr.model import GraphSOMUpscaleModel
from s2_graphsom_sr.config import ModelConfig

def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = ModelConfig()
    model = GraphSOMUpscaleModel(cfg).to(device)
    B,C,H,W = 1, cfg.bands, 24, 24
    x = torch.rand(B,C,H,W, device=device)
    anchors = x[:,:min(C,4)]
    out = model(x, anchors_lr=anchors, compute_loss=True)
    for k,v in out.items():
        if hasattr(v, 'shape'):
            print(k, tuple(v.shape))
        else:
            print(k, float(v))

if __name__ == "__main__":
    main()
