
import torch
import torch.nn.functional as F
import math

def gaussian_kernel2d(ks: int, sigma: float, device=None, dtype=None):
    ax = torch.arange(ks, device=device, dtype=dtype) - (ks-1)/2
    xx, yy = torch.meshgrid(ax, ax, indexing="ij")
    k = torch.exp(-(xx**2 + yy**2)/(2*sigma**2))
    k = k / k.sum()
    return k

def band_psf_kernel(band_index: int, ks: int=9, device=None, dtype=None):
    # Simple heuristic: higher resolution bands have narrower PSFs
    # This is a placeholder; in practice use S2 MTF/PSF tables.
    sigma_map = {
        # approximate scale factors (arbitrary placeholder)
        "10m": 1.2, "20m": 2.0, "60m": 3.5
    }
    if band_index in [2,3,4,8]:   # B2,B3,B4,B8 -> 10m
        sigma = sigma_map["10m"]
    elif band_index in [5,6,7,8,11,12]:  # many 20m (note overlap in index numbers depends on mapping used)
        sigma = sigma_map["20m"]
    else:
        sigma = sigma_map["60m"]
    return gaussian_kernel2d(ks, sigma, device=device, dtype=dtype)

def degrade_psf_downsample(x, stride:int=10, kernel_size:int=9):
    """
    x: [B, C, H, W] high-res (conceptual). We convolve per-channel with a band-specific kernel
    then downsample by stride using strided conv (no aliasing assumption).
    Note: Here we assume x channels correspond one-to-one to bands.
    """
    B,C,H,W = x.shape
    device, dtype = x.device, x.dtype
    weight = []
    for b in range(C):
        k = band_psf_kernel(band_index=b, ks=kernel_size, device=device, dtype=dtype)
        weight.append(k)
    Wk = torch.stack(weight, dim=0).unsqueeze(1)  # [C,1,ks,ks]
    x_blur = F.conv2d(x, Wk, padding=kernel_size//2, groups=C)
    # downsample by taking every stride pixel (nearest). Could use avg_pool for antialias; we already blurred.
    x_ds = x_blur[:,:,::stride,::stride]
    return x_ds
