
# s2_graphsom_sr

**Graph-SOM + Unmixing + OT-based micro-meshing** for Sentinel-2 style super-resolution to ~1 m,
with guidance-field-driven subpixel arrangement and physical LR consistency (PSF/MTF degrade).

> Research prototype, end-to-end differentiable skeleton. Not production-ready.

## Highlights

- **Graph-SOM** codebook over spectra as interpretable endmember manifold.
- **Dirichlet (softmax) unmixing** to produce coarse abundances (simplex constraints).
- **Micro-meshing** (entropic/iterative smoothing inspired) spreads coarse abundances to an upsampled 1 m grid while **preserving per-cell marginals**.
- **Guidance field** from anchor bands steers gradients and reduces hallucinatory textures.
- **Physical consistency**: HR → LR degrade (PSF+downsample) for reconstruction loss.
- Losses: L1 recon, **SAM**, **TV on abundances**, **gradient alignment**, **isotonic order**.
- **Temporal hooks** left for extension (optical flow / change masks).

## Install

```bash
pip install -r requirements.txt
```

## Quick start

```bash
python -m s2_graphsom_sr.train
```

This runs a toy training loop on random data and prints loss scalars and output shapes.

## Notes

- PSF/MTF parameters are placeholders. Replace with band-accurate kernels.
- The Graph-SOM here exposes prototypes; mapping to `K` endmembers is linear for simplicity.
- `micro_mesh` preserves coarse marginals via iterative projection and smooths abundances with a guidance-weighted diffusion, keeping the simplex constraint.
- Extend `model.forward` to include temporal coupling across `t` if you feed a time stack.

## License

MIT
