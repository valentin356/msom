
import torch

def pairwise_dist2(a, b):
    # a: [N,D], b: [M,D]
    a2 = (a**2).sum(-1, keepdim=True)  # [N,1]
    b2 = (b**2).sum(-1, keepdim=True).T  # [1,M]
    ab = a @ b.T
    d2 = a2 + b2 - 2*ab
    return torch.clamp(d2, min=0.0)

def knn_graph(features: torch.Tensor, coords: torch.Tensor, k: int=12, sigma_feat: float=1.0, sigma_pos: float=5.0):
    """
    Build a simple symmetric kNN graph with RBF weights from features and positions.
    features: [N,D]
    coords:   [N,2] (row, col)
    Returns: indices [N,k], weights [N,k]
    """
    with torch.no_grad():
        df = pairwise_dist2(features, features) / (sigma_feat**2)
        dp = pairwise_dist2(coords, coords) / (sigma_pos**2)
        d = df + dp
        # set self large to avoid choosing self twice (will include but weight 1.0 after)
        idx = torch.topk(-d, k=k+1, dim=-1).indices  # largest negative -> smallest d
        idx = idx[:,1:]  # drop self
        N = features.size(0)
        weights = torch.exp(-d.gather(1, idx))
        return idx, weights

