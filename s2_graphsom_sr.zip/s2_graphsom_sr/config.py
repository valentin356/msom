
from dataclasses import dataclass

@dataclass
class ModelConfig:
    bands: int = 13           # Sentinel-2 bands
    up_factor: int = 10       # 10 m -> 1 m
    endmembers: int = 8       # K
    som_codebook: int = 64    # number of SOM prototypes
    som_sigma: float = 1.5    # neighborhood width
    knn_k: int = 12           # graph neighbors
    sinkhorn_eps: float = 0.03
    sinkhorn_iters: int = 60
    tv_weight: float = 0.01
    grad_weight: float = 0.05
    time_weight: float = 0.02
    order_weight: float = 0.01
    border_weight: float = 0.02
    recon_l1_weight: float = 1.0
    sam_weight: float = 0.2

@dataclass
class TrainConfig:
    lr: float = 1e-3
    epochs: int = 2
    batch_size: int = 1
