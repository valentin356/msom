
import torch
import torch.nn.functional as F

def _simplex_project(x, eps=1e-8):
    # Project last dimension onto simplex
    # x: [...,K]
    shape = x.shape
    x = x.reshape(-1, shape[-1])
    # Algorithm from Wang & Carreira-Perpinan 2013
    mu, _ = torch.sort(x, dim=1, descending=True)
    cssv = torch.cumsum(mu, dim=1) - 1
    ind = torch.arange(1, shape[-1]+1, device=x.device).unsqueeze(0)
    cond = mu - cssv / ind > 0
    rho = cond.sum(dim=1) - 1
    theta = (cssv[torch.arange(x.size(0)), rho] / (rho + 1).clamp_min(1)).unsqueeze(1)
    w = torch.clamp(x - theta, min=0)
    return w.reshape(shape)

def sinkhorn(M, r, c, eps=0.03, iters=60):
    """
    Entropic OT between r (source) and c (target) with cost M.
    r: [B,N], c: [B,M], both sum to 1 per batch
    returns transport plan P: [B,N,M]
    """
    K = torch.exp(-M/eps)  # [B,N,M]
    u = torch.ones_like(r) / r.size(-1)
    v = torch.ones_like(c) / c.size(-1)
    for _ in range(iters):
        u = r / (K @ v.unsqueeze(-1)).squeeze(-1).clamp_min(1e-8)
        v = c / (K.transpose(1,2) @ u.unsqueeze(-1)).squeeze(-1).clamp_min(1e-8)
    P = u.unsqueeze(-1) * K * v.unsqueeze(1)
    return P

def micro_mesh(coarse_a, K_endm:int, up:int, guidance=None, border_lambda:float=0.02, iters_smooth:int=5):
    """
    Spread coarse abundances onto an upsampled grid using local OT + smoothing.
    coarse_a: [B,K,H,W] abundances per coarse pixel
    returns sub_A: [B,K,H*up,W*up]
    """
    B,K,H,W = coarse_a.shape
    device = coarse_a.device
    # Initial upsample: nearest to keep mass per coarse pixel (will fix with constraint)
    sub_A = F.interpolate(coarse_a, scale_factor=up, mode="nearest")
    # Normalize per coarse cell marginal to equal coarse_a exactly:
    # For each coarse cell, project mean back to coarse
    for _ in range(2):
        # compute cell means by avg pooling
        pooled = F.avg_pool2d(sub_A, kernel_size=up, stride=up)  # [B,K,H,W]
        diff = coarse_a - pooled
        # distribute diff uniformly within each cell
        diff_up = diff.repeat_interleave(up, -2).repeat_interleave(up, -1) / (up*up)
        sub_A = sub_A + diff_up
        sub_A = torch.clamp(sub_A, min=1e-8)
        # project onto simplex per subpixel
        sub_A = _simplex_project(sub_A.movedim(1,-1)).movedim(-1,1)

    # Optional smoothing guided by guidance field (anisotropic TV-like)
    if guidance is not None:
        # guidance: [B,2,H,W] at coarse res -> upsample to subpixel
        G = F.interpolate(guidance, scale_factor=up, mode="bilinear", align_corners=False)
        gx, gy = G[:,0:1], G[:,1:2]
    else:
        gx = gy = None

    for _ in range(iters_smooth):
        # neighbor diffs
        dx = torch.zeros_like(sub_A)
        dy = torch.zeros_like(sub_A)
        dx[:,:,:,1:] = sub_A[:,:,:,1:] - sub_A[:,:,:,:-1]
        dy[:,:,1:,:] = sub_A[:,:,1:,:] - sub_A[:,:,:-1,:]
        if gx is not None and gy is not None:
            wdx = 1.0 / (1.0 + (gx.abs()+1e-3))
            wdy = 1.0 / (1.0 + (gy.abs()+1e-3))
            dx = dx * wdx
            dy = dy * wdy
        sub_A = sub_A - 0.5*(dx - F.pad(dx[:,:,:,1:], (0,1,0,0)) + dy - F.pad(dy[:,:,1:,:], (0,0,0,1)))
        # keep simplex per pixel
        sub_A = torch.clamp(sub_A, min=1e-8)
        sub_A = _simplex_project(sub_A.movedim(1,-1)).movedim(-1,1)

    return sub_A
