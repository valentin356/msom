
import argparse, pandas as pd, logging, os, time
from hu_eov_rg.io_any import load_any_table
from hu_eov_rg.io_parquet_cfg import normalize_df_with_schema
from hu_eov_rg.coords import ensure_eov_coords
from hu_eov_rg.store import find_latest_base_version
from hu_eov_rg.eov_raster import RasterIndexEOV
from hu_eov_rg.fast_geocode import geocode_vectorized
from hu_eov_rg.logging_utils import setup_logging, get_logger
from hu_eov_rg.progress import pbar

def main():
    ap = argparse.ArgumentParser(description="Batch geokódolás: store + geokódolandó címek -> CSV.")
    ap.add_argument("--store", required=True)
    ap.add_argument("--schema", required=True)
    ap.add_argument("--targets", required=True)
    ap.add_argument("--out-csv", required=True)
    ap.add_argument("--sparse-gap-m", type=float, default=200.0)
    ap.add_argument("--base-res-m", type=float, default=2048.0)
    ap.add_argument("--max-level", type=int, default=11)
    ap.add_argument("--activation-level", type=int, default=10)
    args = ap.parse_args()

    log_dir = os.path.join(args.store, 'logs'); os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, f'geocode_batch_{int(time.time())}.log')
    setup_logging(log_path, level=logging.INFO); log = get_logger(__name__)
    log.info('Start geocode_batch')

    v, latest = find_latest_base_version(args.store)
    if not latest:
        raise SystemExit("Nincs base a store-ban. Futtasd az ősfeltöltést.")
    base = pd.read_parquet(latest)
    if "eov_x" not in base.columns or "eov_y" not in base.columns:
        base = base.rename(columns={"EOV_Y":"eov_x","EOV_X":"eov_y"})

    r = RasterIndexEOV(base_res_m=args.base_res_m, max_level=args.max_level)
    r.ingest_df(base)
    if r.x0 is None or r.y0 is None:
        r.fit_origin_from_df(r.addr_df)
    r.build_cells_from_coords()
    r.build_graph(sparse_gap_m=args.sparse_gap_m)
    geo = GeocoderRasterEOV(r)

    targ_raw = load_any_table(args.targets)
    targ_norm = normalize_df_with_schema(targ_raw, args.schema)
    targ_raw_conv = ensure_eov_coords(targ_raw)
    if ("EOV_X" not in targ_norm.columns or "EOV_Y" not in targ_norm.columns) and ("EOV_X" in targ_raw_conv.columns and "EOV_Y" in targ_raw_conv.columns):
        targ_norm["EOV_X"] = targ_raw_conv["EOV_X"]
        targ_norm["EOV_Y"] = targ_raw_conv["EOV_Y"]
    targ_norm["eov_x"] = targ_norm.get("EOV_Y")
    targ_norm["eov_y"] = targ_norm.get("EOV_X")
    targ_norm["has_coords"] = targ_norm["eov_x"].notna() & targ_norm["eov_y"].notna()

    out_rows = []

res = geocode_vectorized(base, r.graph.edges if r.graph is not None else None, targ_norm)
out_df = targ_norm.copy()
prov = out_df["eov_x"].notna() & out_df["eov_y"].notna()
out_df.loc[prov, "GEOCODE_SOURCE"] = "provided"
out_df.loc[prov, "GEOCODE_ERROR_M"] = 0.0
fill_idx = ~prov
out_df.loc[fill_idx, "eov_x"] = res.loc[fill_idx, "eov_x"]
out_df.loc[fill_idx, "eov_y"] = res.loc[fill_idx, "eov_y"]
out_df.loc[fill_idx, "GEOCODE_SOURCE"] = res.loc[fill_idx, "GEOCODE_SOURCE"]
out_df.loc[fill_idx, "GEOCODE_ERROR_M"] = res.loc[fill_idx, "GEOCODE_ERROR_M"]
out_df["EOV_Y"] = out_df["eov_x"]
out_df["EOV_X"] = out_df["eov_y"]
# Activation mask
L = args.activation_level
resm = args.base_res_m / (2**L)
xi = np.floor((out_df["eov_x"] - r.x0)/resm).astype("Int64")
yi = np.floor((out_df["eov_y"] - r.y0)/resm).astype("Int64")
out_df["xi"] = xi; out_df["yi"] = yi
act_path = os.path.join(args.store, "rasters", f"V{v}", f"activation_L{L}.parquet")
if os.path.exists(act_path):
    act = pd.read_parquet(act_path)[["xi","yi"]].drop_duplicates()
    act["active"] = True
    out_df = out_df.merge(act, how="left", on=["xi","yi"])
    mask_block = out_df["active"].isna() & (out_df["GEOCODE_SOURCE"]=="interpolated")
    if mask_block.any():
        anchors = base[base["has_coords"]].copy()
        anchors["base_num"] = anchors["house_number"].astype(str).str.extract(r"(\d+)")[0].astype(float)
        anchors = anchors.dropna(subset=["base_num"])
        anchors["parity"] = np.where((anchors["base_num"] % 2 == 0), "even", "odd")
        anchors["base_num"] = anchors["base_num"].astype(int)
        for c in ["settlement","street","parity"]:
            anchors[c] = anchors[c].astype("category")
        B = out_df.loc[mask_block, ["settlement","street","parity","house_number"]].copy()
        B["base_num"] = pd.to_numeric(B["house_number"].astype(str).str.extract(r"(\d+)")[0], errors="coerce").astype("Int64")
        lo_b = pd.merge_asof(
            B.sort_values(["settlement","street","parity","base_num"]),
            anchors[["settlement","street","parity","base_num","eov_x","eov_y"]].rename(columns={"eov_x":"x_lo","eov_y":"y_lo"}),
            by=["settlement","street","parity"], on="base_num", direction="backward", allow_exact_matches=True
        ).loc[B.index]
        hi_b = pd.merge_asof(
            B.sort_values(["settlement","street","parity","base_num"]),
            anchors[["settlement","street","parity","base_num","eov_x","eov_y"]].rename(columns={"eov_x":"x_hi","eov_y":"y_hi"}),
            by=["settlement","street","parity"], on="base_num", direction="forward", allow_exact_matches=True
        ).loc[B.index]
        bn_b = B["base_num"].astype("Int64")
        use_lo = (bn_b - lo_b["base_num"]).abs() <= (hi_b["base_num"] - bn_b).abs()
        new_x = np.where(use_lo.fillna(True), lo_b["x_lo"], hi_b["x_hi"])
        new_y = np.where(use_lo.fillna(True), lo_b["y_lo"], hi_b["y_hi"])
        out_df.loc[mask_block, "eov_x"] = new_x; out_df.loc[mask_block, "eov_y"] = new_y
        out_df.loc[mask_block, "EOV_Y"] = new_x; out_df.loc[mask_block, "EOV_X"] = new_y
        out_df.loc[mask_block, "GEOCODE_SOURCE"] = "anchor-no-interp"
    out_df.drop(columns=["active"], inplace=True)
out_rows = out_df.to_dict(orient="records")


    for _, row in pbar(targ_norm.iterrows(), total=len(targ_norm), desc='geocode rows'):
        if pd.notna(row.get("eov_x")) and pd.notna(row.get("eov_y")):
            out_rows.append({**row.to_dict(), "GEOCODE_SOURCE": "provided", "GEOCODE_ERROR_M": 0.0})
            continue
        settlement = row.get("settlement"); street = row.get("street"); hn = row.get("house_number")
        if pd.isna(settlement) or pd.isna(street) or pd.isna(hn):
            out_rows.append({**row.to_dict(), "GEOCODE_SOURCE": "insufficient-address", "GEOCODE_ERROR_M": None})
            continue
        try:
            res = geo.geocode(settlement, street, str(hn))
            out_rows.append({**row.to_dict(),
                             "eov_x": res["eov_x"], "eov_y": res["eov_y"],
                             "EOV_Y": res["eov_x"], "EOV_X": res["eov_y"],
                             "GEOCODE_SOURCE": res["source"], "GEOCODE_ERROR_M": res["error_m"]})
        except Exception as e:
            out_rows.append({**row.to_dict(), "GEOCODE_SOURCE": f"error:{e}", "GEOCODE_ERROR_M": None})

    pd.DataFrame(out_rows).to_csv