
# hu_eov_rg (full)

- tqdm progress, részletes logok
- sémavezérelt beolvasás (Excel/CSV/Parquet)
- WGS→EOV konverzió (pyproj), EOV tengelycsere kezelése (EOV_X = Y, EOV_Y = X)
- verziózott store (V1 seed + frissítések)
- raszter export: COG-szerű GeoTIFF + kvantálás (uint16/uint8), HTML gyorsriport

## Függőségek
pip install pandas numpy pyproj rasterio matplotlib tqdm scipy

## Futtatás
python seed_base.py --input alap.xlsx --schema schemas/schema_example.json --store ./store --base-res-m 2048 --levels 7 10
python update_base.py --input frissites.parquet --schema schemas/schema_example.json --store ./store
python geocode_batch.py --store ./store --schema schemas/schema_example.json --targets test_missing_seed_V1.csv --out-csv geokodolt_test.csv
