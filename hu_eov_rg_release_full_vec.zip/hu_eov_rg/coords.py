
import pandas as pd

WGS_LON = ["lon","longitude","long","x","wgs84_x","wgs_lon"]
WGS_LAT = ["lat","latitude","y","wgs84_y","wgs_lat"]

def detect_coords(df: pd.DataFrame) -> str:
    low = {c.lower(): c for c in df.columns}
    if "eov_x" in low and "eov_y" in low: return "eov"
    if any(n in low for n in WGS_LON) and any(n in low for n in WGS_LAT): return "wgs84"
    return "none"

def _pick(df: pd.DataFrame, names):
    low = {c.lower(): c for c in df.columns}
    for n in names:
        if n in low: return low[n]
    return None

def wgs84_to_eov(df: pd.DataFrame, lon_col: str, lat_col: str) -> pd.DataFrame:
    from pyproj import Transformer
    tr = Transformer.from_crs(4326, 23700, always_xy=True)
    lon = df[lon_col].astype(float).values
    lat = df[lat_col].astype(float).values
    ex, ny = tr.transform(lon, lat)
    df2 = df.copy()
    df2["EOV_Y"] = ex
    df2["EOV_X"] = ny
    return df2

def ensure_eov_coords(df: pd.DataFrame) -> pd.DataFrame:
    kind = detect_coords(df)
    if kind == "eov": return df
    if kind == "wgs84":
        lon = _pick(df, WGS_LON); lat = _pick(df, WGS_LAT)
        return wgs84_to_eov(df, lon, lat)
    return df
