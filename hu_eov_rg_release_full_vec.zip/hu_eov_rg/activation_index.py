
import numpy as np
import pandas as pd
from .progress import pbar

def build_activation_index(edges_df: pd.DataFrame, x0: float, y0: float, base_res_m: float, level: int):
    res = base_res_m / (2**level)
    coords = []
    for _, e in pbar(edges_df.iterrows(), total=len(edges_df), desc=f'activate L{level}'):
        x1, y1, x2, y2 = float(e['x_lo']), float(e['y_lo']), float(e['y_hi']), float(e['y_hi'])
        # Correct y2: we mistakenly doubled y_hi earlier; fix:
        y2 = float(e['y_hi'])
        L = max(1, int(np.hypot(x2-x1, y2-y1) / res))
        ts = np.linspace(0, 1, L+1)
        xs = x1 + ts * (x2 - x1); ys = y1 + ts * (y2 - y1)
        xi = np.floor((xs - x0)/res).astype(int)
        yi = np.floor((ys - y0)/res).astype(int)
        coords.extend(zip(xi, yi))
    if not coords: 
        return pd.DataFrame({"level":[],"xi":[],"yi":[]})
    A = pd.DataFrame(coords, columns=["xi","yi"]).drop_duplicates()
    A["level"] = level
    return A[["level","xi","yi"]]
