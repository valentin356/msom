
# AURORA — Unsupervised Riemannian-Atlas SOM/Attention for Sentinel-2 (GDAL-only)

Supports **clipping to a reference GeoTIFF** from the start: pass `--ref_tif /path/to/ref.tif` and
all inputs are **warped+cropped** to that grid/extent/SRS.

## Quickstart

```bash
python3 -m pip install numpy scipy torch torchvision --upgrade
# (Install GDAL in your environment; we use osgeo.gdal only.)

python -m aurora_s2.main   --input_dir /path/to/S2_ZIPS   --work_dir  /path/to/work   --ref_tif   /path/to/reference.tif \  # << clip grid/bounds & SRS from here
  --epochs 5 --window 8 --patch 32 --samples_per_epoch 2000

python -m aurora_s2.export   --input_dir /path/to/S2_ZIPS   --work_dir  /path/to/work   --ref_tif   /path/to/reference.tif   --out_dir   /path/to/out
```

- Best native resolution per band is used:
  - 10 m: B02, B03, B04, B08
  - 20 m: B05, B06, B07, B8A, B11, B12
  - 60 m: B01, B09
  - SCL: 20 m
- Everything is warped to the **reference** grid (from `--ref_tif` if provided, otherwise first B02 10 m). 
  SCL with **nearest**, others with **bilinear**.
