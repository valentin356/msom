
# AURORA — Unsupervised Riemannian-Atlas SOM/Attention for Sentinel‑2 (GDAL-only)

This is a **complete reference implementation** of the AURORA framework tailored for **Sentinel‑2 L2A** inputs provided as **`.zip` products**.

- **Input**: a directory containing one or more Sentinel‑2 L2A `.zip` files (unmodified Copernicus products).
- **Processing**: GDAL (no rasterio) reads bands inside the ZIP via `/vsizip/`, picks the **best native resolution** per band, warps everything to a common **10 m grid**, builds a temporal **feature stack** (bands + indices), cloud-masks via **SCL** (dilated), and prepares an **unsupervised** dataset.
- **Model**: AURORA — self-organizing atlas + local interactions (SOM‑style prototypes + torus coordinates). Trains with **masked reconstruction + contrastive predictive coding + topology regularization**.
- **Output**: derived **AURORA bands** (atlas coordinates, regime/cell, entropy, residuals, change score) as **GeoTIFF** via GDAL, aligned to the 10 m grid.

> ⚠️ This is an MVP reference. It is robust and runnable, but not optimized for very large AOIs. Start with a subset (e.g. one or a few products) and increase gradually.

## Quickstart

```bash
# Create environment with GDAL and PyTorch installed.
python3 -m pip install numpy scipy torch torchvision --upgrade

# (GDAL must be installed in your environment; this project uses the Python osgeo.gdal bindings.)

# Run training on your S2 L2A ZIP folder:
python -m aurora_s2.main   --input_dir /path/to/S2_ZIPS   --work_dir  /path/to/work   --epochs 5   --window 8   --patch 32   --samples_per_epoch 2000

# After training, export derived bands for the latest time slice:
python -m aurora_s2.export   --input_dir /path/to/S2_ZIPS   --work_dir  /path/to/work   --out_dir   /path/to/out
```

## Band selection policy (best native resolution)

- 10 m preferred: **B02, B03, B04, B08**
- 20 m preferred: **B05, B06, B07, B8A, B11, B12**
- 60 m preferred: **B01, B09**
- SCL (Scene Classification Layer): **20 m**

All sources are resampled to **10 m** (bilinear; SCL = nearest) on a **reference grid** built from the first B02 product found.

## Derived indices

- NDVI = (B8 − B4) / (B8 + B4)
- NDRE = (B8A − B05) / (B8A + B05)
- NDWI = (B3 − B8) / (B3 + B8)
- MNDWI = (B3 − B11) / (B3 + B11)
- NBR = (B8 − B12) / (B8 + B12)

## AURORA outputs (GeoTIFF bands)

- `aurora_u1,u2,u3` — atlas coordinates in [0,1)
- `aurora_cell_id` — integer prototype id
- `aurora_assign_entropy` — soft assignment entropy
- `aurora_regime_id` — same as cell id (alias)
- `aurora_forecast_resid` — proxy anomaly (here: recon residual)
- `aurora_change_score` — temporal jump proxy (BMU changes per pixel)

## Project layout

```
aurora_s2/
  __init__.py
  config.py
  s2_utils.py
  preprocess.py
  dataset.py
  aurora_model.py
  train.py
  export.py
  main.py
```

## Notes

- Uses **GDAL** exclusively for raster IO and resampling.
- **No rasterio** anywhere.
- Works with zipped L2A products via `/vsizip/` and Python's `zipfile` for listing.
- For large scenes, memory can be high. Try `--tile_size 1024` and fewer samples per epoch.
