
import os
from typing import Dict, Tuple
import numpy as np
from osgeo import gdal
from .s2_utils import (
    list_zip_products, list_band_paths_in_zip, choose_best_band_path,
    build_vsizip_path, warp_to_match, create_ref_grid_from_zip
)

def safe_div(a, b, eps=1e-6):
    return (a - b) / np.clip(a + b, eps, None)

def compute_indices(stack: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
    B = stack; out = {}
    def get(b): return B[b] if b in B else np.full_like(B["B02"], np.nan, dtype=np.float32)
    B2,B3,B4,B5,B8,B8A,B11,B12 = get("B02"),get("B03"),get("B04"),get("B05"),get("B08"),get("B8A"),get("B11"),get("B12")
    out["NDVI"]  = safe_div(B8,  B4)
    out["NDRE"]  = safe_div(B8A, B5)
    out["NDWI"]  = safe_div(B3,  B8)
    out["MNDWI"] = safe_div(B3,  B11)
    out["NBR"]   = safe_div(B8,  B12)
    return out

def scl_cloud_mask(scl_array, dilate_iter=1):
    scl = scl_array.astype(np.uint8)
    cloudy = (scl==0)|(scl==1)|(scl==3)|(scl==8)|(scl==9)|(scl==10)|(scl==11)
    if dilate_iter>0:
        for _ in range(dilate_iter):
            padded = np.pad(cloudy, 1, mode="edge")
            out = cloudy.copy()
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    out |= padded[1+dy:1+dy+cloudy.shape[0], 1+dx:1+dx+cloudy.shape[1]]
            cloudy = out
    return cloudy

def read_one_product(zip_path: str, ref_ds=None):
    mapping = list_band_paths_in_zip(zip_path)
    if ref_ds is None:
        ref_ds, _ = create_ref_grid_from_zip(zip_path, band="B02")

    arrays = {}
    for band in ["B02","B03","B04","B08","B05","B06","B07","B8A","B11","B12"]:
        inner = choose_best_band_path(mapping.get(band, []), band)
        if not inner: continue
        vpath = build_vsizip_path(zip_path, inner)
        warped = warp_to_match(vpath, ref_ds, resample="bilinear", to_mem=True)
        arr = warped.ReadAsArray().astype(np.float32)
        if arr.max() > 1.0: arr = arr / 10000.0
        arrays[band] = arr

    scl_inner = choose_best_band_path(mapping.get("SCL", []), "SCL")
    if scl_inner:
        vpath = build_vsizip_path(zip_path, scl_inner)
        warped = warp_to_match(vpath, ref_ds, resample="nearest", to_mem=True)
        scl = warped.ReadAsArray()
        cloud = scl_cloud_mask(scl, dilate_iter=1)
    else:
        cloud = np.zeros_like(arrays["B02"], dtype=bool)

    idx = compute_indices(arrays); arrays.update(idx)
    return arrays, cloud

def build_time_stack(input_dir: str, max_products: int=0, ref_tif: str=""):
    zips = list_zip_products(input_dir, max_products=max_products)
    if not zips:
        raise RuntimeError("No .zip products found")

    if ref_tif and os.path.exists(ref_tif):
        ref_ds = gdal.Open(ref_tif, gdal.GA_ReadOnly)
        if ref_ds is None: raise RuntimeError(f"Failed to open ref_tif: {ref_tif}")
    else:
        ref_ds, _ = create_ref_grid_from_zip(zips[0], band="B02")

    entries = []
    for zp in zips:
        try:
            arrays, cloud = read_one_product(zp, ref_ds=ref_ds)
        except Exception as e:
            print(f"[WARN] Skipping {zp}: {e}")
            continue
        import re, datetime
        m = re.search(r"(\d{8}T\d{6})", os.path.basename(zp))
        dt = None
        if m:
            try: dt = datetime.datetime.strptime(m.group(1), "%Y%m%dT%H%M%S")
            except: dt = None
        entries.append((arrays, cloud, dt, zp))

    entries.sort(key=lambda x: x[2] or 0)
    return entries, ref_ds
