
import os, math
from typing import Dict, List, Tuple
import numpy as np
from osgeo import gdal
from .s2_utils import (
    list_zip_products, list_band_paths_in_zip, choose_best_band_path,
    build_vsizip_path, open_ds, warp_to_match, create_ref_grid_from_zip,
    scl_cloud_mask
)

BANDS_ALL = ["B02","B03","B04","B08","B05","B06","B07","B8A","B11","B12","B01","B09"]

def safe_div(a, b, eps=1e-6):
    return (a - b) / np.clip(a + b, eps, None)

def compute_indices(stack: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
    B = stack
    out = {}
    def get(b): return B[b] if b in B else np.full_like(B["B02"], np.nan, dtype=np.float32)
    B2,B3,B4,B5,B8,B8A,B11,B12 = get("B02"),get("B03"),get("B04"),get("B05"),get("B08"),get("B8A"),get("B11"),get("B12")

    out["NDVI"]  = safe_div(B8,  B4)
    out["NDRE"]  = safe_div(B8A, B5)
    out["NDWI"]  = safe_div(B3,  B8)
    out["MNDWI"] = safe_div(B3,  B11)
    out["NBR"]   = safe_div(B8,  B12)
    return out

def read_one_product(zip_path: str, ref_ds=None):
    mapping = list_band_paths_in_zip(zip_path)
    if ref_ds is None:
        ref_ds, _ = create_ref_grid_from_zip(zip_path, band="B02")

    arrays = {}
    for band in ["B02","B03","B04","B08","B05","B06","B07","B8A","B11","B12"]:
        inner = choose_best_band_path(mapping.get(band, []), band)
        if not inner: continue
        vpath = build_vsizip_path(zip_path, inner)
        warped = warp_to_match(vpath, ref_ds, resample="bilinear", to_mem=True)
        arr = warped.ReadAsArray().astype(np.float32)
        if arr.max() > 1.0:
            arr = arr / 10000.0
        arrays[band] = arr

    # SCL
    scl_inner = choose_best_band_path(mapping.get("SCL", []), "SCL")
    if scl_inner:
        vpath = build_vsizip_path(zip_path, scl_inner)
        warped = warp_to_match(vpath, ref_ds, resample="nearest", to_mem=True)
        scl = warped.ReadAsArray()
        cloud = scl_cloud_mask(scl, dilate_iter=1)
    else:
        cloud = np.zeros_like(arrays["B02"], dtype=bool)

    idx = compute_indices(arrays)
    arrays.update(idx)
    return arrays, cloud

def build_time_stack(input_dir: str, max_products: int=0):
    zips = list_zip_products(input_dir, max_products=max_products)
    if not zips:
        raise RuntimeError("No .zip products found")
    ref_ds, _ = create_ref_grid_from_zip(zips[0], band="B02")
    entries = []
    for zp in zips:
        try:
            arrays, cloud = read_one_product(zp, ref_ds=ref_ds)
        except Exception as e:
            print(f"[WARN] Skipping {zp}: {e}")
            continue
        import re, datetime, os
        m = re.search(r"(\d{8}T\d{6})", os.path.basename(zp))
        dt = None
        if m:
            try:
                dt = datetime.datetime.strptime(m.group(1), "%Y%m%dT%H%M%S")
            except:
                dt = None
        entries.append((arrays, cloud, dt, zp))
    entries.sort(key=lambda x: x[2] or 0)
    return entries, ref_ds
