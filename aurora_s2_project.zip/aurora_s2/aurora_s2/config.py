
from dataclasses import dataclass

@dataclass
class Config:
    # Data
    input_dir: str = ""
    work_dir: str = ""
    out_dir: str = ""
    ref_tif: str = ""        # Optional reference GeoTIFF (grid/SRS/extent)
    window: int = 8
    patch: int = 32
    tile_size: int = 1024
    max_products: int = 0

    # Model / Atlas
    d_embed: int = 128
    atlas_m: int = 3
    grid_n: int = 16
    K_local: int = 16
    k_worm: int = 4
    tau: float = 1.0
    lam_geo: float = 1.0
    sigma_atlas: float = 4.0

    # Training
    epochs: int = 5
    batch_size: int = 64
    lr: float = 3e-4
    weight_decay: float = 0.02
    samples_per_epoch: int = 2000

    # Loss weights
    w_mae: float = 1.0
    w_cpc: float = 0.5
    w_topo: float = 0.2
    w_mdl: float = 0.1
    w_commit: float = 0.25
    w_sparse: float = 0.05
    w_dyn: float = 0.2
