
from dataclasses import dataclass

@dataclass
class Config:
    # Data
    input_dir: str = ""
    work_dir: str = ""
    out_dir: str = ""
    window: int = 8          # time steps per token window
    patch: int = 32          # spatial patch size (pixels)
    tile_size: int = 1024    # for export tiling
    max_products: int = 0    # 0 = no limit

    # Model / Atlas
    d_embed: int = 128
    atlas_m: int = 3         # torus dims
    grid_n: int = 16         # grid per dimension => total protos = grid_n**atlas_m
    K_local: int = 16        # KNN neighbors on atlas
    k_worm: int = 4          # sparse global connections
    tau: float = 1.0         # temperature
    lam_geo: float = 1.0     # geodesic weight in soft-assign
    sigma_atlas: float = 4.0 # neighbor kernel on grid

    # Training
    epochs: int = 5
    batch_size: int = 64
    lr: float = 3e-4
    weight_decay: float = 0.02
    samples_per_epoch: int = 2000

    # Loss weights
    w_mae: float = 1.0
    w_cpc: float = 0.5
    w_topo: float = 0.2
    w_mdl: float = 0.1
    w_commit: float = 0.25
    w_sparse: float = 0.05
    w_dyn: float = 0.2
