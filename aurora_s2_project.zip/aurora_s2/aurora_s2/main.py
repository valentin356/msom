
import argparse, os, json
from .config import Config
from .train import train
from .export import export

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--input_dir", required=True, help="Directory with Sentinel-2 L2A .zip products")
    p.add_argument("--work_dir", required=True, help="Working directory (checkpoints)")
    p.add_argument("--out_dir", default="", help="Output directory for derived bands (optional)")
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--window", type=int, default=8)
    p.add_argument("--patch", type=int, default=32)
    p.add_argument("--samples_per_epoch", type=int, default=2000)
    p.add_argument("--max_products", type=int, default=0, help="Limit number of products (0=no limit)")
    return p.parse_args()

def main():
    args = parse_args()
    cfg = Config(
        input_dir=args.input_dir,
        work_dir=args.work_dir,
        out_dir=args.out_dir or os.path.join(args.work_dir, "export"),
        epochs=args.epochs,
        window=args.window,
        patch=args.patch,
        samples_per_epoch=args.samples_per_epoch,
        max_products=args.max_products,
    )
    os.makedirs(cfg.work_dir, exist_ok=True)
    with open(os.path.join(cfg.work_dir, "config.json"), "w") as f:
        json.dump(vars(cfg), f, indent=2)

    train(cfg)
    if cfg.out_dir:
        os.makedirs(cfg.out_dir, exist_ok=True)
        export(cfg)

if __name__ == "__main__":
    main()
