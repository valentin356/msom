
import torch
import torch.nn as nn
import torch.nn.functional as F

def geodesic_torus_dist(u, v):
    dv = torch.abs(u - v)
    dv = torch.minimum(dv, 1.0 - dv)
    return torch.linalg.vector_norm(dv, dim=-1)

class Encoder(nn.Module):
    def __init__(self, in_ch, d_embed):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, 64, 3, padding=1), nn.GELU(),
            nn.Conv2d(64, 128, 3, padding=1), nn.GELU(),
            nn.Conv2d(128, d_embed, 3, padding=1),
        )
    def forward(self, x): return self.net(x)

class Decoder(nn.Module):
    def __init__(self, d_embed, out_ch):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(d_embed, 128, 3, padding=1), nn.GELU(),
            nn.Conv2d(128, 64, 3, padding=1), nn.GELU(),
            nn.Conv2d(64, out_ch, 3, padding=1),
        )
    def forward(self, z): return self.net(z)

class AtlasMapper(nn.Module):
    def __init__(self, d_embed, m=3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(d_embed, d_embed, 1), nn.GELU(),
            nn.Conv2d(d_embed, m, 1), nn.Sigmoid(),
        )
    def forward(self, z): return self.net(z)

class Prototypes(nn.Module):
    def __init__(self, d_embed, m=3, grid_n=16):
        super().__init__()
        self.m = m; self.grid_n = grid_n; self.P = grid_n**m
        axes = [torch.linspace(0,1,grid_n) for _ in range(m)]
        mesh = torch.meshgrid(*axes, indexing='ij')
        coords = torch.stack(mesh, dim=-1).reshape(-1, m)
        self.register_buffer("coords", coords)
        self.w = nn.Parameter(torch.randn(self.P, d_embed)*0.02)

    def soft_assign(self, z_flat, u_flat, tau=1.0, lam_geo=1.0):
        cd = torch.cdist(z_flat, self.w)  # [N,P]
        uv = u_flat[:,None,:]; pc = self.coords[None,:,:]
        dv = torch.abs(uv - pc); dv = torch.minimum(dv, 1.0 - dv)
        gd = torch.linalg.vector_norm(dv, dim=-1)
        D = cd + lam_geo * gd
        a = F.softmax(-D / max(tau,1e-6), dim=-1)
        bmu = torch.argmax(a, dim=-1)
        return a, bmu

class Aurora(nn.Module):
    def __init__(self, in_ch, out_ch, d_embed=128, m=3, grid_n=16, K_local=16, tau=1.0, lam_geo=1.0):
        super().__init__()
        self.encoder = Encoder(in_ch, d_embed)
        self.mapper  = AtlasMapper(d_embed, m=m)
        self.protos  = Prototypes(d_embed, m=m, grid_n=grid_n)
        self.decoder = Decoder(d_embed, out_ch)
        self.d_embed = d_embed; self.m = m; self.K_local = K_local; self.tau = tau; self.lam_geo = lam_geo

    def forward(self, x, mask_mae):
        B,T,F,H,W = x.shape
        x_ = x.reshape(B, T*F, H, W)
        z = self.encoder(x_)
        u = self.mapper(z)
        zf = z.permute(0,2,3,1).reshape(-1, self.d_embed)
        uf = u.permute(0,2,3,1).reshape(-1, self.m)
        a, bmu = self.protos.soft_assign(zf, uf, tau=self.tau, lam_geo=self.lam_geo)
        mem = (a @ self.protos.w).reshape(B,H,W,self.d_embed).permute(0,3,1,2).contiguous()
        z_tilde = z + mem
        y = self.decoder(z_tilde)
        mask = mask_mae.reshape(B, T*F, H, W)
        recon = y * mask
        target = x_ * mask
        return recon, target, (u, a, bmu)

def masked_l1(recon, target):
    denom = (target!=0).float().sum() + 1e-6
    return (recon - target).abs().sum() / denom

def info_nce(anchor, positive, temperature=0.07):
    B,C,H,W = anchor.shape
    A = anchor.reshape(B, C, -1).mean(-1)
    P = positive.reshape(B, C, -1).mean(-1)
    A = F.normalize(A, dim=-1); P = F.normalize(P, dim=-1)
    logits = A @ P.t() / temperature
    labels = torch.arange(B, device=anchor.device)
    return F.cross_entropy(logits, labels)

def assignment_entropy(a):
    p = a + 1e-9
    return (-(p * torch.log(p)).sum(-1)).mean()
