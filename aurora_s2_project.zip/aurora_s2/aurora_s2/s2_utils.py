
import os, re, zipfile, datetime
from typing import Dict, List, Optional, Tuple
from osgeo import gdal, osr

# Ensure GDAL raises exceptions
gdal.UseExceptions()

BAND_PREFERENCE = {
    "B02": [10,20,60],
    "B03": [10,20,60],
    "B04": [10,20,60],
    "B08": [10,20,60],
    "B05": [20,10,60],
    "B06": [20,10,60],
    "B07": [20,10,60],
    "B8A": [20,10,60],
    "B11": [20,10,60],
    "B12": [20,10,60],
    "B01": [60,20,10],
    "B09": [60,20,10],
    "SCL": [20,10,60],
}

BAND_RE = re.compile(r".*_(B0[1-9]|B1[0-2]|B8A)_(10m|20m|60m)\.jp2$", re.IGNORECASE)
SCL_RE  = re.compile(r".*_(SCL)_(10m|20m|60m)\.jp2$", re.IGNORECASE)

def list_zip_products(input_dir: str, max_products: int=0) -> List[str]:
    zips = [os.path.join(input_dir, f) for f in os.listdir(input_dir) if f.lower().endswith(".zip")]
    zips.sort()
    return zips[:max_products] if max_products and max_products>0 else zips

def parse_datetime_from_name(name: str) -> Optional[datetime.datetime]:
    m = re.search(r"(\d{8}T\d{6})", name)
    if not m: return None
    s = m.group(1)
    try:
        return datetime.datetime.strptime(s, "%Y%m%dT%H%M%S")
    except:
        return None

def list_band_paths_in_zip(zip_path: str) -> Dict[str, List[str]]:
    mapping = {}
    with zipfile.ZipFile(zip_path, 'r') as zf:
        for n in zf.namelist():
            if n.endswith("/"):
                continue
            if n.lower().endswith(".jp2") and ("IMG_DATA" in n or "QI_DATA" in n):
                bn = None
                m = BAND_RE.match(n)
                if m:
                    bn = m.group(1).upper()
                else:
                    m2 = SCL_RE.match(n)
                    if m2:
                        bn = "SCL"
                if bn:
                    mapping.setdefault(bn, []).append(n)
    return mapping

def choose_best_band_path(paths: List[str], band: str) -> Optional[str]:
    prefs = BAND_PREFERENCE.get(band, [10,20,60])
    for res in prefs:
        for p in paths:
            if f"_{res}m.jp2" in p:
                return p
    return paths[0] if paths else None

def build_vsizip_path(zip_path: str, inner_path: str) -> str:
    return f"/vsizip/{zip_path}/{inner_path}"

def open_ds(path: str):
    ds = gdal.Open(path, gdal.GA_ReadOnly)
    if ds is None:
        raise RuntimeError(f"GDAL failed to open: {path}")
    return ds

def get_gt_srs(ds) -> Tuple[Tuple[float,...], str]:
    gt = ds.GetGeoTransform()
    srs_wkt = ds.GetProjection()
    return gt, srs_wkt

def warp_to_match(src_path: str, tmpl_ds, resample="bilinear", to_mem=True):
    # Warp src to match template dataset's geotransform/size/SRS.
    tmpl_gt = tmpl_ds.GetGeoTransform()
    tmpl_proj = tmpl_ds.GetProjection()
    x_size = tmpl_ds.RasterXSize
    y_size = tmpl_ds.RasterYSize
    xmin = tmpl_gt[0]
    ymax = tmpl_gt[3]
    xres = tmpl_gt[1]
    yres = tmpl_gt[5]  # negative
    xmax = xmin + x_size * xres
    ymin = ymax + y_size * yres
    dst_bounds = (xmin, ymin, xmax, ymax)

    res_alg = {
        "nearest": gdal.GRA_NearestNeighbour,
        "bilinear": gdal.GRA_Bilinear,
        "cubic": gdal.GRA_Cubic,
        "cubicspline": gdal.GRA_CubicSpline,
    }.get(resample, gdal.GRA_Bilinear)

    dst = gdal.Warp(
        "", src_path,
        options=gdal.WarpOptions(
            format="MEM" if to_mem else "GTiff",
            outputBounds=dst_bounds,
            dstSRS=tmpl_proj,
            xRes=xres, yRes=abs(yres),
            targetAlignedPixels=True,
            resampleAlg=res_alg,
            multithread=True,
        )
    )
    if dst is None:
        raise RuntimeError(f"gdal.Warp failed for {src_path}")
    return dst

def create_ref_grid_from_zip(zip_path: str, band="B02"):
    mapping = list_band_paths_in_zip(zip_path)
    inner = choose_best_band_path(mapping.get(band, []), band)
    if not inner:
        raise RuntimeError(f"No {band} found in {zip_path}")
    vpath = build_vsizip_path(zip_path, inner)
    ds = open_ds(vpath)
    return ds, vpath

def scl_cloud_mask(scl_array, dilate_iter=1):
    import numpy as np
    scl = scl_array.astype(np.uint8)
    cloudy = (scl==0)|(scl==1)|(scl==3)|(scl==8)|(scl==9)|(scl==10)|(scl==11)
    if dilate_iter>0:
        for _ in range(dilate_iter):
            padded = np.pad(cloudy, 1, mode="edge")
            out = cloudy.copy()
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    out |= padded[1+dy:1+dy+cloudy.shape[0], 1+dx:1+dx+cloudy.shape[1]]
            cloudy = out
    return cloudy
