
import os
import torch
from torch.utils.data import DataLoader
from .config import Config
from .dataset import AuroraTimePatchDataset, FEAT_KEYS
from .preprocess import build_time_stack
from .aurora_model import Aurora, masked_l1, info_nce, assignment_entropy

def train(cfg: Config):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    os.makedirs(cfg.work_dir, exist_ok=True)

    entries, ref_ds = build_time_stack(cfg.input_dir, max_products=cfg.max_products, ref_tif=cfg.ref_tif)
    print(f"[INFO] Loaded {len(entries)} products. Reference grid from {'ref_tif' if cfg.ref_tif else 'B02'}: {ref_ds.RasterXSize}x{ref_ds.RasterYSize}")

    dataset = AuroraTimePatchDataset(entries, window=cfg.window, patch=cfg.patch, samples=cfg.samples_per_epoch*cfg.epochs)
    loader = DataLoader(dataset, batch_size=cfg.batch_size, shuffle=True, num_workers=0, drop_last=True)

    in_ch = cfg.window * len(FEAT_KEYS)
    model = Aurora(in_ch=in_ch, out_ch=in_ch, d_embed=cfg.d_embed, m=cfg.atlas_m, grid_n=cfg.grid_n, K_local=cfg.K_local, tau=cfg.tau, lam_geo=cfg.lam_geo).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)

    for epoch in range(cfg.epochs):
        model.train()
        it_per_epoch = max(1, cfg.samples_per_epoch // cfg.batch_size)
        for it, (feats, mask_mae, target_next, has_next_flag) in enumerate(loader):
            if it >= it_per_epoch: break
            feats, mask_mae, target_next = feats.to(device), mask_mae.to(device), target_next.to(device)
            recon, target, (u,a,bmu) = model(feats, mask_mae)
            L_mae = masked_l1(recon, target) * cfg.w_mae
            L_cpc = info_nce(recon, target_next.unsqueeze(1).repeat(1, feats.shape[1], 1, 1)) * cfg.w_cpc
            L_topo = assignment_entropy(a) * cfg.w_topo
            L = L_mae + L_cpc + L_topo
            opt.zero_grad(); L.backward(); opt.step()
            if it % 10 == 0:
                print(f"[E{epoch+1}] it {it}/{it_per_epoch}  L={L.item():.4f}  mae={L_mae.item():.4f} cpc={L_cpc.item():.4f} topo={L_topo.item():.4f}")
        ckpt = os.path.join(cfg.work_dir, f"aurora_epoch{epoch+1}.pt")
        torch.save({ "model": model.state_dict(), "cfg": vars(cfg) }, ckpt)
        print(f"[INFO] Saved {ckpt}")
    final = os.path.join(cfg.work_dir, "aurora_final.pt")
    torch.save({ "model": model.state_dict(), "cfg": vars(cfg) }, final)
    print(f"[INFO] Saved final model to {final}")
