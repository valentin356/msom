
import random
import numpy as np
import torch
from torch.utils.data import Dataset

FEAT_KEYS = ["B02","B03","B04","B08","B05","B06","B07","B8A","B11","B12","NDVI","NDRE","NDWI","MNDWI","NBR"]

class AuroraTimePatchDataset(Dataset):
    def __init__(self, time_entries, window=8, patch=32, samples=2000, seed=0):
        self.entries = time_entries
        self.T = window
        self.P = patch
        self.samples = samples
        self.rng = random.Random(seed)
        any_feats = self.entries[0][0]
        H, W = any_feats["B02"].shape
        self.H, self.W = H, W

    def __len__(self):
        return self.samples

    def __getitem__(self, idx):
        T, P = self.T, self.P
        tmax = max(0, len(self.entries) - T - 1)
        t0 = self.rng.randint(0, tmax) if tmax>0 else 0
        y0 = self.rng.randint(0, self.H-P)
        x0 = self.rng.randint(0, self.W-P)

        feats_t, masks_t = [], []
        for t in range(t0, t0+T):
            arrays, cloud, *_ = self.entries[t]
            F_stack = [arrays.get(k, np.full((self.H,self.W), np.nan, dtype=np.float32))[y0:y0+P, x0:x0+P] for k in FEAT_KEYS]
            feats_t.append(np.stack(F_stack, axis=0))
            masks_t.append(cloud[y0:y0+P, x0:x0+P])
        feats = np.stack(feats_t, axis=0)      # [T,F,P,P]
        cloudmask = np.stack(masks_t, axis=0)  # [T,P,P]
        feats = np.where(cloudmask[:, None, :, :], np.nan, feats)

        mu = np.nanmean(feats, axis=(0,2,3), keepdims=True)
        sd = np.nanstd(feats, axis=(0,2,3), keepdims=True) + 1e-6
        feats = (feats - mu) / sd
        feats = np.nan_to_num(feats, nan=0.0)

        mask_mae = np.zeros_like(feats, dtype=np.float32)
        numel = feats.size; mcount = int(0.2 * numel)
        flat = mask_mae.reshape(-1); flat[np.random.choice(numel, mcount, replace=False)] = 1.0
        mask_mae = mask_mae

        has_next = (t0+T < len(self.entries))
        if has_next:
            arrays, cloud, *_ = self.entries[t0+1]
            F_stack = [arrays.get(k, np.full((self.H,self.W), np.nan, dtype=np.float32))[y0:y0+P, x0:x0+P] for k in FEAT_KEYS]
            F_stack = (np.stack(F_stack, axis=0) - mu[0]) / sd[0]
            F_stack = np.nan_to_num(F_stack, nan=0.0)
            target_next = F_stack
        else:
            target_next = np.zeros((len(FEAT_KEYS), P, P), dtype=np.float32)

        return torch.from_numpy(feats).float(), torch.from_numpy(mask_mae).float(), torch.from_numpy(target_next).float(), torch.tensor([1.0 if has_next else 0.0], dtype=torch.float32)
