
import os, math
import numpy as np
import torch
from osgeo import gdal
from .config import Config
from .preprocess import build_time_stack
from .dataset import FEAT_KEYS
from .aurora_model import Aurora

def create_gdt_from_template(tmpl_ds, out_path, nbands=1, dtype=gdal.GDT_Float32, compress="LZW"):
    driver = gdal.GetDriverByName("GTiff")
    xsize = tmpl_ds.RasterXSize
    ysize = tmpl_ds.RasterYSize
    out_ds = driver.Create(out_path, xsize, ysize, nbands, dtype, options=[f"COMPRESS={compress}", "TILED=YES", "BIGTIFF=YES"])
    out_ds.SetProjection(tmpl_ds.GetProjection())
    out_ds.SetGeoTransform(tmpl_ds.GetGeoTransform())
    return out_ds

def export(cfg: Config):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    entries, ref_ds = build_time_stack(cfg.input_dir, max_products=cfg.max_products)
    os.makedirs(cfg.out_dir, exist_ok=True)

    ckpt = torch.load(os.path.join(cfg.work_dir, "aurora_final.pt"), map_location=device)
    mcfg = ckpt["cfg"]
    in_ch = cfg.window * len(FEAT_KEYS)
    out_ch = in_ch
    model = Aurora(in_ch=in_ch, out_ch=out_ch, d_embed=mcfg["d_embed"], m=mcfg["atlas_m"], grid_n=mcfg["grid_n"], K_local=mcfg["K_local"], tau=mcfg["tau"], lam_geo=mcfg["lam_geo"])
    model.load_state_dict(ckpt["model"])
    model.to(device)
    model.eval()

    arrays, cloud, *_ = entries[-1]
    H, W = arrays["B02"].shape

    T = cfg.window
    F = len(FEAT_KEYS)
    X = np.zeros((1,T,F,H,W), dtype=np.float32)
    for t in range(T):
        arrs, cld, *_ = entries[max(0, len(entries)-T+t)]
        for fi,k in enumerate(FEAT_KEYS):
            a = arrs.get(k, np.zeros((H,W), dtype=np.float32))
            X[0,t,fi] = a
    mu = np.nanmean(X, axis=(0,3,4), keepdims=True)
    sd = np.nanstd(X, axis=(0,3,4), keepdims=True) + 1e-6
    X = (X - mu) / sd
    X = np.nan_to_num(X, nan=0.0)

    MASK = np.zeros_like(X)

    with torch.no_grad():
        feats = torch.from_numpy(X).to(device)
        mask  = torch.from_numpy(MASK).to(device)
        recon, target, (u,a,bmu) = model(feats, mask)
        u = u[0].cpu().numpy()
        P = model.protos.P
        N = H*W
        a_np = a.cpu().numpy().reshape(H*W, P)
        ent = -(a_np * (np.log(a_np+1e-9))).sum(-1).reshape(H,W)
        bmu_np = bmu.cpu().numpy().reshape(H,W)
        rec = recon[0].cpu().numpy().reshape(T, F, H, W)[-1].mean(0)
        orig = X[0,-1].mean(0)
        resid = np.abs(rec - orig)

    out = os.path.join(cfg.out_dir, "aurora_derived.tif")
    ds = create_gdt_from_template(ref_ds, out, nbands=6, dtype=gdal.GDT_Float32)
    ds.GetRasterBand(1).WriteArray(u[0]); ds.GetRasterBand(1).SetDescription("aurora_u1")
    ds.GetRasterBand(2).WriteArray(u[1]); ds.GetRasterBand(2).SetDescription("aurora_u2")
    if u.shape[0] >= 3: ds.GetRasterBand(3).WriteArray(u[2])
    else: ds.GetRasterBand(3).WriteArray(np.zeros_like(u[0]))
    ds.GetRasterBand(3).SetDescription("aurora_u3")
    ds.GetRasterBand(4).WriteArray(ent); ds.GetRasterBand(4).SetDescription("aurora_assign_entropy")
    ds.GetRasterBand(5).WriteArray(bmu_np.astype(np.float32)); ds.GetRasterBand(5).SetDescription("aurora_cell_id")
    ds.GetRasterBand(6).WriteArray(resid); ds.GetRasterBand(6).SetDescription("aurora_forecast_resid")
    ds.FlushCache(); ds = None
    print(f"[INFO] Exported {out}")
