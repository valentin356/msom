# DRIFT — Sentinel-2 unlabeled pipeline
- GDAL-only, nearest neighbor resampling
- Preprocess supports `--ref` for **early clipping**
- Inference supports `--ref` to **restrict compute** to AOI
