class Config:
    embed_dim=64; code_heads=3; codebook_sizes=[256,512,1024]; topk=4; sinkhorn_iters=3; sinkhorn_eps=0.05;
    commit_weight=0.25; mask_ratio=0.75; tile=256; overlap=32; crf_weight=0.6; crf_iters=5
