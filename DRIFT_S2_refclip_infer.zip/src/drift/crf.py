import torch.nn.functional as F
def meanfield_potts(unary_logits,image=None,weight=0.6,iters=5):
    Q=F.softmax(unary_logits,dim=1)
    for _ in range(iters):
        up=F.pad(Q,(0,0,1,0))[:,:,:-1,:]; down=F.pad(Q,(0,0,0,1))[:,:,1:,:]
        left=F.pad(Q,(1,0,0,0))[:,:,:,:-1]; right=F.pad(Q,(0,1,0,0))[:,:,:,1:]
        smooth=(up+down+left+right)/4.0; Q=F.softmax(unary_logits+weight*smooth,dim=1)
    return Q
