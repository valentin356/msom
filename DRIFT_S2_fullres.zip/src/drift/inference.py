import numpy as np, torch, torch.nn.functional as F
from ..geoutils import open_gdal, write_array_like
from .m2pt import M2PT
from .mrq import MRQ
from .config import Config
from .crf import meanfield_potts
from osgeo import gdal

def _bounds_from_gt(gt, W, H):
    minx=gt[0]; maxy=gt[3]; maxx=minx+W*gt[1]+H*gt[2]; miny=maxy+W*gt[4]+H*gt[5]
    xmin=min(minx,maxx); xmax=max(minx,maxx); ymin=min(miny,maxy); ymax=max(miny,maxy); return xmin,ymin,xmax,ymax

def _intersection_window(stack_ds, ref_ds):
    gt_s=stack_ds.GetGeoTransform(); W=stack_ds.RasterXSize; H=stack_ds.RasterYSize
    gt_r=ref_ds.GetGeoTransform();   Wr=ref_ds.RasterXSize; Hr=ref_ds.RasterYSize
    if stack_ds.GetProjection()!=ref_ds.GetProjection():
        return 0,0,W,H
    xs,ys,xe,ye=_bounds_from_gt(gt_s,W,H); xr,yr,xR,yR=_bounds_from_gt(gt_r,Wr,Hr)
    xmin=max(xs,xr); ymin=max(ys,yr); xmax=min(xe,xR); ymax=min(ye,yR)
    if xmax<=xmin or ymax<=ymin: return None
    inv = gdal.InvGeoTransform(gt_s)
    if inv is None: return 0,0,W,H
    ulx=int(np.floor(inv[0]*xmin + inv[1]*ymax + inv[2])); uly=int(np.floor(inv[3]*xmin + inv[4]*ymax + inv[5]))
    lrx=int(np.ceil (inv[0]*xmax + inv[1]*ymin + inv[2])); lry=int(np.ceil (inv[3]*xmax + inv[4]*ymin + inv[5]))
    ulx=max(0,min(ulx,W)); uly=max(0,min(uly,H)); lrx=max(0,min(lrx,W)); lry=max(0,min(lry,H))
    return ulx,uly,max(0,lrx-ulx),max(0,lry-uly)

def infer(stack_path,weights_path,out_prefix,device='cpu',tile=256,overlap=32,ref_path=None):
    ds=open_gdal(stack_path); C=ds.RasterCount; H=ds.RasterYSize; W=ds.RasterXSize
    ckpt=torch.load(weights_path,map_location='cpu'); model=M2PT(in_ch=C,dim=Config.embed_dim).to(device)
    quant=MRQ(dim=Config.embed_dim,heads=Config.code_heads,Ks=Config.codebook_sizes,topk=Config.topk,sink_iters=Config.sinkhorn_iters,sink_eps=Config.sinkhorn_eps).to(device)
    model.load_state_dict(ckpt['m2pt'],strict=False); quant.load_state_dict(ckpt['mrq'],strict=False); model.eval()
    x0=y0=0; Wwin=W; Hwin=H
    if ref_path is not None:
        try:
            ref_ds=open_gdal(ref_path); win=_intersection_window(ds,ref_ds)
            if win is None:
                print('No intersection with reference; exiting.'); return True
            x0,y0,Wwin,Hwin=win
        except Exception as e:
            print('Ref clip error, skipping:', e)
    labels=np.zeros((Hwin, Wwin),dtype=np.uint16); prob=np.zeros((Hwin, Wwin),dtype=np.float32); entr=np.zeros((Hwin, Wwin),dtype=np.float32)
    step=tile-overlap; head=0
    for y in range(y0, y0+Hwin, step):
        h=min(tile, y0+Hwin - y)
        for x in range(x0, x0+Wwin, step):
            w=min(tile, x0+Wwin - x)
            arr=np.stack([ds.GetRasterBand(i+1).ReadAsArray(xoff=x,yoff=y,win_xsize=w,win_ysize=h) for i in range(C)],axis=0).astype(np.float32)
            t=torch.from_numpy(arr[None,...])
            with torch.no_grad():
                z,_=model(t); logits,_=quant(z); lg=logits[head]; B,N,K=lg.shape; hq, wq = z.shape[-2], z.shape[-1]
                lg2d_low = lg.reshape(1, hq, wq, K).permute(0,3,1,2)
                # upsample logits to input tile size (nearest)
                lg2d = torch.nn.functional.interpolate(lg2d_low, size=(h, w), mode='nearest')
                Q=F.softmax(lg2d,dim=1); e=-(Q*(Q.clamp_min(1e-6).log())).sum(dim=1); top_p,top_c=Q.max(dim=1)
                labels[y-y0:y-y0+h, x-x0:x-x0+w]=top_c[0].cpu().numpy().astype(np.uint16)
                prob[y-y0:y-y0+h, x-x0:x-x0+w]=top_p[0].cpu().numpy(); entr[y-y0:y-y0+h, x-x0:x-x0+w]=e[0].cpu().numpy()
    # Write out clipped-sized rasters using a synthetic ref (copy geotransform for the window)
    gt = list(ds.GetGeoTransform()); gt[0] = gt[0] + x0*gt[1] + y0*gt[2]; gt[3] = gt[3] + x0*gt[4] + y0*gt[5]
    # Build a small in-memory dataset-like wrapper for write_array_like
    class _Ref: pass
    ref=_Ref(); ref.RasterXSize=Wwin; ref.RasterYSize=Hwin
    ref.GetGeoTransform=lambda: tuple(gt); ref.GetProjection=lambda: ds.GetProjection()
    from ..geoutils import create_like
    write_array_like(ref, out_prefix+'codes.tif', labels, dtype=gdal.GDT_UInt16)
    write_array_like(ref, out_prefix+'prob.tif', prob, dtype=gdal.GDT_Float32)
    write_array_like(ref, out_prefix+'entropy.tif', entr, dtype=gdal.GDT_Float32)
    # CRF on the clipped window
    labels_crf=np.zeros_like(labels,dtype=np.uint16)
    for y in range(y0, y0+Hwin, step):
        h=min(tile, y0+Hwin - y)
        for x in range(x0, x0+Wwin, step):
            w=min(tile, x0+Wwin - x)
            arr=np.stack([ds.GetRasterBand(i+1).ReadAsArray(xoff=x,yoff=y,win_xsize=w,win_ysize=h) for i in range(C)],axis=0).astype(np.float32)
            t=torch.from_numpy(arr[None,...])
            with torch.no_grad():
                z,_=model(t); logits,_=quant(z); lg=logits[head]; B,N,K=lg.shape; hq, wq = z.shape[-2], z.shape[-1]
                lg2d_low = lg.reshape(1, hq, wq, K).permute(0,3,1,2)
                # upsample logits to input tile size (nearest)
                lg2d = torch.nn.functional.interpolate(lg2d_low, size=(h, w), mode='nearest')
                Q=meanfield_potts(lg2d,None,weight=Config.crf_weight,iters=Config.crf_iters); top_p,top_c=Q.max(dim=1)
                labels_crf[y-y0:y-y0+h, x-x0:x-x0+w]=top_c[0].cpu().numpy().astype(np.uint16)
    write_array_like(ref, out_prefix+'labels_crf.tif', labels_crf, dtype=gdal.GDT_UInt16)
    import numpy as np
    thr=np.quantile(entr,0.25); conf=(entr<=thr).astype(np.uint8); write_array_like(ref, out_prefix+'confmask.tif', conf, dtype=gdal.GDT_Byte)
    return True
