import torch
import torch.nn as nn

class ConvBlock(nn.Module):
    def __init__(self, c_in, c_out, k=3, s=1):
        super().__init__()
        p = k//2
        self.net = nn.Sequential(
            nn.Conv2d(c_in, c_out, k, s, p),
            nn.GroupNorm(4, c_out),
            nn.GELU()
        )
    def forward(self, x):
        return self.net(x)

class Encoder(nn.Module):
    def __init__(self, in_ch, dim=64, down_factor=1):
        super().__init__()
        # Choose strides to achieve the requested down_factor
        if down_factor == 4:
            strides = [2, 1, 2, 1]   # total /4
        elif down_factor == 2:
            strides = [2, 1, 1, 1]   # total /2
        else:
            strides = [1, 1, 1, 1]   # full-res
        self.stem = nn.Sequential(
            ConvBlock(in_ch, 64, 5, strides[0]),
            ConvBlock(64, 64, 3, strides[1]),
            ConvBlock(64, 96, 3, strides[2]),
            ConvBlock(96, dim, 3, strides[3]),
        )
    def forward(self, x):
        return self.stem(x)

class Decoder(nn.Module):
    def __init__(self, in_ch, dim=64, out_ch=None, down_factor=1):
        super().__init__()
        self.out_ch = out_ch or in_ch
        up_layers = []
        up_layers += [ConvBlock(dim, 96, 3, 1)]
        # Mirror upsampling to get back to input size
        if down_factor >= 2:
            up_layers += [nn.Upsample(scale_factor=2, mode='nearest'),
                          ConvBlock(96, 64, 3, 1)]
        else:
            up_layers += [ConvBlock(96, 64, 3, 1)]
        if down_factor >= 4:
            up_layers += [nn.Upsample(scale_factor=2, mode='nearest'),
                          ConvBlock(64, 64, 3, 1)]
        else:
            up_layers += [ConvBlock(64, 64, 3, 1)]
        up_layers += [ConvBlock(64, self.out_ch, 1, 1)]
        self.net = nn.Sequential(*up_layers)
    def forward(self, z):
        return self.net(z)

class M2PT(nn.Module):
    def __init__(self, in_ch, dim=64, down_factor=1):
        super().__init__()
        self.enc = Encoder(in_ch, dim, down_factor=down_factor)
        self.dec = Decoder(in_ch, dim, out_ch=in_ch, down_factor=down_factor)
        self.mask_token = nn.Parameter(torch.zeros(1, in_ch, 1, 1))

    def forward(self, x, mask=None):
        if mask is not None:
            x_in = x*(1-mask) + self.mask_token*mask
        else:
            x_in = x
        z = self.enc(x_in)
        x_hat = self.dec(z)
        return z, x_hat
