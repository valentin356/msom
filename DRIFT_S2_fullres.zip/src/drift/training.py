import os, numpy as np, torch
from torch.utils.data import Dataset, DataLoader
from .m2pt import M2PT
from .mrq import MRQ
from .config import Config
from ..utils.augment import random_block_mask, normalize_minmax
from ..geoutils import open_gdal
class StackDataset(Dataset):
    def __init__(self,stack_path,tile=256,samples=1024):
        self.ds=open_gdal(stack_path); self.tile=tile; self.samples=samples
        self.C=self.ds.RasterCount; self.H=self.ds.RasterYSize; self.W=self.ds.RasterXSize
    def __len__(self): return self.samples
    def __getitem__(self,idx):
        import random
        x=random.randint(0,max(0,self.W-self.tile)); y=random.randint(0,max(0,self.H-self.tile))
        arr=np.stack([self.ds.GetRasterBand(i+1).ReadAsArray(xoff=x,yoff=y,win_xsize=self.tile,win_ysize=self.tile) for i in range(self.C)],axis=0).astype(np.float32)
        return torch.from_numpy(arr)
def train_unlabeled(stack_path,epochs=2,tile=256,save_path='models/drift.ckpt',device='cpu'):
    ds=open_gdal(stack_path); C=ds.RasterCount
    model=M2PT(in_ch=C,dim=Config.embed_dim).to(device)
    quant=MRQ(dim=Config.embed_dim,heads=Config.code_heads,Ks=Config.codebook_sizes,topk=Config.topk,sink_iters=Config.sinkhorn_iters,sink_eps=Config.sinkhorn_eps).to(device)
    opt=torch.optim.Adam(list(model.parameters())+list(quant.parameters()),lr=1e-3)
    loader=DataLoader(StackDataset(stack_path,tile=tile,samples=512*epochs),batch_size=4,shuffle=True,num_workers=0)
    for ep in range(epochs):
        for i,b in enumerate(loader):
            b=b.to(device); b=normalize_minmax(b); x_mask,mask=random_block_mask(b,mask_ratio=Config.mask_ratio,block=8)
            z,x_hat=model(x_mask,mask=mask); rec=((x_hat-b)**2*mask).sum()/(mask.sum()+1e-6)
            logits,qfs=quant(z); _,hard=quant.balanced_assign(logits); import torch.nn.functional as F
            commit=quant.commit_losses(qfs,hard,weight=Config.commit_weight)
            loss=rec+commit; opt.zero_grad(); loss.backward(); opt.step()
            if i%50==0: print(f'[{ep}:{i}] loss={loss.item():.4f} rec={rec.item():.4f} com={commit.item():.4f}')
    os.makedirs(os.path.dirname(save_path),exist_ok=True); torch.save({'m2pt':model.state_dict(),'mrq':quant.state_dict(),'bands':C},save_path)
    print('Saved',save_path)
