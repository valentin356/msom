# DRIFT — Sentinel-2 unlabeled pipeline
- GDAL-only, nearest neighbor resampling
- Preprocess supports `--ref` for **early clipping**
- Inference supports `--ref` to **restrict compute** to AOI


### Output resolution
- Set `Config.down_factor = 1` for **native 10 m** outputs (default now).
- Use `2` (20 m) or `4` (40 m) only if you need faster inference and can tolerate coarser outputs.
- Changing `down_factor` **requires re-training** for best quality.
