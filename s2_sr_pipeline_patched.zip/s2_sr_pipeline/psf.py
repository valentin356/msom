
import torch, torch.nn.functional as F
def gaussian_kernel2d(ks: int, sigma: float, device=None, dtype=None):
    ax = torch.arange(ks, device=device, dtype=dtype) - (ks-1)/2
    xx, yy = torch.meshgrid(ax, ax, indexing="ij")
    k = torch.exp(-(xx**2 + yy**2)/(2*sigma**2))
    return k / k.sum()
def band_psf_kernel(band_index: int, ks: int=9, device=None, dtype=None):
    sigma = 1.2 if band_index in [1,2,3,7] else (2.0 if band_index in [4,5,6,8,10,11] else 3.5)
    return gaussian_kernel2d(ks, sigma, device=device, dtype=dtype)
def degrade_psf_downsample(x, stride:int=10, kernel_size:int=9):
    B,C,H,W = x.shape
    Wk = torch.stack([band_psf_kernel(b, kernel_size, x.device, x.dtype) for b in range(C)], dim=0).unsqueeze(1)
    x_blur = F.conv2d(x, Wk, padding=kernel_size//2, groups=C)
    return x_blur[:,:,::stride,::stride]
