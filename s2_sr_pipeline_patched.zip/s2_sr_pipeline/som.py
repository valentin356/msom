
import torch, torch.nn as nn, torch.nn.functional as F
class GraphSOM(nn.Module):
    def __init__(self, codebook:int, bands:int, sigma:float=1.5):
        super().__init__()
        self.prototypes = nn.Parameter(torch.rand(codebook, bands)*0.05)
    def forward(self, x):
        x_n = F.normalize(x, dim=-1); p_n = F.normalize(self.prototypes, dim=-1)
        sim = x_n @ p_n.T
        w = F.softmax(sim*3.0, dim=-1)
        return w, self.prototypes
