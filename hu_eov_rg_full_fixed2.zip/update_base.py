
import argparse, os, pandas as pd, math
from hu_eov_rg.io_any import load_any_table
from hu_eov_rg.io_parquet_cfg import normalize_df_with_schema
from hu_eov_rg.coords import ensure_eov_coords
from hu_eov_rg.store import find_latest_base_version, save_new_base_version
from hu_eov_rg.raster_export import export_rasters, export_diagnostics, export_diffs, generate_html_report

KEY_COLS = ["settlement","street","house_number"]

def _read_meta(store_dir: str):
    meta_path = os.path.join(store_dir, "rasters", "meta.json")
    if os.path.exists(meta_path):
        import json
        with open(meta_path, "r", encoding="utf-8") as f:
            m = json.load(f)
        return m["base_res_m"], m["x0"], m["y0"], m.get("levels",[7,10])
    return 2048.0, None, None, [7,10]

def _infer_origin(df: pd.DataFrame):
    x0 = float(df["eov_x"].min() - 1000.0)
    y0 = float(df["eov_y"].min() - 1000.0)
    return x0, y0

def main():
    ap = argparse.ArgumentParser(description="Frissítés – új base verzió létrehozása a legfrissebb V alapján, raszterekkel és diffekkel.")
    ap.add_argument("--input", required=True, help="Frissítő állomány (Parquet/Excel/CSV).")
    ap.add_argument("--schema", required=True, help="Sémadefiníció (JSON/YAML).")
    ap.add_argument("--store", required=True, help="Store könyvtár.")
    args = ap.parse_args()

    v, latest = find_latest_base_version(args.store)
    if not latest:
        raise SystemExit("Nincs meglévő base a store-ban. Futtasd először a seed_base.py-t.")

    base = pd.read_parquet(latest)
    upd_raw = load_any_table(args.input)
    upd_norm = normalize_df_with_schema(upd_raw, args.schema)
    upd_raw_conv = ensure_eov_coords(upd_raw)
    if ("EOV_X" in upd_norm.columns and "EOV_Y" in upd_norm.columns):
        pass
    else:
        if ("EOV_X" in upd_raw_conv.columns) and ("EOV_Y" in upd_raw_conv.columns):
            upd_norm["EOV_X"] = upd_raw_conv["EOV_X"]
            upd_norm["EOV_Y"] = upd_raw_conv["EOV_Y"]
    upd_norm["eov_x"] = upd_norm.get("EOV_Y")
    upd_norm["eov_y"] = upd_norm.get("EOV_X")
    upd_norm["has_coords"] = upd_norm["eov_x"].notna() & upd_norm["eov_y"].notna()

    base_keyed = base.set_index(KEY_COLS)
    upd_keyed = upd_norm.set_index(KEY_COLS)
    combined = base_keyed.combine_first(upd_keyed)
    combined.update(upd_keyed)
    combined = combined.reset_index()
    new_path = save_new_base_version(args.store, combined, version=v+1)
    print(f"Base V{v+1} created: {new_path}")

    # Rasters & diagnostics using consistent origin/resolution
    base_res_m, x0, y0, levels = _read_meta(args.store)
    if x0 is None or y0 is None:
        x0, y0 = _infer_origin(combined[combined["has_coords"]])

    # Build edges for metrics
    df = combined[combined["has_coords"]].copy()
    df["house_number"] = df["house_number"].astype(str)
    df["base_num"] = df["house_number"].str.extract(r"(\\d+)").astype(float)
    def _parity_safe(x):
        import pandas as pd
        if pd.isna(x):
            return None
        try:
            n = int(x)
        except Exception:
            return None
        return "even" if (n % 2 == 0) else "odd"
    df["parity"] = df["base_num"].apply(_parity_safe)%2==0 else "odd" if not pd.isna(x) else None)
    edges = []
    for (sett, street, par), g in df.groupby(["settlement","street","parity"]):
        g = g.dropna(subset=["base_num"]).sort_values("base_num")
        prev=None
        for _,r in g.iterrows():
            if prev is not None:
                d = math.hypot(r["eov_x"]-prev["eov_x"], r["eov_y"]-prev["eov_y"])
                tanya_flag = any(("tanya" in str(v).lower()) for v in [prev.get("tags",""), r.get("tags",""), street])
                sparse = d > 200.0
                edges.append({"settlement":sett,"street":street,"parity":par,
                              "x_lo":prev["eov_x"],"y_lo":prev["eov_y"],
                              "x_hi":r["eov_x"],"y_hi":r["eov_y"],
                              "gap_m":float(d),"interp_allowed": bool(not (tanya_flag or sparse))})
            prev=r
    edges_df = pd.DataFrame(edges)

    curr_ras_dir = os.path.join(args.store, "rasters", f"V{v+1}")
    curr_diag_dir = os.path.join(args.store, "diagnostics", f"V{v+1}")
    os.makedirs(curr_ras_dir, exist_ok=True)
    os.makedirs(curr_diag_dir, exist_ok=True)
    export_rasters(combined, edges_df, curr_ras_dir, base_res_m, x0, y0, levels=levels)
    export_diagnostics(combined, edges_df, curr_diag_dir)
    # HTML gyorsriport az aktuális verzióról
    report_path = os.path.join(curr_diag_dir, 'report.html')
    prev_label = f'V{v}'
    # diff képek mappája (ha van)
    diffs_path = os.path.join(args.store, 'rasters', 'diffs', f'V{v+1}_vs_V{v}')
    generate_html_report(f'V{v+1}', curr_ras_dir, curr_diag_dir, report_path, prev_version_label=prev_label, diffs_dir=diffs_path if os.path.isdir(diffs_path) else None)

    # diffs vs previous version
    prev_ras_dir = os.path.join(args.store, "rasters", f"V{v}")
    if os.path.isdir(prev_ras_dir):
        diff_dir = os.path.join(args.store, "rasters", "diffs", f"V{v+1}_vs_V{v}")
        os.makedirs(diff_dir, exist_ok=True)
        export_diffs(prev_ras_dir, curr_ras_dir, diff_dir)

    prev_diag_dir = os.path.join(args.store, "diagnostics", f"V{v}")
    if os.path.isdir(prev_diag_dir):
        # simple JSON compare
        import json
        def _load(path): 
            with open(path, "r", encoding="utf-8") as f: 
                return json.load(f)
        prev_s = _load(os.path.join(prev_diag_dir, "summary.json"))
        curr_s = _load(os.path.join(curr_diag_dir, "summary.json"))
        delta = {k: (curr_s.get(k) - prev_s.get(k) if isinstance(curr_s.get(k), (int,float)) and isinstance(prev_s.get(k),(int,float)) else None) for k in curr_s}
        with open(os.path.join(curr_diag_dir, f"compare_to_V{v}.json"), "w", encoding="utf-8") as f:
            json.dump({"prev": prev_s, "curr": curr_s, "delta": delta}, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    main()
