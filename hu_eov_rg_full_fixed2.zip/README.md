
# hu_eov_rg_full

**Konfigurálható, verziózott, EOV-alapú raszter–gráf geokódoló** (Excel/Parquet/CSV bemenettel).  
Kiemelt funkciók:
- **Külső sémából** olvasott szintek (Település, Közterületnév, Közterület jellege, Házszám, Helyrajziszám, Épület, Lépcsőház, Szint, Ajtó, + Városrésznév/Településrésznév opcionális).
- **Koordináta-oszlopok ellenőrzése**: ha EOV (`EOV_X`/`EOV_Y`) vagy WGS84 (`lon`/`lat`) van → felismeri; ha WGS84 → **EOV konverzió** (pyproj). Ha egyik sincs, geokódolás során előállítja.
- **Verziózott base store**: `base_v1.parquet`, `base_v2.parquet`, ... A program mindig a **legfrissebb V**-t használja.
- **Ősfeltöltés** (`seed_base.py`) és **frissítés** (`update_base.py`).
- **Batch geokódolás** (`geocode_batch.py`) – kimenet **CSV**.

## Futtatás – Ősfeltöltés (V1)

```bash
python seed_base.py \
  --input /útvonal/alap.xlsx \
  --schema /útvonal/schema.json \
  --store  ./store
```

## Futtatás – Frissítés (Vn → Vn+1)

```bash
python update_base.py \
  --input /útvonal/frissites.parquet \
  --schema /útvonal/schema.json \
  --store  ./store
```

## Futtatás – Geokódolás (CSV kimenet)

```bash
python geocode_batch.py \
  --store   ./store \
  --schema  /útvonal/schema.json \
  --targets /útvonal/geokodolandok.xlsx \
  --out-csv geokodolt.csv
```

> Megjegyzés: WGS84→EOV konverzióhoz a környezetedben legyen telepítve: **pyproj**.



## Raszterek és hibatérképek (verziózott)

A `store/rasters/` alatt verziónként mentünk:
- `density_L{L}.csv` (+ `.png`): cím-ankerpontok száma cellánként.
- `nearest_dist_L{L}.csv` (+ `.png`): legközelebbi ismert pont távolsága (m) a cellaközéptől.
- `edge_gap_median_L{L}.csv` (+ `.png`): fontos élközök mediánja (m) a cellára vetítve.
- `interp_allowed_fraction_L{L}.csv` (+ `.png`): ahol van él, milyen arányban engedett az interpoláció.

A `store/rasters/diffs/V{new}_vs_V{old}/` mappában ugyanezek **különbsége** (current - previous).

A `store/diagnostics/V{n}/summary.json` összegző metrikákat tartalmaz, az újabb verziókhoz `compare_to_V{n-1}.json` diff is készül.

```
store/
  base_v1.parquet
  base_v2.parquet
  rasters/
    meta.json
    V1/
      density_L7.csv
      nearest_dist_L7.csv
      ...
    V2/
      ...
    diffs/
      V2_vs_V1/
        density_L7_diff.csv
        ...
  diagnostics/
    V1/summary.json
    V2/summary.json
    V2/compare_to_V1.json
```


### GeoTIFF export + HTML gyorsriport

- Minden raszterből készül **GeoTIFF** (`.tif`), ha a környezetben elérhető a `rasterio` könyvtár.
- A `diagnostics/Vn/report.html` egy **HTML gyorsriport**: összegző metrikák + beágyazott raszter-áttekintő képek, linkek a CSV/GeoTIFF fájlokra.  
- `update_base.py` futtatásakor a riport – ha elérhető – beemeli a **verzióközi különbségképeket** is.

Telepítés a teljes exporthoz:
```
pip install rasterio matplotlib
```


**Tesztkészlet:** az ősfeltöltés a projekt gyökerébe menti a `test_missing_seed_V1.csv` fájlt (azok a címek, amelyekben nincs koordináta).
