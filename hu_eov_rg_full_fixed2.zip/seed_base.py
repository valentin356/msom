
import argparse, os, math
import pandas as pd
from hu_eov_rg.io_any import load_any_table
from hu_eov_rg.io_parquet_cfg import normalize_df_with_schema
from hu_eov_rg.coords import ensure_eov_coords
from hu_eov_rg.store import save_new_base_version
from hu_eov_rg.raster_export import export_rasters, export_diagnostics, generate_html_report

def _write_raster_meta(store_dir: str, base_res_m: float, x0: float, y0: float, levels=(7,10)):
    meta_dir = os.path.join(store_dir, "rasters")
    os.makedirs(meta_dir, exist_ok=True)
    meta_path = os.path.join(meta_dir, "meta.json")
    meta = {"base_res_m": float(base_res_m), "x0": float(x0), "y0": float(y0), "levels": list(levels)}
    import json
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    return meta_path

def _load_meta_or_infer(store_dir: str, df, base_res_m: float):
    meta_path = os.path.join(store_dir, "rasters", "meta.json")
    if os.path.exists(meta_path):
        import json
        with open(meta_path, "r", encoding="utf-8") as f:
            meta = json.load(f)
        return meta["base_res_m"], meta["x0"], meta["y0"], meta.get("levels",[7,10])
    x0 = float(df["eov_x"].min() - 1000.0)
    y0 = float(df["eov_y"].min() - 1000.0)
    return base_res_m, x0, y0, [7,10]

def main():
    ap = argparse.ArgumentParser(description="Ősfeltöltés – létrehozza az első V1 base állományt a store-ba.")
    ap.add_argument("--input", required=True, help="Forrás (Parquet/Excel/CSV).")
    ap.add_argument("--schema", required=True, help="Sémadefiníció (JSON/YAML).")
    ap.add_argument("--store", required=True, help="Store könyvtár (ide menti a base_v1.parquet-et).")
    ap.add_argument("--base-res-m", type=float, default=2048.0, help="Raszter alapszint m/pixel.")
    ap.add_argument("--levels", type=int, nargs="+", default=[7,10], help="Raster szintek, pl. 7 10")
    args = ap.parse_args()

    raw = load_any_table(args.input)
    norm = normalize_df_with_schema(raw, args.schema)
    norm_raw_coords = ensure_eov_coords(raw)
    if ("EOV_X" in norm.columns and "EOV_Y" in norm.columns):
        pass
    else:
        if ("EOV_X" in norm_raw_coords.columns) and ("EOV_Y" in norm_raw_coords.columns):
            norm["EOV_X"] = norm_raw_coords["EOV_X"]
            norm["EOV_Y"] = norm_raw_coords["EOV_Y"]
    norm["eov_x"] = norm.get("EOV_Y")
    norm["eov_y"] = norm.get("EOV_X")
    norm["has_coords"] = norm["eov_x"].notna() & norm["eov_y"].notna()

    save_new_base_version(args.store, norm, version=1)
    print("Base V1 created.")

    # Export rasters & diagnostics
    base_res_m, x0, y0, levels = _load_meta_or_infer(args.store, norm[norm["has_coords"]], args.base_res_m)
    _write_raster_meta(args.store, base_res_m, x0, y0, levels)

    # Build edges DataFrame for metrics
    # reuse simple logic: consecutive HN per street+parity
    df = norm[norm["has_coords"]].copy()
    df["house_number"] = df["house_number"].astype(str)
    df["base_num"] = df["house_number"].str.extract(r"(\\d+)").astype(float)
    def _parity_safe(x):
        import math
        import pandas as pd
        if pd.isna(x):
            return None
        try:
            n = int(x)
        except Exception:
            return None
        return "even" if (n % 2 == 0) else "odd"
    df["parity"] = df["base_num"].apply(_parity_safe)%2==0 else "odd" if not pd.isna(x) else None)
    edges = []
    for (sett, street, par), g in df.groupby(["settlement","street","parity"]):
        g = g.dropna(subset=["base_num"]).sort_values("base_num")
        prev=None
        for _,r in g.iterrows():
            if prev is not None:
                d = math.hypot(r["eov_x"]-prev["eov_x"], r["eov_y"]-prev["eov_y"])
                tanya_flag = any(("tanya" in str(v).lower()) for v in [prev.get("tags",""), r.get("tags",""), street])
                sparse = d > 200.0
                edges.append({"settlement":sett,"street":street,"parity":par,
                              "x_lo":prev["eov_x"],"y_lo":prev["eov_y"],
                              "x_hi":r["eov_x"],"y_hi":r["eov_y"],
                              "gap_m":float(d),"interp_allowed": bool(not (tanya_flag or sparse))})
            prev=r
    edges_df = pd.DataFrame(edges)

    rasters_dir = os.path.join(args.store, "rasters", "V1")
    diags_dir = os.path.join(args.store, "diagnostics", "V1")
    os.makedirs(rasters_dir, exist_ok=True)
    os.makedirs(diags_dir, exist_ok=True)
    export_rasters(norm, edges_df, rasters_dir, base_res_m, x0, y0, levels=levels)
    export_diagnostics(norm, edges_df, diags_dir)
    # HTML gyorsriport
    report_path = os.path.join(args.store, 'diagnostics', 'V1', 'report.html')
    generate_html_report('V1', rasters_dir, diags_dir, report_path)

    # --- Test set from seed: rows without coordinates ---
    try:
        proj_root = os.path.dirname(os.path.abspath(__file__))
    except Exception:
        proj_root = "."
    test_out = os.path.join(proj_root, "test_missing_seed_V1.csv")
    missing = norm[~norm["has_coords"]].copy()
    missing.to_csv(test_out, index=False, encoding="utf-8")
    print(f"Saved test set to {test_out} (rows without coords from seed).")


if __name__ == "__main__":
    main()
