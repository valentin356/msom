
import pandas as pd
from .schema_loader import load_schema

def _pick(df: pd.DataFrame, spec, case_insensitive=True):
    if spec is None: return None
    candidates = spec if isinstance(spec, list) else [spec]
    cols = list(df.columns)
    if case_insensitive:
        lowmap = {c.lower(): c for c in cols}
        for c in candidates:
            if c is None: continue
            key = str(c).lower()
            if key in lowmap: return lowmap[key]
        return None
    else:
        for c in candidates:
            if c in cols: return c
        return None

def normalize_df_with_schema(df: pd.DataFrame, schema_path: str) -> pd.DataFrame:
    schema = load_schema(schema_path) or {}
    levels = schema.get("levels", {})
    coords = schema.get("coords", {})

    def col(spec): return _pick(df, spec, case_insensitive=True)

    country         = col(levels.get("country"))
    county          = col(levels.get("county"))
    settlement      = col(levels.get("settlement"))
    city_district   = col(levels.get("city_district"))       # Városrésznév (opcionális)
    settlement_part = col(levels.get("settlement_part"))     # Településrésznév (opcionális)
    district        = col(levels.get("district"))
    postcode        = col(levels.get("postcode"))
    street_name     = col(levels.get("street_name"))
    street_type     = col(levels.get("street_type"))
    house_number    = col(levels.get("house_number"))
    lot_number      = col(levels.get("lot_number"))
    building        = col(levels.get("building"))
    staircase       = col(levels.get("staircase"))
    floor           = col(levels.get("floor"))
    door            = col(levels.get("door"))
    subunit         = col(levels.get("subunit"))
    tags            = col(levels.get("tags"))

    eov_x_col       = col(coords.get("eov_x_col"))  # EASTING (X) -- pl. "EOV_Y"
    eov_y_col       = col(coords.get("eov_y_col"))  # NORTHING (Y) -- pl. "EOV_X"

    out = {}
    out["country"]          = df[country]         if country         else None
    out["county"]           = df[county]          if county          else None
    out["settlement"]       = df[settlement]      if settlement      else None
    out["city_district"]    = df[city_district]   if city_district   else None
    out["settlement_part"]  = df[settlement_part] if settlement_part else None
    out["district"]         = df[district]        if district        else None
    out["postcode"]         = df[postcode]        if postcode        else None
    out["street_name"]      = df[street_name]     if street_name     else None
    out["street_type"]      = df[street_type]     if street_type     else None
    out["house_number"]     = df[house_number]    if house_number    else None
    out["lot_number"]       = df[lot_number]      if lot_number      else None
    out["building"]         = df[building]        if building        else None
    out["staircase"]        = df[staircase]       if staircase       else None
    out["floor"]            = df[floor]           if floor           else None
    out["door"]             = df[door]            if door            else None
    out["subunit"]          = df[subunit]         if subunit         else None
    out["tags"]             = df[tags]            if tags            else ""

    out["eov_x"] = df[eov_x_col] if eov_x_col else None
    out["eov_y"] = df[eov_y_col] if eov_y_col else None

    norm = pd.DataFrame(out)
    # Compose 'street'
    if ("street_name" in norm.columns) and ("street_type" in norm.columns) and (norm["street_name"] is not None) and (norm["street_type"] is not None):
        norm["street"] = (norm["street_name"].astype(str).str.strip() + " " + norm["street_type"].astype(str).str.strip()).str.replace(r"\s+", " ", regex=True)
    else:
        norm["street"] = norm.get("street_name")

    # strip
    for c in ["country","county","settlement","city_district","settlement_part","district","postcode","street","street_name","street_type","house_number","lot_number","building","staircase","floor","door","subunit","tags"]:
        if c in norm.columns:
            try: norm[c] = norm[c].astype(str).str.strip()
            except: pass

    norm["has_coords"] = norm["eov_x"].notna() & norm["eov_y"].notna()
    return norm

def load_addresses_from_parquet_with_schema(parquet_path: str, schema_path: str) -> pd.DataFrame:
    df = pd.read_parquet(parquet_path)
    return normalize_df_with_schema(df, schema_path)
