
import math, pandas as pd
from .eov_graph import AddressGraphEOV, GeocoderEOV

def interleave_bits(n):
    n = (n | (n << 8)) & 0x00FF00FF
    n = (n | (n << 4)) & 0x0F0F0F0F
    n = (n | (n << 2)) & 0x33333333
    n = (n | (n << 1)) & 0x55555555
    return n

def morton2D(xi, yi):
    xi = int(xi) & 0xFFFFFFFF; yi = int(yi) & 0xFFFFFFFF
    return (interleave_bits(yi) << 1) | interleave_bits(xi)

class RasterIndexEOV:
    def __init__(self, base_res_m: float=2048.0, max_level: int=11, x0: float=None, y0: float=None):
        self.base_res_m = float(base_res_m)
        self.max_level = int(max_level)
        self.x0 = x0
        self.y0 = y0
        self.cells = [dict() for _ in range(self.max_level+1)]
        self.addr_df = None
        self.graph = None

    def fit_origin_from_df(self, df: pd.DataFrame, margin_m: float=1000.0):
        d = df[df["eov_x"].notna() & df["eov_y"].notna()]
        if d.empty:
            raise ValueError("No coordinates to infer origin from.")
        self.x0 = float(d["eov_x"].min() - margin_m)
        self.y0 = float(d["eov_y"].min() - margin_m)

    def _quantize(self, x, y, level):
        if self.x0 is None or self.y0 is None:
            raise ValueError("Raster origin (x0,y0) is not set. Call fit_origin_from_df() or pass x0,y0 to ctor.")
        res = self.base_res_m / (2**level)
        xi = int(math.floor((x - self.x0)/res))
        yi = int(math.floor((y - self.y0)/res))
        return xi, yi

    def _cell_key(self, x, y, level):
        xi, yi = self._quantize(x, y, level)
        return morton2D(max(0,xi), max(0,yi)), xi, yi

    def ingest_df(self, df_norm: pd.DataFrame):
        self.addr_df = df_norm.copy()

    def build_cells_from_coords(self, level_for_points: int=10):
        if self.addr_df is None:
            raise ValueError("Call ingest_df() first.")
        hn_level = min(self.max_level, int(level_for_points))
        for _, r in self.addr_df[self.addr_df["has_coords"]].iterrows():
            key, xi, yi = self._cell_key(r["eov_x"], r["eov_y"], hn_level)
            self.cells[hn_level][int(key)] = {
                "settlement": r.get("settlement"),
                "street": r.get("street"),
                "house_number": str(r.get("house_number")) if r.get("house_number") is not None else None,
                "eov_x": float(r["eov_x"]), "eov_y": float(r["eov_y"]),
                "xi": xi, "yi": yi, "level": hn_level, "tags": r.get("tags","")
            }

    def build_graph(self, sparse_gap_m: float=200.0):
        if self.addr_df is None: raise ValueError("Call ingest_df() first.")
        self.graph = AddressGraphEOV(self.addr_df, sparse_gap_m=sparse_gap_m)

    def geocoder(self):
        if self.graph is None: raise ValueError("Call build_graph() first.")
        return GeocoderEOV(self.graph, self.addr_df)

    def geocode(self, settlement, street, house_number, level_for_points: int=10):
        ggeo = self.geocoder().geocode(settlement, street, house_number)
        hn_level = min(self.max_level, int(level_for_points))
        key, xi, yi = self._cell_key(ggeo.eov_x, ggeo.eov_y, hn_level)
        return {
            "eov_x": ggeo.eov_x, "eov_y": ggeo.eov_y, "source": ggeo.source, "error_m": ggeo.error_m, "meta": ggeo.meta,
            "pixel": {"level": hn_level, "xi": xi, "yi": yi, "morton": int(key)}
        }

    def density_tiles(self, level: int=7):
        if self.addr_df is None: raise ValueError("Call ingest_df() first.")
        level = int(level)
        rows = []
        for _, r in self.addr_df[self.addr_df["has_coords"]].iterrows():
            key, xi, yi = self._cell_key(r["eov_x"], r["eov_y"], level)
            rows.append({"level": level, "morton": int(key), "xi": xi, "yi": yi})
        if not rows:
            return pd.DataFrame(columns=["level","morton","xi","yi","count"])
        df = pd.DataFrame(rows)
        agg = df.groupby(["level","morton","xi","yi"]).size().reset_index(name="count")
        return agg.sort_values("count", ascending=False)

class GeocoderRasterEOV:
    def __init__(self, raster_index: RasterIndexEOV):
        self.r = raster_index
        if self.r.graph is None: self.r.build_graph()
    def geocode(self, settlement, street, house_number, level_for_points: int=10):
        return self.r.geocode(settlement, street, house_number, level_for_points=level_for_points)
