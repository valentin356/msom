import re
_STREET_NORMALIZATION = {
    "u.": "utca","utca":"utca","út":"út","út.":"út","krt.":"körút","krt":"körút","körút":"körút",
    "rkp.":"rakpart","rakpart":"rakpart","sugárút":"sugárút","sétány":"sétány","köz":"köz",
    "tér":"tér","fasor":"fasor","lépcső":"lépcső","lejtő":"lejtő","dűlő":"dűlő","park":"park",
}

def normalize_street_name(name: str) -> str:
    name = name.strip()
    parts = name.split()
    if not parts: return name
    last = parts[-1].rstrip(".").lower()
    last_norm = _STREET_NORMALIZATION.get(last + ".", None) or _STREET_NORMALIZATION.get(last, None)
    if last_norm: parts[-1] = last_norm
    return " ".join(parts)

def _split_house_number(hn: str):
    import re
    if not hn: return {"kind":"unknown"}
    s = hn.strip().lower().replace(" ","").rstrip(".")
    mlot = re.fullmatch(r"(\d+)\s*/\s*(\d+)", s)
    if mlot: return {"kind":"lot","fraction": (int(mlot.group(1)), int(mlot.group(2)))}
    mrange = re.fullmatch(r"(\d+)\s*[-–]\s*(\d+)", s)
    if mrange: return {"kind":"range","start": int(mrange.group(1)), "end": int(mrange.group(2))}
    mstd = re.fullmatch(r"(\d+)([a-z]+)?", s)
    if mstd: return {"kind":"number","base": int(mstd.group(1)), "suffix": mstd.group(2) or ""}
    digits = "".join(ch for ch in s if ch.isdigit())
    if digits: return {"kind":"number","base": int(digits), "suffix": ""}
    return {"kind":"unknown"}

def parse_address_hu(raw: str):
    s = raw.strip()
    lower = s.lower()
    is_tanya = "tanya" in lower
    is_hrsz = ("hrsz" in lower) or ("helyrajzi" in lower)
    import re
    mpc = re.search(r"\b(\d{4})\b", s)
    postal_code = mpc.group(1) if mpc else None
    mdist = re.search(r"\b([ivxlcdm]{1,3})\.\s*ker", lower)
    district = mdist.group(1).upper() if mdist else None
    parts = [p.strip() for p in s.split(",") if p.strip()]
    settlement = parts[0] if len(parts)>=2 else None
    street_hn = parts[1] if len(parts)>=2 else parts[0] if parts else s
    m = re.search(r"(.+?)\s+(\d+[A-Za-z/–-]?\s*(?:[-–]\s*\d+)?)\b", street_hn)
    street = street_hn; house_number=None
    if m:
        street = m.group(1).strip(); house_number = m.group(2).strip()
    street = normalize_street_name(street)
    hn_parsed = _split_house_number(house_number) if house_number else {"kind":"unknown"}
    return {"raw":raw,"settlement":settlement,"district":district,"postal_code":postal_code,
            "street":street,"house_number":house_number,"hn_parsed":hn_parsed,
            "is_tanya":is_tanya,"is_hrsz":is_hrsz}
