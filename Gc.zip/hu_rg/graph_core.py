from dataclasses import dataclass
import math
import pandas as pd

def haversine_m(lat1, lon1, lat2, lon2):
    R = 6371000.0
    import math
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1); dl = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dl/2)**2
    return 2*R*math.atan2(math.sqrt(a), math.sqrt(1-a))

def parity(n:int)->str: return "even" if n%2==0 else "odd"

@dataclass
class GeoResult:
    lat: float; lon: float; source: str; error_m: float; meta: dict

class AddressGraph:
    def __init__(self, df_addresses: pd.DataFrame, sparse_gap_m: float=200.0):
        self.addr = df_addresses.copy()
        self.addr["house_number"] = self.addr["house_number"].astype(str)
        self.addr["base_num"] = self.addr["house_number"].str.extract(r"(\d+)").astype(float)
        if "settlement" not in self.addr.columns: self.addr["settlement"]=None
        if "tags" not in self.addr.columns: self.addr["tags"]=""
        self.addr["parity"] = self.addr["base_num"].apply(lambda x: parity(int(x)) if not math.isnan(x) else None)
        self.addr.sort_values(["settlement","street","parity","base_num"], inplace=True)
        self.sparse_gap_m = sparse_gap_m
        self.edges = self._build_edges()
        self.street_stats = self._build_density()
    def _build_edges(self):
        rows=[]
        for (sett, street, par), g in self.addr.groupby(["settlement","street","parity"]):
            g = g.dropna(subset=["base_num"]).sort_values("base_num")
            prev=None
            for _,r in g.iterrows():
                if prev is not None:
                    d = haversine_m(prev["lat"],prev["lon"],r["lat"],r["lon"])
                    tanya_flag = any(("tanya" in str(v).lower()) for v in [prev.get("tags",""), r.get("tags",""), street])
                    sparse = d > self.sparse_gap_m
                    rows.append({"settlement":sett,"street":street,"parity":par,
                                 "num_lo":int(prev["base_num"]),"num_hi":int(r["base_num"]),
                                 "lat_lo":prev["lat"],"lon_lo":prev["lon"],
                                 "lat_hi":r["lat"],"lon_hi":r["lon"],
                                 "gap_m":float(d),"tanya_edge":bool(tanya_flag),
                                 "sparse_edge":bool(sparse),
                                 "interp_allowed": bool(not (tanya_flag or sparse))})
                prev=r
        return pd.DataFrame(rows)
    def _build_density(self):
        stats=[]
        for (sett, street, par), g in self.edges.groupby(["settlement","street","parity"]):
            n = len(g); total = g["gap_m"].sum() if n else 0.0
            addr_count = n+1 if n else len(self.addr[(self.addr["settlement"]==sett)&(self.addr["street"]==street)&(self.addr["parity"]==par)])
            dens = (addr_count / (total/1000.0)) if total>0 else None
            stats.append({"settlement":sett,"street":street,"parity":par,
                          "addresses":int(addr_count),"total_length_m":float(total),
                          "density_per_km": float(dens) if dens else None,
                          "sparse_ratio": float(g["sparse_edge"].mean()) if n else 0.0,
                          "tanya_ratio": float(g["tanya_edge"].mean()) if n else 0.0,
                          "interp_allowed_fraction": float(g["interp_allowed"].mean()) if n else 0.0})
        return pd.DataFrame(stats)
    def density_map(self):
        return self.street_stats.sort_values(["settlement","street","parity"])
    def add_address_point(self, settlement, street, house_number, lat, lon, tags=""):
        new = {"settlement":settlement,"street":street,"house_number":str(house_number),
               "lat":float(lat),"lon":float(lon),"tags":tags}
        self.addr = pd.concat([self.addr, pd.DataFrame([new])], ignore_index=True)
        self.addr["base_num"] = self.addr["house_number"].str.extract(r"(\d+)").astype(float)
        self.addr["parity"] = self.addr["base_num"].apply(lambda x: parity(int(x)) if not math.isnan(x) else None)
        self.addr.sort_values(["settlement","street","parity","base_num"], inplace=True)
        self.edges = self._build_edges(); self.street_stats = self._build_density()

class GeocoderHU:
    def __init__(self, graph: AddressGraph): self.g=graph
    def geocode(self, settlement, street, hn) -> GeoResult:
        exact = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street)) & (self.g.addr["house_number"].eq(str(hn)))]
        if not exact.empty:
            r = exact.iloc[0]; return GeoResult(r["lat"], r["lon"], "exact", 0.0, {"match":"exact"})
        import re
        m = re.match(r"(\d+)", str(hn)); 
        if not m:
            group = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street))]
            if group.empty: raise ValueError("Street not found")
            return GeoResult(group["lat"].mean(), group["lon"].mean(), "street-centroid", 150.0, {"reason":"no-number"})
        base = int(m.group(1)); par = "even" if base%2==0 else "odd"
        group = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street)) & (self.g.addr["parity"].eq(par))].dropna(subset=["base_num"]).sort_values("base_num")
        if group.empty: group = self.g.addr[(self.g.addr["settlement"].eq(settlement)) & (self.g.addr["street"].eq(street))].dropna(subset=["base_num"]).sort_values("base_num")
        if group.empty: raise ValueError("Street not found")
        lower = group[group["base_num"] < base].tail(1); upper = group[group["base_num"] > base].head(1)
        if lower.empty or upper.empty:
            near = group.iloc[(group["base_num"]-base).abs().argsort().iloc[0]]
            return GeoResult(near["lat"], near["lon"], "nearest", 60.0, {"reason":"no-bracket"})
        lo, hi = lower.iloc[0], upper.iloc[0]
        edges = self.g.edges
        chain = edges[(edges["settlement"].eq(settlement)) & (edges["street"].eq(street)) & (edges["num_lo"].eq(int(lo["base_num"]))) & (edges["num_hi"].eq(int(hi["base_num"])))]
        if chain.empty or not bool(chain.iloc[0]["interp_allowed"]):
            d = haversine_m(lo["lat"], lo["lon"], hi["lat"], hi["lon"])
            if (base - int(lo["base_num"])) <= (int(hi["base_num"]) - base):
                return GeoResult(lo["lat"], lo["lon"], "anchor-no-interp", d/2, {"blocked_edge":True})
            else:
                return GeoResult(hi["lat"], hi["lon"], "anchor-no-interp", d/2, {"blocked_edge":True})
        ratio = (base - int(lo["base_num"])) / (int(hi["base_num"]) - int(lo["base_num"]))
        lat = lo["lat"] + ratio*(hi["lat"]-lo["lat"]); lon = lo["lon"] + ratio*(hi["lon"]-lo["lon"])
        gap_m = float(chain.iloc[0]["gap_m"])
        dens = self.g.density_map()
        drow = dens[(dens["settlement"].eq(settlement)) & (dens["street"].eq(street))]
        density = float(drow.iloc[0]["density_per_km"]) if not drow.empty and drow.iloc[0]["density_per_km"] else None
        err = (gap_m/2) / math.sqrt(max((density or 50.0)/50.0, 0.5))
        return GeoResult(lat, lon, "interpolated", float(err), {"gap_m":gap_m,"density_per_km":density})
