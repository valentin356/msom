import math, pandas as pd
from .graph_core import AddressGraph, GeocoderHU as GraphGeocoder

# Web Mercator
R = 6378137.0
def lonlat_to_merc(lon, lat):
    x = math.radians(lon)*R
    y = math.log(math.tan(math.pi/4 + math.radians(lat)/2))*R
    return x, y
def merc_to_lonlat(x, y):
    lon = math.degrees(x/R)
    lat = math.degrees(2*math.atan(math.exp(y/R)) - math.pi/2)
    return lon, lat

def interleave_bits(n):
    n = (n | (n << 8)) & 0x00FF00FF
    n = (n | (n << 4)) & 0x0F0F0F0F
    n = (n | (n << 2)) & 0x33333333
    n = (n | (n << 1)) & 0x55555555
    return n
def morton2D(xi, yi):
    xi = int(xi) & 0xFFFFFFFF; yi = int(yi) & 0xFFFFFFFF
    return (interleave_bits(yi) << 1) | interleave_bits(xi)

class RasterIndex:
    def __init__(self, base_res_m: float=2048.0, max_level: int=11, x0: float=1.5e6, y0: float=5.6e6):
        self.base_res_m = float(base_res_m)
        self.max_level = int(max_level)
        self.x0, self.y0 = float(x0), float(y0)
        self.cells = [dict() for _ in range(self.max_level+1)]
        self.addr_df = pd.DataFrame(columns=["settlement","street","house_number","lat","lon","tags"])
        self.graph = None
    def _quantize(self, lon, lat, level):
        x, y = lonlat_to_merc(lon, lat)
        res = self.base_res_m / (2**level)
        xi = int(math.floor((x - self.x0)/res))
        yi = int(math.floor((y - self.y0)/res))
        return xi, yi
    def _cell_key(self, lon, lat, level):
        xi, yi = self._quantize(lon, lat, level)
        return morton2D(max(0,xi), max(0,yi)), xi, yi
    def add_address(self, settlement, street, house_number, lat, lon, tags=""):
        hn_level = min(self.max_level, 10)
        key, xi, yi = self._cell_key(lon, lat, hn_level)
        self.cells[hn_level][int(key)] = {"settlement":settlement,"street":street,"house_number":str(house_number),
                                          "lat":float(lat),"lon":float(lon),"xi":xi,"yi":yi,"level":hn_level,"tags":tags}
        self.addr_df = pd.concat([self.addr_df, pd.DataFrame([{
            "settlement":settlement,"street":street,"house_number":str(house_number),
            "lat":float(lat),"lon":float(lon),"tags":tags}])], ignore_index=True)
    def build_graph(self, sparse_gap_m: float=200.0):
        self.graph = AddressGraph(self.addr_df, sparse_gap_m=sparse_gap_m)
    def geocode(self, settlement, street, house_number):
        if self.graph is None: self.build_graph()
        ggeo = GraphGeocoder(self.graph).geocode(settlement, street, house_number)
        hn_level = min(self.max_level, 10)
        key, xi, yi = self._cell_key(ggeo.lon, ggeo.lat, hn_level)
        return {"lat":ggeo.lat,"lon":ggeo.lon,"source":ggeo.source,"error_m":ggeo.error_m,"meta":ggeo.meta,
                "pixel":{"level":hn_level,"xi":xi,"yi":yi,"morton":int(key)}}
    def density_tiles(self, level: int=7):
        level = int(level)
        rows = []
        for _, r in self.addr_df.iterrows():
            key, xi, yi = self._cell_key(r["lon"], r["lat"], level)
            rows.append({"level": level, "morton": int(key), "xi": xi, "yi": yi})
        if not rows: 
            return pd.DataFrame(columns=["level","morton","xi","yi","count"])
        df = pd.DataFrame(rows)
        agg = df.groupby(["level","morton","xi","yi"]).size().reset_index(name="count")
        return agg.sort_values("count", ascending=False)

class GeocoderRaster:
    def __init__(self, raster_index: RasterIndex):
        self.r = raster_index
        if self.r.graph is None: self.r.build_graph()
    def geocode(self, settlement, street, house_number):
        return self.r.geocode(settlement, street, house_number)
    def update_with_confirmed(self, settlement, street, house_number, lat, lon, tags=""):
        self.r.add_address(settlement, street, house_number, lat, lon, tags)
        self.r.build_graph()
