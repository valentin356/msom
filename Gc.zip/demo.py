import pandas as pd
from hu_rg import RasterIndex, GeocoderRaster
df = pd.read_csv("data/addresses_sample.csv")
r = RasterIndex(base_res_m=2048.0, max_level=11)
for _, row in df.iterrows():
    r.add_address(row["settlement"], row["street"], row["house_number"], row["lat"], row["lon"], row.get("tags",""))
r.build_graph()
geo = GeocoderRaster(r)
print(geo.geocode("Budapest","Fő utca","2"))
print(geo.geocode("Budapest","Fő utca","8"))
print(geo.geocode("Kunszentmiklós","Fő út","2"))
print(r.density_tiles(level=7).head())
