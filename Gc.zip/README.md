# hu_raster_graph_geocoder

Raszter–gráf hibrid geokódoló magyar címekhez.

- Hierarchikus raszter (Web Mercator, power-of-two felbontások a szinteken).
- Sparsity: csak a címek pixeleit tároljuk (Morton/Z-order kulcs).
- Gráf a szomszédos házszámok közt; **tanya/ritka** él => **tiltott interpoláció**.
- Sűrűség: csempénkénti cím-szám (`density_tiles`), ill. utca hossza mentén `density_per_km`.
- Önjavítás: új cím hozzáadása frissíti a gráfot is.

## Példa

```python
import pandas as pd
from hu_rg import RasterIndex, GeocoderRaster

df = pd.read_csv("data/addresses_sample.csv")
r = RasterIndex(base_res_m=2048.0, max_level=11)  # ~2 m/pixel a 10. szinten
for _, row in df.iterrows():
    r.add_address(row["settlement"], row["street"], row["house_number"], row["lat"], row["lon"], row.get("tags",""))
r.build_graph()
geo = GeocoderRaster(r)

print(geo.geocode("Budapest","Fő utca","2"))
print(geo.geocode("Budapest","Fő utca","8"))   # interpolált (ha engedett él)
print(geo.geocode("Kunszentmiklós","Fő út","2"))  # tanya-él => tiltott
print(r.density_tiles(level=7).head())
```
