import os, re, time, argparse, pandas as pd
from hu_eov_rg.io_any import load_any_table
from hu_eov_rg.io_parquet_cfg import normalize_df_with_schema
from hu_eov_rg.coords import ensure_eov_coords
from hu_eov_rg.eov_raster import RasterIndexEOV
from hu_eov_rg.raster_export import export_rasters, export_diagnostics, generate_html_report
from hu_eov_rg.activation_index import build_activation_index
from hu_eov_rg.cadastre import load_geoparquet_polygons, split_parcels_and_streets, parcels_centroids, streets_axes_pca, frontage_points_from_polygons
from hu_eov_rg.logging_utils import setup_logging, get_logger

def find_latest_version(bases_dir):
    vs=[]
    for fn in os.listdir(bases_dir):
        m=re.match(r'V(\d+)\.parquet$',fn)
        if m: vs.append(int(m.group(1)))
    return max(vs) if vs else None

def main():
    ap=argparse.ArgumentParser(description='Frissítés – új Vn + egyfájlos cadastre')
    ap.add_argument('--input',required=True); ap.add_argument('--schema',required=True); ap.add_argument('--store',required=True)
    ap.add_argument('--base-res-m',type=float,default=2048.0); ap.add_argument('--levels',type=int,nargs='+',default=[9,10])
    ap.add_argument('--cadastre',type=str,default=None); ap.add_argument('--cad-geometry-col',type=str,default='geometry')
    ap.add_argument('--street-field',type=str,default=None); ap.add_argument('--street-values',type=str,default=None); ap.add_argument('--parcel-values',type=str,default=None)
    args=ap.parse_args()
    os.makedirs(args.store,exist_ok=True); log_path=os.path.join(args.store,'logs',f'update_base_{int(time.time())}.log')
    setup_logging(log_path); log=get_logger(__name__)
    bases_dir=os.path.join(args.store,'bases'); os.makedirs(bases_dir,exist_ok=True); last=find_latest_version(bases_dir); v=1 if not last else last+1
    raw=load_any_table(args.input); raw=ensure_eov_coords(raw); base=normalize_df_with_schema(raw,args.schema)
    base_path=os.path.join(bases_dir,f'V{v}.parquet'); base.to_parquet(base_path,index=False)
    r=RasterIndexEOV(base_res_m=args.base_res_m, max_level=max(args.levels)+1); r.ingest_df(base)
    if r.x0 is None or r.y0 is None: r.fit_origin_from_df(r.addr_df)
    r.build_cells_from_coords(); r.build_graph(sparse_gap_m=200.0)
    rasters_dir=os.path.join(args.store,'rasters',f'V{v}'); os.makedirs(rasters_dir,exist_ok=True)
    export_rasters(base,r.graph.edges,rasters_dir,args.base_res_m,r.x0,r.y0,levels=args.levels)
    for L in args.levels:
        A=build_activation_index(r.graph.edges,r.x0,r.y0,args.base_res_m,L); A.to_parquet(os.path.join(rasters_dir,f'activation_L{L}.parquet'),index=False)
    diag_dir=os.path.join(args.store,'diagnostics',f'V{v}'); os.makedirs(diag_dir,exist_ok=True)
    export_diagnostics(base,r.graph.edges,diag_dir); report_path=os.path.join(args.store,f'report_V{v}.html'); generate_html_report(f'V{v}',rasters_dir,diag_dir,report_path)
    if args.cadastre and args.street_field and args.street_values:
        cdir=os.path.join(args.store,'cadastre',f'V{v}'); os.makedirs(cdir,exist_ok=True)
        try:
            G=load_geoparquet_polygons(args.cadastre, geometry_col=args.cad_geometry_col, target_epsg=23700)
            P,S=split_parcels_and_streets(G, args.street_field, args.street_values, args.parcel_values)
            P.to_parquet(os.path.join(cdir,'parcels.parquet'),index=False); S.to_parquet(os.path.join(cdir,'streets.parquet'),index=False)
            parcels_centroids(P).to_parquet(os.path.join(cdir,'parcel_centroids.parquet'),index=False)
            streets_axes_pca(S).to_parquet(os.path.join(cdir,'streets_axis.parquet'),index=False)
            frontage_points_from_polygons(P,S,buffer_m=20.0).to_parquet(os.path.join(cdir,'frontage_points.parquet'),index=False)
        except Exception as e:
            log.exception(f'Cadastre feldolgozás hiba: {e}')
    else:
        log.info('Cadastre nem lett feldolgozva (hiányzó --cadastre/--street-field/--street-values)')
    print(f'Kész: V{v} frissítve.')
if __name__=='__main__': main()
