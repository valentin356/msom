# HU EOV Geocoder – Egyfájlos cadastre (GeoParquet) támogatás
Build: 2025-10-16T11:55:06.217568Z

## Használat
seed: python seed_base.py --input alap.xlsx --schema schemas/schema.json --store ./store --cadastre cadastre.parquet --cad-geometry-col geometry --street-field layer_type --street-values "ROAD,STREET"

update: python update_base.py --input friss.parquet --schema schemas/schema.json --store ./store --cadastre cadastre.parquet --cad-geometry-col geometry --street-field layer_type --street-values '["ROAD","STREET"]'

geocode: python geocode_batch.py --store ./store --schema schemas/schema.json --targets geokodolandok.xlsx --out-csv geokodolt.csv --use-frontage
