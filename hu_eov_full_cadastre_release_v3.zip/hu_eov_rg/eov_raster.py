import numpy as np, pandas as pd
class RasterIndexEOV:
    def __init__(self, base_res_m=2048.0, max_level=11):
        self.base_res_m=float(base_res_m); self.max_level=int(max_level); self.addr_df=None; self.x0=None; self.y0=None
        import pandas as pd; self.graph=type('G',(),{})(); self.graph.edges=pd.DataFrame(columns=['settlement','street','parity','num_lo','num_hi','x_lo','y_lo','x_hi','y_hi','gap_m','interp_allowed'])
    def ingest_df(self, df: pd.DataFrame): self.addr_df=df.copy()
    def fit_origin_from_df(self, df: pd.DataFrame):
        x=df['eov_x'].dropna().to_numpy(); y=df['eov_y'].dropna().to_numpy()
        self.x0=float(np.floor(x.min()/1000.0)*1000.0) if x.size else 0.0; self.y0=float(np.floor(y.min()/1000.0)*1000.0) if y.size else 0.0
    def build_cells_from_coords(self): return
    def build_graph(self, sparse_gap_m=200.0):
        if self.addr_df is None: return
        df=self.addr_df.copy(); df['base_num']=pd.to_numeric(df['house_number'].astype(str).str.extract(r'(\d+)')[0], errors='coerce')
        df=df.dropna(subset=['base_num','eov_x','eov_y']); df['base_num']=df['base_num'].astype(int); df['parity']=np.where((df['base_num']%2==0),'even','odd')
        edges=[]
        for (sett,street,parity),g in df.sort_values(['settlement','street','parity','base_num']).groupby(['settlement','street','parity']):
            g=g.reset_index(drop=True)
            for i in range(len(g)-1):
                lo=g.iloc[i]; hi=g.iloc[i+1]
                num_lo,num_hi=int(lo['base_num']),int(hi['base_num'])
                x_lo,y_lo=float(lo['eov_x']),float(lo['eov_y']); x_hi,y_hi=float(hi['eov_x']),float(hi['eov_y'])
                gap=float(np.hypot(x_hi-x_lo,y_hi-y_lo)); interp_allowed=bool(gap <= sparse_gap_m*4.0)
                edges.append([sett,street,parity,num_lo,num_hi,x_lo,y_lo,x_hi,y_hi,gap,interp_allowed])
        self.graph.edges=pd.DataFrame(edges, columns=['settlement','street','parity','num_lo','num_hi','x_lo','y_lo','x_hi','y_hi','gap_m','interp_allowed'])
