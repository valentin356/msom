import pandas as pd, numpy as np
from .housenum import extract_base_num
from .keyhash import hash64

def build_key_id(df: pd.DataFrame) -> pd.Series:
    key=df['settlement'].astype('string').fillna('')+'||'+df['street'].astype('string').fillna('')+'||'+df['parity'].astype('string').fillna('')
    return hash64(key)

def geocode_vectorized(base_df: pd.DataFrame, edges_df: pd.DataFrame, targets_df: pd.DataFrame):
    anchors=base_df[base_df['has_coords']].copy(); anchors['base_num']=extract_base_num(anchors['house_number']); anchors=anchors.dropna(subset=['base_num'])
    anchors['parity']=np.where((anchors['base_num']%2==0),'even','odd'); anchors['base_num']=anchors['base_num'].astype(np.int32)
    for c in ['settlement','street','parity']: anchors[c]=anchors[c].astype('string')
    anchors['key_id']=build_key_id(anchors); anchors.sort_values(['key_id','base_num'], inplace=True)
    T=targets_df.copy(); T['base_num']=extract_base_num(T['house_number']).astype('Int64'); T['parity']=np.where(T['base_num'].notna() & ((T['base_num']%2)==0),'even','odd')
    for c in ['settlement','street','parity']: T[c]=T[c].astype('string')
    T['key_id']=build_key_id(T); T.sort_values(['key_id','base_num'], inplace=True)
    exact_map=base_df.set_index(['settlement','street','house_number'])[['eov_x','eov_y']]
    keys=list(zip(T['settlement'],T['street'],T['house_number'].astype(str))); exact_xy=exact_map.reindex(keys)
    exact_mask=exact_xy['eov_x'].notna() & exact_xy['eov_y'].notna(); out=pd.DataFrame(index=T.index)
    out.loc[exact_mask,'eov_x']=exact_xy.loc[exact_mask,'eov_x']; out.loc[exact_mask,'eov_y']=exact_xy.loc[exact_mask,'eov_y']
    out.loc[exact_mask,'GEOCODE_SOURCE']='exact'; out.loc[exact_mask,'GEOCODE_ERROR_M']=0.0
    remaining=~exact_mask; nonum=remaining & T['base_num'].isna()
    if nonum.any():
        cent=base_df[base_df['has_coords']].groupby(['settlement','street'])[['eov_x','eov_y']].mean().rename(columns={'eov_x':'cx','eov_y':'cy'})
        c_keys=list(zip(T.loc[nonum,'settlement'],T.loc[nonum,'street'])); cxy=cent.reindex(c_keys)
        out.loc[nonum,'eov_x']=cxy['cx'].values; out.loc[nonum,'eov_y']=cxy['cy'].values
        out.loc[nonum,'GEOCODE_SOURCE']='street-centroid'; out.loc[nonum,'GEOCODE_ERROR_M']=150.0
    todo=remaining & T['base_num'].notna()
    if todo.any():
        A=anchors[['key_id','base_num','eov_x','eov_y']].copy()
        L=pd.merge_asof(T.loc[todo,['key_id','base_num']].sort_values(['key_id','base_num']), A.rename(columns={'eov_x':'x_lo','eov_y':'y_lo'}).sort_values(['key_id','base_num']), by='key_id', on='base_num', direction='backward', allow_exact_matches=True)
        H=pd.merge_asof(T.loc[todo,['key_id','base_num']].sort_values(['key_id','base_num']), A.rename(columns={'eov_x':'x_hi','eov_y':'y_hi'}).sort_values(['key_id','base_num']), by='key_id', on='base_num', direction='forward', allow_exact_matches=True)
        L=L.reindex(T.loc[todo].sort_values(['key_id','base_num']).index); H=H.reindex(T.loc[todo].sort_values(['key_id','base_num']).index)
        bn=T.loc[todo,'base_num'].astype(int); lo_missing=L['x_lo'].isna() | L['y_lo'].isna(); hi_missing=H['x_hi'].isna() | H['y_hi'].isna(); nearest=lo_missing|hi_missing
        if nearest.any():
            xl=L.loc[nearest,'x_lo']; yl=L.loc[nearest,'y_lo']; xh=H.loc[nearest,'x_hi']; yh=H.loc[nearest,'y_hi']; use_lo=xl.notna()
            out.loc[T.loc[todo].index[nearest],'eov_x']=np.where(use_lo,xl,xh); out.loc[T.loc[todo].index[nearest],'eov_y']=np.where(use_lo,yl,yh)
            out.loc[T.loc[todo].index[nearest],'GEOCODE_SOURCE']='nearest'; out.loc[T.loc[todo].index[nearest],'GEOCODE_ERROR_M']=60.0
        both=(~lo_missing) & (~hi_missing)
        if both.any():
            idx=T.loc[todo].index[both]; blo=L.loc[both,'base_num'].astype(int).values; bhi=H.loc[both,'base_num'].astype(int).values
            denom=(bhi-blo).astype(float); denom[denom==0]=1.0; ratio=(bn.loc[idx].values-blo)/denom
            x=L.loc[both,'x_lo'].values + ratio*(H.loc[both,'x_hi'].values - L.loc[both,'x_lo'].values)
            y=L.loc[both,'y_lo'].values + ratio*(H.loc[both,'y_hi'].values - L.loc[both,'y_lo'].values)
            out.loc[idx,'eov_x']=x; out.loc[idx,'eov_y']=y; out.loc[idx,'GEOCODE_SOURCE']='interpolated'; out.loc[idx,'GEOCODE_ERROR_M']=100.0
    missing_addr=out['GEOCODE_SOURCE'].isna() & (T['settlement'].isna() | T['street'].isna())
    out.loc[missing_addr,'GEOCODE_SOURCE']='insufficient-address'; out.loc[missing_addr,'GEOCODE_ERROR_M']=pd.NA
    return out
