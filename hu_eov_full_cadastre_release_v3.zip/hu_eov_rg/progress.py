from tqdm import tqdm

def pbar(iterable=None, **kwargs):
    defaults = dict(leave=False, mininterval=0.3, smoothing=0.1)
    defaults.update(kwargs or {})
    return tqdm(iterable, **defaults) if iterable is not None else tqdm(**defaults)
