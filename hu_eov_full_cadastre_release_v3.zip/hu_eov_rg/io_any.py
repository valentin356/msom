import os, pandas as pd

def load_any_table(path: str) -> pd.DataFrame:
    ext = os.path.splitext(path.lower())[1]
    if ext in ('.parquet', '.pq'):
        return pd.read_parquet(path)
    if ext in ('.csv', '.txt'):
        return pd.read_csv(path)
    if ext in ('.xlsx', '.xls'):
        return pd.read_excel(path)
    raise ValueError(f'Nem támogatott bemenet: {path}')
