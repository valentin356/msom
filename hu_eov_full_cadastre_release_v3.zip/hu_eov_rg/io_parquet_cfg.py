import json, pandas as pd
DEFAULTS={"settlement":None,"street":None,"street_type":None,"house_number":None,"lot_number":None,"building":None,"staircase":None,"floor":None,"door":None,"district":None,"sublocality":None,"EOV_X":None,"EOV_Y":None}

def normalize_df_with_schema(df: pd.DataFrame, schema_json_path: str) -> pd.DataFrame:
    s=json.load(open(schema_json_path,'r',encoding='utf-8'))
    m={k:s.get(k,v) for k,v in DEFAULTS.items()}
    out=pd.DataFrame()
    for dst,src in m.items(): out[dst]=df[src] if (src and src in df.columns) else None
    for c in ["settlement","street","street_type","house_number","lot_number","building","staircase","floor","door","district","sublocality"]:
        out[c]=out[c].astype('string').str.strip() if c in out.columns else None
    out['eov_x']=pd.to_numeric(out.get('EOV_Y'), errors='coerce'); out['eov_y']=pd.to_numeric(out.get('EOV_X'), errors='coerce')
    out['has_coords']=out['eov_x'].notna() & out['eov_y'].notna()
    return out
