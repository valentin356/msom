import logging, json, pandas as pd
log=logging.getLogger(__name__)

def _sha1_hex(b: bytes)->str:
    import hashlib; return hashlib.sha1(b).hexdigest()

def _to_eov(gdf, target_epsg=23700):
    if gdf.crs is None: gdf=gdf.set_crs(epsg=target_epsg)
    elif gdf.crs.to_epsg()!=target_epsg: gdf=gdf.to_crs(epsg=target_epsg)
    return gdf

def load_geoparquet_polygons(path:str, geometry_col='geometry', target_epsg=23700):
    try:
        import geopandas as gpd
        gdf=gpd.read_parquet(path)
        if geometry_col in gdf.columns and gdf.geometry.name!=geometry_col: gdf=gdf.set_geometry(geometry_col)
    except Exception as e:
        import pandas as pd
        from shapely import wkb, wkt
        df=pd.read_parquet(path)
        if geometry_col not in df.columns: raise RuntimeError(f'Hiányzó geometria oszlop: {geometry_col}')
        def to_geom(v):
            try:
                if hasattr(v,'geom_type'): return v
                if isinstance(v,(bytes,bytearray)): return wkb.loads(v)
                if isinstance(v,str): return wkt.loads(v)
            except Exception: return None
            return None
        geom=df[geometry_col].map(to_geom)
        import geopandas as gpd
        gdf=gpd.GeoDataFrame(df.drop(columns=[geometry_col]), geometry=geom, crs=f'EPSG:{target_epsg}')
    return _to_eov(gdf, target_epsg)

def split_parcels_and_streets(gdf, field:str, street_values, parcel_values=None):
    if isinstance(street_values,str):
        try: street_values=json.loads(street_values)
        except Exception: street_values=[v.strip() for v in street_values.split(',') if v.strip()]
    if parcel_values is not None and isinstance(parcel_values,str):
        try: parcel_values=json.loads(parcel_values)
        except Exception: parcel_values=[v.strip() for v in parcel_values.split(',') if v.strip()]
    if field not in gdf.columns: raise ValueError(f'Mező nem található: {field}')
    street_mask=gdf[field].astype(str).isin(set(map(str, street_values)))
    parcel_mask=gdf[field].astype(str).isin(set(map(str, parcel_values))) if parcel_values else ~street_mask
    return gdf[parcel_mask].copy(), gdf[street_mask].copy()

def parcels_centroids(gdf_parcels):
    C=gdf_parcels.copy(); C['eov_x']=C.geometry.centroid.x; C['eov_y']=C.geometry.centroid.y
    return C[['eov_x','eov_y']].assign(parcel_id=C.geometry.apply(lambda g:_sha1_hex(g.wkb)))

def streets_axes_pca(gdf_streets):
    rows=[]
    for _,row in gdf_streets.iterrows():
        geom=row.geometry
        try:
            xs,ys=geom.exterior.coords.xy
            import numpy as np
            X=np.c_[np.array(xs),np.array(ys)]
            if X.shape[0]<3: continue
            mu=X.mean(axis=0); X0=X-mu; U,S,VT=np.linalg.svd(X0, full_matrices=False); dirv=VT[0]
            rows.append({'cx':float(mu[0]),'cy':float(mu[1]),'dir_x':float(dirv[0]),'dir_y':float(dirv[1])})
        except Exception: continue
    return pd.DataFrame(rows)

def frontage_points_from_polygons(gdf_parcels, gdf_streets, buffer_m=20.0):
    from shapely.ops import nearest_points
    from shapely.strtree import STRtree
    P=gdf_parcels.copy(); S=gdf_streets.copy(); P['boundary']=P.geometry.boundary; S['boundary']=S.geometry.boundary
    treeS=STRtree(S['boundary'].values.tolist()); out=[]
    for i,pb in enumerate(P['boundary'].values):
        cand=treeS.query(pb.buffer(buffer_m))
        for sb in cand or []:
            p=nearest_points(pb,sb)[0]; out.append({'parcel_idx':i,'eov_x':p.x,'eov_y':p.y})
    import pandas as pd
    return pd.DataFrame(out).drop_duplicates()
