import argparse, os, sys
import torch
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from src.drift.training import train_unlabeled

def main(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--stack', required=True)
    parser.add_argument('--epochs', type=int, default=2)
    parser.add_argument('--tile', type=int, default=256)
    parser.add_argument('--out', default='models/drift.ckpt')
    if isinstance(args, argparse.Namespace): ns=args
    else: ns=parser.parse_args()
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    os.makedirs(os.path.dirname(ns.out), exist_ok=True)
    train_unlabeled(ns.stack, epochs=ns.epochs, tile=ns.tile, save_path=ns.out, device=device)

if __name__ == '__main__':
    main()
