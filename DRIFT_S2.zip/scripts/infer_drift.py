import argparse, os, sys
import torch
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from src.drift.inference import infer

def main(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--stack', required=True)
    parser.add_argument('--weights', required=True)
    parser.add_argument('--out_prefix', required=True)
    parser.add_argument('--tile', type=int, default=256)
    parser.add_argument('--overlap', type=int, default=32)
    if isinstance(args, argparse.Namespace): ns=args
    else: ns=parser.parse_args()
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    os.makedirs(os.path.dirname(ns.out_prefix), exist_ok=True)
    infer(ns.stack, ns.weights, ns.out_prefix, device=device, tile=ns.tile, overlap=ns.overlap)

if __name__ == '__main__':
    main()
