# DRIFT — Discrete Routing In-Field Transduction (Sentinel-2, unlabeled)

Unlabeled Sentinel-2 pipeline with GDAL-only IO, nearest-neighbor resampling, discrete routing quantizer and CRF refinement.
