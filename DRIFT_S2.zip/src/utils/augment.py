import torch
import numpy as np

def random_block_mask(x, mask_ratio=0.75, block=8):
    # x: (B,C,H,W)
    B,C,H,W = x.shape
    mask = torch.zeros((B,1,H,W), device=x.device)
    num_blocks = int((H*W*mask_ratio)/(block*block))
    for b in range(B):
        for _ in range(num_blocks):
            i = np.random.randint(0, max(1,H-block+1))
            j = np.random.randint(0, max(1,W-block+1))
            mask[b,0,i:i+block,j:j+block] = 1.0
    x_masked = x*(1-mask)
    return x_masked, mask

def normalize_minmax(x, eps=1e-6):
    xmin = x.amin(dim=(2,3), keepdim=True)
    xmax = x.amax(dim=(2,3), keepdim=True)
    return (x - xmin) / (xmax - xmin + eps)
