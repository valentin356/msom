import torch

def sinkhorn_knopp(logits, n_iters=3, epsilon=0.05):
    # Balanced assignment via Sinkhorn on exp(logits/epsilon)
    Q = torch.exp(logits / epsilon)
    Q = Q + 1e-12
    Q /= Q.sum(dim=1, keepdim=True)
    for _ in range(n_iters):
        Q /= Q.sum(dim=2, keepdim=True)
        Q /= Q.sum(dim=1, keepdim=True)
    return Q
