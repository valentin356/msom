import os, re, zipfile
from osgeo import gdal
import numpy as np
from .geoutils import open_gdal, reproject_near, write_array_like

S2_BANDS = ['B01','B02','B03','B04','B05','B06','B07','B08','B8A','B09','B10','B11','B12']

def list_zip_members(zip_path):
    with zipfile.ZipFile(zip_path, 'r') as z:
        return z.namelist()

def find_safe_root(members):
    for m in members:
        if m.endswith('.SAFE/'):
            return m
    roots = sorted(set([m.split('/')[0] for m in members if m.endswith('.SAFE/') or '.SAFE/' in m]))
    if roots:
        return roots[0] + ('/' if not roots[0].endswith('/') else '')
    raise RuntimeError('No .SAFE root found in ZIP')

def best_band_files(zip_path):
    # Return dict band -> (vsi_path, res_meters)
    members = list_zip_members(zip_path)
    _ = find_safe_root(members)
    pattern = re.compile(r'.*GRANULE/.*/IMG_DATA/(R10m|R20m|R60m)/.*_(B0[1-9]|B1[0-2]|B8A)_(10m|20m|60m)\.jp2$', re.IGNORECASE)
    candidates = {}
    for m in members:
        if not m.lower().endswith('.jp2'):
            continue
        if 'IMG_DATA' not in m:
            continue
        mm = pattern.match(m)
        if not mm:
            continue
        band = mm.group(2).upper(); res = mm.group(3); res_int = int(res.replace('m',''))
        vsi = f'/vsizip/{zip_path}/{m}'
        cur = candidates.get(band)
        if (cur is None) or (res_int < cur[1]):
            candidates[band] = (vsi, res_int)
    return candidates

def pick_reference_10m(candidates):
    for b in ['B04','B03','B02','B08']:
        if b in candidates and candidates[b][1] == 10:
            return candidates[b][0]
    best = None
    for b,(p,r) in candidates.items():
        if (best is None) or (r < best[1]):
            best = (p,r)
    return best[0]

def build_stack(zip_path, out_stack_path, wanted_bands=None, scale_to_reflectance=True):
    if wanted_bands is None:
        wanted_bands = S2_BANDS
    cand = best_band_files(zip_path)
    if not cand:
        raise RuntimeError('No bands found in ZIP')
    ref_path = pick_reference_10m(cand)
    ref_ds = open_gdal(ref_path)
    arrays = []; names = []
    for band in wanted_bands:
        if band not in cand:
            continue
        src_path, res = cand[band]
        if res != 10:
            tmp = reproject_near(src_path, ref_ds, out_path=f'/vsimem/tmp_{band}.tif')
            ds = open_gdal(tmp)
        else:
            ds = open_gdal(src_path)
        arr = ds.ReadAsArray().astype(np.float32)
        if scale_to_reflectance:
            arr = arr / 10000.0; arr = np.clip(arr, 0.0, 1.0)
        arrays.append(arr); names.append(band)
        ds = None
    if not arrays:
        raise RuntimeError('No wanted bands available')
    stack = np.stack(arrays, axis=0)
    write_array_like(ref_ds, out_stack_path, stack, dtype=gdal.GDT_Float32, compress='LZW')
    ref_ds = None
    return names
