import numpy as np
from osgeo import gdal

def open_gdal(path):
    ds = gdal.Open(path, gdal.GA_ReadOnly)
    if ds is None:
        raise RuntimeError(f'Cannot open: {path}')
    return ds

def read_as_array(ds):
    bands = ds.RasterCount
    arr = np.stack([ds.GetRasterBand(i+1).ReadAsArray() for i in range(bands)], axis=0)
    return arr

def create_like(ref_ds, out_path, bands, dtype=gdal.GDT_Float32, compress='LZW'):
    driver = gdal.GetDriverByName('GTiff')
    xsize = ref_ds.RasterXSize
    ysize = ref_ds.RasterYSize
    geotrans = ref_ds.GetGeoTransform()
    proj = ref_ds.GetProjection()
    opts = ['TILED=YES', 'COMPRESS='+compress, 'BIGTIFF=IF_SAFER']
    dst = driver.Create(out_path, xsize, ysize, bands, dtype, options=opts)
    dst.SetGeoTransform(geotrans)
    dst.SetProjection(proj)
    return dst

def write_array_like(ref_ds, out_path, array, dtype=gdal.GDT_Float32, compress='LZW', nodata=None):
    if array.ndim == 2:
        array = array[None, ...]
    dst = create_like(ref_ds, out_path, array.shape[0], dtype=dtype, compress=compress)
    for i in range(array.shape[0]):
        band = dst.GetRasterBand(i+1)
        band.WriteArray(array[i])
        if nodata is not None:
            band.SetNoDataValue(nodata)
        band.FlushCache()
    dst.FlushCache()
    dst = None

def reproject_near(src_path, ref_ds, out_path=None):
    if out_path is None:
        out_path = '/vsimem/tmp_reproj.tif'
    gt = ref_ds.GetGeoTransform()
    xsize = ref_ds.RasterXSize
    ysize = ref_ds.RasterYSize
    minx = gt[0]; maxy = gt[3]
    maxx = minx + xsize * gt[1]
    miny = maxy + ysize * gt[5]
    dst_wkt = ref_ds.GetProjection()
    warp_options = gdal.WarpOptions(format='GTiff', outputBounds=(minx, miny, maxx, maxy), width=xsize, height=ysize,
        dstSRS=dst_wkt, resampleAlg=gdal.GRA_NearestNeighbour, multithread=True, xRes=abs(gt[1]), yRes=abs(gt[5]), targetAlignedPixels=True)
    out_ds = gdal.Warp(out_path, src_path, options=warp_options)
    if out_ds is None:
        raise RuntimeError(f'gdal.Warp failed for {src_path}')
    out_ds.FlushCache(); out_ds=None
    return out_path
