import torch
import torch.nn as nn

class ConvBlock(nn.Module):
    def __init__(self, c_in, c_out, k=3, s=1):
        super().__init__()
        p = k//2
        self.net = nn.Sequential(
            nn.Conv2d(c_in, c_out, k, s, p),
            nn.GroupNorm(4, c_out),
            nn.GELU()
        )
    def forward(self, x):
        return self.net(x)

class Encoder(nn.Module):
    def __init__(self, in_ch, dim=64):
        super().__init__()
        self.stem = nn.Sequential(
            ConvBlock(in_ch, 64, 5, 2),
            ConvBlock(64, 64, 3, 1),
            ConvBlock(64, 96, 3, 2),
            ConvBlock(96, dim, 3, 1),
        )
    def forward(self, x):
        return self.stem(x)

class Decoder(nn.Module):
    def __init__(self, in_ch, dim=64, out_ch=None):
        super().__init__()
        self.out_ch = out_ch or in_ch
        self.net = nn.Sequential(
            ConvBlock(dim, 96, 3, 1),
            nn.Upsample(scale_factor=2, mode='nearest'),
            ConvBlock(96, 64, 3, 1),
            nn.Upsample(scale_factor=2, mode='nearest'),
            ConvBlock(64, 64, 3, 1),
            ConvBlock(64, self.out_ch, 1, 1),
        )
    def forward(self, z):
        return self.net(z)

class M2PT(nn.Module):
    def __init__(self, in_ch, dim=64):
        super().__init__()
        self.enc = Encoder(in_ch, dim)
        self.dec = Decoder(in_ch, dim, out_ch=in_ch)
        self.mask_token = nn.Parameter(torch.zeros(1, in_ch, 1, 1))

    def forward(self, x, mask=None):
        if mask is not None:
            x_in = x*(1-mask) + self.mask_token*mask
        else:
            x_in = x
        z = self.enc(x_in)
        x_hat = self.dec(z)
        return z, x_hat
