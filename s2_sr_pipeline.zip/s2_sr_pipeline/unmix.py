
import torch
import torch.nn as nn
import torch.nn.functional as F

class DirichletUnmix(nn.Module):
    def __init__(self, in_dim:int, endmembers:int, temp:float=1.0):
        super().__init__()
        self.endmembers = endmembers
        self.net = nn.Sequential(
            nn.Conv2d(in_dim, in_dim, 3, padding=1),
            nn.ReLU(True),
            nn.Conv2d(in_dim, endmembers, 1)
        )
        self.log_temp = nn.Parameter(torch.log(torch.tensor([temp])))

    def forward(self, feat):
        # feat: [B,D,H,W]
        logits = self.net(feat) / torch.exp(self.log_temp)
        a = F.softmax(logits, dim=1)  # [B,K,H,W]
        return a

def mix_spectra(abundances, endmembers):
    # abundances: [B,K,H,W], endmembers: [K,C]
    B,K,H,W = abundances.shape
    return torch.einsum('bkhw,kc->bchw', abundances, endmembers.clamp(0,1))
