
import torch
import torch.nn as nn

class GuidanceNet(nn.Module):
    def __init__(self, in_ch:int=4, hidden:int=32):
        super().__init__()
        self.enc1 = nn.Sequential(nn.Conv2d(in_ch, hidden, 3, padding=1), nn.ReLU(True))
        self.enc2 = nn.Sequential(nn.Conv2d(hidden, hidden, 3, stride=2, padding=1), nn.ReLU(True))
        self.enc3 = nn.Sequential(nn.Conv2d(hidden, hidden, 3, stride=2, padding=1), nn.ReLU(True))
        self.dec2 = nn.Sequential(nn.ConvTranspose2d(hidden, hidden, 2, stride=2), nn.ReLU(True))
        self.dec1 = nn.Sequential(nn.ConvTranspose2d(hidden, hidden, 2, stride=2), nn.ReLU(True))
        self.out  = nn.Conv2d(hidden, 2, 3, padding=1)

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(e1)
        e3 = self.enc3(e2)
        d2 = self.dec2(e3) + e2
        d1 = self.dec1(d2) + e1
        g  = self.out(d1)
        return g
