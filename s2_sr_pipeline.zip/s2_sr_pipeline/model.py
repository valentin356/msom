
import torch
import torch.nn as nn
import torch.nn.functional as F

from .som import GraphSOM
from .unmix import DirichletUnmix, mix_spectra
from .guidance import GuidanceNet
from .ot import micro_mesh
from .psf import degrade_psf_downsample
from .losses import l1_recon, spectral_angle_mapper, total_variation, gradient_align_loss
from .config import ModelConfig

class GraphSOMUpscaleModel(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.cfg = cfg
        self.feat = nn.Sequential(
            nn.Conv2d(cfg.bands, 64, 3, padding=1),
            nn.ReLU(True),
            nn.Conv2d(64, 64, 3, padding=1),
            nn.ReLU(True),
        )
        self.som = GraphSOM(codebook=cfg.som_codebook, bands=cfg.bands, sigma=cfg.som_sigma)
        self.unmix = DirichletUnmix(in_dim=64, endmembers=cfg.endmembers, temp=0.7)
        self.guidance = GuidanceNet(in_ch=min(cfg.bands,4))
        # learnable endmembers directly (simpler than mapping from SOM prototypes)
        self.endmembers = nn.Parameter(torch.rand(cfg.endmembers, cfg.bands)*0.1)

    def forward(self, x_lr, anchors_lr=None, compute_loss=False):
        B,C,H,W = x_lr.shape
        up = self.cfg.up_factor

        f = self.feat(x_lr)                    # [B,64,H,W]
        # SOM (optional) - not strictly necessary for forward here
        _w_som, _protos = self.som(x_lr.movedim(1,-1).reshape(B,H*W,C))

        a_coarse = self.unmix(f)               # [B,K,H,W]

        if anchors_lr is None:
            anchors_lr = x_lr[:,:min(C,4)]
        G = self.guidance(anchors_lr)          # [B,2,H,W]

        A_hr = micro_mesh(a_coarse, up=up, guidance=G, iters_smooth=5)  # [B,K,H*up,W*up]

        Y_hr = mix_spectra(A_hr, self.endmembers)  # [B,C,H*up,W*up]

        out = {"Y_hr": Y_hr, "A_hr": A_hr, "endmembers": self.endmembers, "A_coarse": a_coarse, "guidance": G}

        if compute_loss:
            x_rec = degrade_psf_downsample(Y_hr, stride=up)  # [B,C,H,W]
            loss_recon = l1_recon(x_rec, x_lr)
            loss_sam   = spectral_angle_mapper(x_lr, x_rec)
            loss_tv    = total_variation(A_hr)
            loss_grad  = gradient_align_loss(Y_hr, torch.nn.functional.interpolate(G, scale_factor=up, mode='bilinear', align_corners=False))

            total = (self.cfg.recon_l1_weight*loss_recon +
                     self.cfg.sam_weight*loss_sam +
                     self.cfg.tv_weight*loss_tv +
                     self.cfg.grad_weight*loss_grad)

            out.update({
                "loss_total": total,
                "loss_recon": loss_recon,
                "loss_sam": loss_sam,
                "loss_tv": loss_tv,
                "loss_grad": loss_grad
            })
        return out
