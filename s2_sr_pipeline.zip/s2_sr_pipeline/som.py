
import torch
import torch.nn as nn
import torch.nn.functional as F

class GraphSOM(nn.Module):
    def __init__(self, codebook:int, bands:int, sigma:float=1.5):
        super().__init__()
        self.codebook = codebook
        self.bands = bands
        self.sigma = sigma
        self.prototypes = nn.Parameter(torch.rand(codebook, bands)*0.05)

    def forward(self, x):
        # x: [B,N,Bands]
        protos = self.prototypes  # [K,D]
        x_n = F.normalize(x, dim=-1)
        p_n = F.normalize(protos, dim=-1)
        sim = x_n @ p_n.T  # [B,N,K]
        w = F.softmax(sim*3.0, dim=-1)
        return w, protos

    def prototypes_clamped(self):
        return self.prototypes.clamp(0.0,1.0)
