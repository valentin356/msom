
import torch
import torch.nn.functional as F

def l1_recon(pred, target):
    return (pred - target).abs().mean()

def spectral_angle_mapper(y_true, y_pred, eps=1e-8):
    B,C,H,W = y_true.shape
    yt = y_true.movedim(1,-1).reshape(B,-1,C)
    yp = y_pred.movedim(1,-1).reshape(B,-1,C)
    num = (yt*yp).sum(-1)
    den = (yt.norm(dim=-1)*yp.norm(dim=-1)).clamp_min(eps)
    ang = torch.acos(torch.clamp(num/den, -1+1e-6, 1-1e-6))
    return ang.mean()

def total_variation(A):
    dx = (A[:,:,:,1:] - A[:,:,:,:-1]).abs().mean()
    dy = (A[:,:,1:,:] - A[:,:,:-1,:]).abs().mean()
    return dx + dy

def gradient_align_loss(Y, G):
    gray = Y.mean(1, keepdim=True)
    gx = gray[:,:,:,1:] - gray[:,:,:,:-1]
    gy = gray[:,:,1:,:] - gray[:,:,:-1,:]
    Gx = G[:,0:1]; Gy = G[:,1:2]
    gx = F.pad(gx, (0,1,0,0)); gy = F.pad(gy, (0,0,0,1))
    num = gx*Gx + gy*Gy
    den = (gx.square() + gy.square()).sqrt()*(Gx.square()+Gy.square()).sqrt() + 1e-6
    cos = num/den
    return (1 - cos).mean()
