
import torch
import torch.nn.functional as F

def _simplex_project(x, eps=1e-8):
    shape = x.shape
    x = x.reshape(-1, shape[-1])
    mu, _ = torch.sort(x, dim=1, descending=True)
    cssv = torch.cumsum(mu, dim=1) - 1
    ind = torch.arange(1, shape[-1]+1, device=x.device).unsqueeze(0)
    cond = mu - cssv / ind > 0
    rho = cond.sum(dim=1) - 1
    theta = (cssv[torch.arange(x.size(0)), rho] / (rho + 1).clamp_min(1)).unsqueeze(1)
    w = torch.clamp(x - theta, min=0)
    return w.reshape(shape)

def micro_mesh(coarse_a, up:int, guidance=None, iters_smooth:int=5):
    B,K,H,W = coarse_a.shape
    sub_A = F.interpolate(coarse_a, scale_factor=up, mode="nearest")
    # Enforce cell marginals (two iterations)
    for _ in range(2):
        pooled = F.avg_pool2d(sub_A, kernel_size=up, stride=up)  # [B,K,H,W]
        diff = coarse_a - pooled
        diff_up = diff.repeat_interleave(up, -2).repeat_interleave(up, -1) / (up*up)
        sub_A = sub_A + diff_up
        sub_A = _simplex_project(sub_A.movedim(1,-1)).movedim(-1,1)
    # Guidance-weighted smoothing
    if guidance is not None:
        G = F.interpolate(guidance, scale_factor=up, mode="bilinear", align_corners=False)
        gx = G[:,0:1]; gy = G[:,1:2]
    else:
        gx = gy = None

    for _ in range(iters_smooth):
        dx = torch.zeros_like(sub_A)
        dy = torch.zeros_like(sub_A)
        dx[:,:,:,1:] = sub_A[:,:,:,1:] - sub_A[:,:,:,:-1]
        dy[:,:,1:,:] = sub_A[:,:,1:,:] - sub_A[:,:,:-1,:]
        if gx is not None and gy is not None:
            wdx = 1.0 / (1.0 + (gx.abs()+1e-3))
            wdy = 1.0 / (1.0 + (gy.abs()+1e-3))
            dx = dx * wdx
            dy = dy * wdy
        sub_A = sub_A - 0.5*(dx - F.pad(dx[:,:,:,1:], (0,1,0,0)) + dy - F.pad(dy[:,:,1:,:], (0,0,0,1)))
        sub_A = _simplex_project(sub_A.movedim(1,-1)).movedim(-1,1)
    return sub_A
