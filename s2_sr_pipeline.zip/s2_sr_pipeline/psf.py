
import torch
import torch.nn.functional as F

def gaussian_kernel2d(ks: int, sigma: float, device=None, dtype=None):
    ax = torch.arange(ks, device=device, dtype=dtype) - (ks-1)/2
    xx, yy = torch.meshgrid(ax, ax, indexing="ij")
    k = torch.exp(-(xx**2 + yy**2)/(2*sigma**2))
    k = k / k.sum()
    return k

def band_psf_kernel(band_index: int, ks: int=9, device=None, dtype=None):
    # Placeholder heuristic; replace with S2 PSF tables for accuracy
    if band_index in [1,2,3,7]:   # approx 10m bands (B02,B03,B04,B08) -> indices depend on order used
        sigma = 1.2
    elif band_index in [4,5,6,8,10,11]:
        sigma = 2.0
    else:
        sigma = 3.5
    return gaussian_kernel2d(ks, sigma, device=device, dtype=dtype)

def degrade_psf_downsample(x, stride:int=10, kernel_size:int=9):
    B,C,H,W = x.shape
    device, dtype = x.device, x.dtype
    weight = []
    for b in range(C):
        k = band_psf_kernel(band_index=b, ks=kernel_size, device=device, dtype=dtype)
        weight.append(k)
    Wk = torch.stack(weight, dim=0).unsqueeze(1)  # [C,1,ks,ks]
    x_blur = F.conv2d(x, Wk, padding=kernel_size//2, groups=C)
    x_ds = x_blur[:,:,::stride,::stride]
    return x_ds
