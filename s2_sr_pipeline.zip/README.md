
# s2_sr_pipeline (all-in-one)

**Everything in 1 ZIP**: Sentinel-2 SAFE **ZIP loader** (R10m/R20m/R60m) + **Graph-SOM + Unmixing + micro-meshing** model, with a **main** CLI that loads a raw `.zip`, stacks bands to 10/20/60 m, runs the model, and writes a **1 m**-ish HR GeoTIFF.

> Research prototype. The model is untrained by default (works end-to-end but output is not scientifically meaningful until trained).

## Install

```bash
pip install rasterio numpy torch
```

## Run

```bash
python -m s2_sr_pipeline.main /path/to/S2_product.zip   --out hr_1m.tif   --res 10   --up 10   --bands B02 B03 B04 B08 B11 B12 B8A   --reflectance
```

Options:
- `--res {10,20,60}`: LR stacking resolution before upscaling.
- `--up`: upscale factor (10 => 1 m from 10 m grid).
- `--endmembers K`: number of learned endmembers.
- `--bands ...`: choose bands; default=all available.
- `--save-lr stack_10m.tif`: also write the LR stack.
- `--device cuda|cpu`: inference device.

## Notes

- Loader reads JP2 **from the ZIP** (no manual unzip).
- HR GeoTIFF georeference is derived by shrinking pixel size by `up` while keeping the same origin/CRS.
- PSF/MTF degrade is only used for training loss; here inference-only pipeline skips loss computation.
- For training, add your loop and optimize `model.parameters()` with a PSF-aware LR reconstruction loss.
